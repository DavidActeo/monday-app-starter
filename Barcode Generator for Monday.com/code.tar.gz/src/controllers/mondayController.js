/**
 * Monday.com Controller
 * 
 * This file contains controller functions for Monday.com API interactions,
 * board management, and item operations.
 */

const logger = require('../utils/logger');
const mondayService = require('../services/mondayService');
const { createError } = require('../middleware/errorHandler');

// ==============================================
// BOARD OPERATIONS
// ==============================================

/**
 * Get user's Monday.com boards
 * GET /api/monday/boards
 */
const getBoards = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Boards retrieval requested', { userId });

    const boards = await mondayService.getUserBoards(accessToken);

    res.status(200).json({
      status: 'success',
      data: {
        boards: boards.map(board => ({
          id: board.id,
          name: board.name,
          description: board.description,
          state: board.state,
          itemsCount: board.items?.length || 0,
          columns: board.columns?.map(col => ({
            id: col.id,
            title: col.title,
            type: col.type
          })) || [],
          groups: board.groups?.map(group => ({
            id: group.id,
            title: group.title,
            color: group.color
          })) || []
        })),
        total: boards.length
      }
    });

  } catch (error) {
    logger.error('Error fetching boards:', error);
    
    if (error.response && error.response.status === 401) {
      return next(createError(401, 'Monday.com authentication failed', 'MONDAY_AUTH_FAILED'));
    }
    
    next(createError(500, 'Failed to fetch boards', 'BOARDS_FETCH_FAILED'));
  }
};

/**
 * Get items from a specific Monday.com board
 * GET /api/monday/boards/:boardId/items
 */
const getBoardItems = async (req, res, next) => {
  try {
    const { boardId } = req.params;
    const { limit = 50, page = 1 } = req.query;
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Board items retrieval requested', {
      userId,
      boardId,
      limit,
      page
    });

    const result = await mondayService.getBoardItems(accessToken, boardId, {
      limit: parseInt(limit),
      page: parseInt(page)
    });

    res.status(200).json({
      status: 'success',
      data: {
        boardId: boardId,
        items: result.items.map(item => ({
          id: item.id,
          name: item.name,
          state: item.state,
          groupId: item.group?.id,
          groupTitle: item.group?.title,
          columnValues: item.column_values?.reduce((acc, cv) => {
            acc[cv.id] = {
              id: cv.id,
              title: cv.title,
              value: cv.value,
              text: cv.text,
              type: cv.type
            };
            return acc;
          }, {}) || {},
          createdAt: item.created_at,
          updatedAt: item.updated_at
        })),
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: result.total,
          totalPages: Math.ceil(result.total / parseInt(limit)),
          hasMore: result.hasMore
        }
      }
    });

  } catch (error) {
    logger.error('Error fetching board items:', error);
    
    if (error.response && error.response.status === 404) {
      return next(createError(404, 'Board not found', 'BOARD_NOT_FOUND'));
    }
    
    next(createError(500, 'Failed to fetch board items', 'BOARD_ITEMS_FETCH_FAILED'));
  }
};

/**
 * Create a new item in a Monday.com board
 * POST /api/monday/boards/:boardId/items
 */
const createBoardItem = async (req, res, next) => {
  try {
    const { boardId } = req.params;
    const { name, columnValues, groupId } = req.body;
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Board item creation requested', {
      userId,
      boardId,
      itemName: name,
      groupId
    });

    const newItem = await mondayService.createBoardItem(accessToken, boardId, {
      name,
      columnValues,
      groupId
    });

    res.status(201).json({
      status: 'success',
      message: 'Item created successfully',
      data: {
        id: newItem.id,
        name: newItem.name,
        boardId: boardId,
        groupId: newItem.group?.id,
        columnValues: newItem.column_values?.reduce((acc, cv) => {
          acc[cv.id] = {
            id: cv.id,
            title: cv.title,
            value: cv.value,
            text: cv.text
          };
          return acc;
        }, {}) || {},
        createdAt: new Date().toISOString()
      }
    });

  } catch (error) {
    logger.error('Error creating board item:', error);
    
    if (error.response && error.response.status === 404) {
      return next(createError(404, 'Board not found', 'BOARD_NOT_FOUND'));
    }
    
    next(createError(500, 'Failed to create board item', 'BOARD_ITEM_CREATE_FAILED'));
  }
};

// ==============================================
// ITEM OPERATIONS
// ==============================================

/**
 * Update a Monday.com item with barcode information
 * PUT /api/monday/items/:itemId
 */
const updateItem = async (req, res, next) => {
  try {
    const { itemId } = req.params;
    const { columnValues } = req.body;
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Item update requested', {
      userId,
      itemId,
      columnsToUpdate: Object.keys(columnValues || {})
    });

    const updatedItem = await mondayService.updateItem(accessToken, itemId, columnValues);

    res.status(200).json({
      status: 'success',
      message: 'Item updated successfully',
      data: {
        id: updatedItem.id,
        name: updatedItem.name,
        columnValues: updatedItem.column_values?.reduce((acc, cv) => {
          acc[cv.id] = {
            id: cv.id,
            title: cv.title,
            value: cv.value,
            text: cv.text
          };
          return acc;
        }, {}) || {},
        updatedAt: new Date().toISOString()
      }
    });

  } catch (error) {
    logger.error('Error updating item:', error);
    
    if (error.response && error.response.status === 404) {
      return next(createError(404, 'Item not found', 'ITEM_NOT_FOUND'));
    }
    
    next(createError(500, 'Failed to update item', 'ITEM_UPDATE_FAILED'));
  }
};

/**
 * Get columns for a specific Monday.com board
 * GET /api/monday/columns/:boardId
 */
const getBoardColumns = async (req, res, next) => {
  try {
    const { boardId } = req.params;
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Board columns retrieval requested', { userId, boardId });

    const columns = await mondayService.getBoardColumns(accessToken, boardId);

    res.status(200).json({
      status: 'success',
      data: {
        boardId: boardId,
        columns: columns.map(column => ({
          id: column.id,
          title: column.title,
          type: column.type,
          description: column.description,
          settings_str: column.settings_str,
          archived: column.archived
        }))
      }
    });

  } catch (error) {
    logger.error('Error fetching board columns:', error);
    
    if (error.response && error.response.status === 404) {
      return next(createError(404, 'Board not found', 'BOARD_NOT_FOUND'));
    }
    
    next(createError(500, 'Failed to fetch board columns', 'BOARD_COLUMNS_FETCH_FAILED'));
  }
};

// ==============================================
// ADVANCED OPERATIONS
// ==============================================

/**
 * Get item details by ID
 * GET /api/monday/items/:itemId
 */
const getItemById = async (req, res, next) => {
  try {
    const { itemId } = req.params;
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Item details retrieval requested', { userId, itemId });

    const item = await mondayService.getItemById(accessToken, itemId);

    if (!item) {
      return next(createError(404, 'Item not found', 'ITEM_NOT_FOUND'));
    }

    res.status(200).json({
      status: 'success',
      data: {
        id: item.id,
        name: item.name,
        state: item.state,
        boardId: item.board?.id,
        boardName: item.board?.name,
        groupId: item.group?.id,
        groupTitle: item.group?.title,
        columnValues: item.column_values?.reduce((acc, cv) => {
          acc[cv.id] = {
            id: cv.id,
            title: cv.title,
            value: cv.value,
            text: cv.text,
            type: cv.type
          };
          return acc;
        }, {}) || {},
        subitems: item.subitems?.map(subitem => ({
          id: subitem.id,
          name: subitem.name,
          columnValues: subitem.column_values?.reduce((acc, cv) => {
            acc[cv.id] = {
              id: cv.id,
              title: cv.title,
              value: cv.value,
              text: cv.text
            };
            return acc;
          }, {}) || {}
        })) || [],
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }
    });

  } catch (error) {
    logger.error('Error fetching item details:', error);
    next(createError(500, 'Failed to fetch item details', 'ITEM_FETCH_FAILED'));
  }
};

/**
 * Search items across boards
 * GET /api/monday/search
 */
const searchItems = async (req, res, next) => {
  try {
    const { query, boardIds, limit = 50 } = req.query;
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Item search requested', {
      userId,
      query: query ? query.substring(0, 50) : null,
      boardIds,
      limit
    });

    const searchResults = await mondayService.searchItems(accessToken, {
      query,
      boardIds: boardIds ? boardIds.split(',') : undefined,
      limit: parseInt(limit)
    });

    res.status(200).json({
      status: 'success',
      data: {
        query: query,
        results: searchResults.items.map(item => ({
          id: item.id,
          name: item.name,
          boardId: item.board?.id,
          boardName: item.board?.name,
          groupId: item.group?.id,
          groupTitle: item.group?.title,
          relevanceScore: item.relevanceScore,
          matchedFields: item.matchedFields
        })),
        total: searchResults.total,
        executionTime: searchResults.executionTime
      }
    });

  } catch (error) {
    logger.error('Error searching items:', error);
    next(createError(500, 'Failed to search items', 'ITEM_SEARCH_FAILED'));
  }
};

// ==============================================
// BATCH OPERATIONS
// ==============================================

/**
 * Batch update multiple items
 * PUT /api/monday/items/batch
 */
const batchUpdateItems = async (req, res, next) => {
  try {
    const { updates } = req.body;
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Batch item update requested', {
      userId,
      updateCount: updates.length
    });

    const results = await mondayService.batchUpdateItems(accessToken, updates);

    res.status(200).json({
      status: 'success',
      message: `Batch update completed. ${results.successful} successful, ${results.failed} failed.`,
      data: {
        total: updates.length,
        successful: results.successful,
        failed: results.failed,
        results: results.details,
        processedAt: new Date().toISOString()
      }
    });

  } catch (error) {
    logger.error('Error in batch item update:', error);
    next(createError(500, 'Failed to batch update items', 'BATCH_UPDATE_FAILED'));
  }
};

// ==============================================
// WORKSPACE & USER INFO
// ==============================================

/**
 * Get current user's Monday.com information
 * GET /api/monday/me
 */
const getCurrentUser = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('User info retrieval requested', { userId });

    const userInfo = await mondayService.getCurrentUser(accessToken);

    res.status(200).json({
      status: 'success',
      data: {
        id: userInfo.id,
        name: userInfo.name,
        email: userInfo.email,
        photo_original: userInfo.photo_original,
        photo_small: userInfo.photo_small,
        enabled: userInfo.enabled,
        is_admin: userInfo.is_admin,
        is_guest: userInfo.is_guest,
        account: userInfo.account ? {
          id: userInfo.account.id,
          name: userInfo.account.name,
          slug: userInfo.account.slug,
          plan: userInfo.account.plan
        } : null
      }
    });

  } catch (error) {
    logger.error('Error fetching user info:', error);
    next(createError(500, 'Failed to fetch user information', 'USER_INFO_FETCH_FAILED'));
  }
};

/**
 * Get workspace information
 * GET /api/monday/workspace
 */
const getWorkspace = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const accessToken = req.user.accessToken;

    logger.info('Workspace info retrieval requested', { userId });

    const workspace = await mondayService.getWorkspace(accessToken);

    res.status(200).json({
      status: 'success',
      data: {
        account: workspace.account,
        users: workspace.users?.map(user => ({
          id: user.id,
          name: user.name,
          email: user.email,
          enabled: user.enabled,
          is_admin: user.is_admin
        })) || [],
        teams: workspace.teams?.map(team => ({
          id: team.id,
          name: team.name,
          users: team.users?.map(u => u.id) || []
        })) || []
      }
    });

  } catch (error) {
    logger.error('Error fetching workspace info:', error);
    next(createError(500, 'Failed to fetch workspace information', 'WORKSPACE_INFO_FETCH_FAILED'));
  }
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  getBoards,
  getBoardItems,
  createBoardItem,
  updateItem,
  getBoardColumns,
  getItemById,
  searchItems,
  batchUpdateItems,
  getCurrentUser,
  getWorkspace
}; 