/**
 * Logger Configuration
 * 
 * This file configures Winston logger with multiple transports,
 * log levels, and formatting for the Monday.com Barcode Generator app.
 */

const winston = require('winston');
const path = require('path');

// Define log levels and colors
const levels = {
  error: 0,
  warn: 1,
  info: 2,
  http: 3,
  debug: 4,
};

const colors = {
  error: 'red',
  warn: 'yellow',
  info: 'green',
  http: 'magenta',
  debug: 'white',
};

winston.addColors(colors);

// Determine log level based on environment
const level = () => {
  const env = process.env.NODE_ENV || 'development';
  const isDevelopment = env === 'development';
  return isDevelopment ? 'debug' : 'warn';
};

// Create logs directory if it doesn't exist
const fs = require('fs');
const logsDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Define custom formats
const customFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss:ms' }),
  winston.format.colorize({ all: true }),
  winston.format.printf(
    (info) => `${info.timestamp} ${info.level}: ${info.message}`
  )
);

const fileFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss:ms' }),
  winston.format.errors({ stack: true }),
  winston.format.json()
);

// Define transports
const transports = [
  // Console transport for development
  new winston.transports.Console({
    level: level(),
    format: customFormat,
  }),
  
  // File transport for errors
  new winston.transports.File({
    filename: path.join(logsDir, 'error.log'),
    level: 'error',
    format: fileFormat,
    maxsize: 5242880, // 5MB
    maxFiles: 5,
  }),
  
  // File transport for all logs
  new winston.transports.File({
    filename: path.join(logsDir, 'combined.log'),
    format: fileFormat,
    maxsize: 5242880, // 5MB
    maxFiles: 5,
  }),
];

// Add HTTP log transport in production
if (process.env.NODE_ENV === 'production') {
  transports.push(
    new winston.transports.File({
      filename: path.join(logsDir, 'http.log'),
      level: 'http',
      format: fileFormat,
      maxsize: 5242880, // 5MB
      maxFiles: 3,
    })
  );
}

// Create the logger
const logger = winston.createLogger({
  level: level(),
  levels,
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports,
  exceptionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, 'exceptions.log'),
      format: fileFormat,
    }),
  ],
  rejectionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, 'rejections.log'),
      format: fileFormat,
    }),
  ],
  exitOnError: false,
});

// Helper functions for structured logging

/**
 * Log user activity
 */
const logUserActivity = (userId, action, details = {}) => {
  logger.info('User activity', {
    type: 'USER_ACTIVITY',
    userId: userId,
    action: action,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log API requests
 */
const logAPIRequest = (method, url, statusCode, responseTime, userId = null) => {
  logger.http('API Request', {
    type: 'API_REQUEST',
    method: method,
    url: url,
    statusCode: statusCode,
    responseTime: `${responseTime}ms`,
    userId: userId,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log Monday.com API interactions
 */
const logMondayAPI = (operation, success, details = {}) => {
  const logLevel = success ? 'info' : 'error';
  logger.log(logLevel, 'Monday.com API interaction', {
    type: 'MONDAY_API',
    operation: operation,
    success: success,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log barcode operations
 */
const logBarcodeOperation = (operation, userId, details = {}) => {
  logger.info('Barcode operation', {
    type: 'BARCODE_OPERATION',
    operation: operation,
    userId: userId,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log security events
 */
const logSecurityEvent = (event, severity, details = {}) => {
  const logLevel = severity === 'high' ? 'error' : severity === 'medium' ? 'warn' : 'info';
  logger.log(logLevel, 'Security event', {
    type: 'SECURITY_EVENT',
    event: event,
    severity: severity,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log performance metrics
 */
const logPerformance = (operation, duration, details = {}) => {
  logger.info('Performance metric', {
    type: 'PERFORMANCE',
    operation: operation,
    duration: `${duration}ms`,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log errors with additional context
 */
const logError = (error, context = {}) => {
  logger.error('Application Error', {
    type: 'APPLICATION_ERROR',
    message: error.message,
    stack: error.stack,
    context: context,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log webhook events
 */
const logWebhook = (event, source, success, details = {}) => {
  const logLevel = success ? 'info' : 'error';
  logger.log(logLevel, 'Webhook event', {
    type: 'WEBHOOK_EVENT',
    event: event,
    source: source,
    success: success,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log rate limiting events
 */
const logRateLimit = (identifier, action, details = {}) => {
  logger.warn('Rate limit event', {
    type: 'RATE_LIMIT',
    identifier: identifier,
    action: action,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Create child logger with persistent metadata
 */
const createChildLogger = (metadata = {}) => {
  return logger.child(metadata);
};

/**
 * Log application startup
 */
const logAppStartup = (port, environment) => {
  logger.info('Application startup', {
    type: 'APP_STARTUP',
    port: port,
    environment: environment,
    nodeVersion: process.version,
    pid: process.pid,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log application shutdown
 */
const logAppShutdown = (reason = 'Normal shutdown') => {
  logger.info('Application shutdown', {
    type: 'APP_SHUTDOWN',
    reason: reason,
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
};

/**
 * Log database operations (for future use)
 */
const logDatabaseOperation = (operation, table, success, duration, details = {}) => {
  const logLevel = success ? 'debug' : 'error';
  logger.log(logLevel, 'Database operation', {
    type: 'DATABASE_OPERATION',
    operation: operation,
    table: table,
    success: success,
    duration: `${duration}ms`,
    details: details,
    timestamp: new Date().toISOString(),
  });
};

/**
 * Sanitize sensitive data from logs
 */
const sanitizeLogData = (data) => {
  const sensitiveFields = [
    'password',
    'token',
    'accessToken',
    'refreshToken',
    'apiKey',
    'secret',
    'authorization',
    'cookie',
    'session'
  ];

  if (typeof data !== 'object' || data === null) {
    return data;
  }

  const sanitized = { ...data };

  const sanitizeRecursive = (obj, path = '') => {
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        const currentPath = path ? `${path}.${key}` : key;
        
        if (sensitiveFields.some(field => key.toLowerCase().includes(field.toLowerCase()))) {
          obj[key] = '[REDACTED]';
        } else if (typeof obj[key] === 'object' && obj[key] !== null && !Array.isArray(obj[key])) {
          sanitizeRecursive(obj[key], currentPath);
        } else if (Array.isArray(obj[key])) {
          obj[key] = obj[key].map((item, index) => {
            if (typeof item === 'object' && item !== null) {
              const itemCopy = { ...item };
              sanitizeRecursive(itemCopy, `${currentPath}[${index}]`);
              return itemCopy;
            }
            return item;
          });
        }
      }
    }
  };

  sanitizeRecursive(sanitized);
  return sanitized;
};

// Middleware for Express request logging
const requestLoggingMiddleware = (req, res, next) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    const userId = req.user ? req.user.id : null;
    
    logAPIRequest(
      req.method,
      req.originalUrl,
      res.statusCode,
      duration,
      userId
    );
  });
  
  next();
};

// Stream for Morgan HTTP logging
const morganStream = {
  write: (message) => {
    logger.http(message.trim());
  },
};

module.exports = logger;

// Export helper functions
module.exports.logUserActivity = logUserActivity;
module.exports.logAPIRequest = logAPIRequest;
module.exports.logMondayAPI = logMondayAPI;
module.exports.logBarcodeOperation = logBarcodeOperation;
module.exports.logSecurityEvent = logSecurityEvent;
module.exports.logPerformance = logPerformance;
module.exports.logError = logError;
module.exports.logWebhook = logWebhook;
module.exports.logRateLimit = logRateLimit;
module.exports.createChildLogger = createChildLogger;
module.exports.logAppStartup = logAppStartup;
module.exports.logAppShutdown = logAppShutdown;
module.exports.logDatabaseOperation = logDatabaseOperation;
module.exports.sanitizeLogData = sanitizeLogData;
module.exports.requestLoggingMiddleware = requestLoggingMiddleware;
module.exports.morganStream = morganStream; 