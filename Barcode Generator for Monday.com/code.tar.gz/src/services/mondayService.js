/**
 * Monday.com Service
 * 
 * This file contains service functions for interacting with the Monday.com API,
 * including GraphQL queries, authentication, and data transformations.
 */

const axios = require('axios');
const logger = require('../utils/logger');

// Monday.com API configuration
const MONDAY_API_URL = 'https://api.monday.com/v2';
const MONDAY_AUTH_URL = 'https://auth.monday.com/oauth2/token';

// ==============================================
// AUTHENTICATION SERVICES
// ==============================================

/**
 * Exchange authorization code for access tokens
 */
const exchangeCodeForTokens = async (code) => {
  try {
    const response = await axios.post(MONDAY_AUTH_URL, {
      client_id: process.env.MONDAY_CLIENT_ID,
      client_secret: process.env.MONDAY_CLIENT_SECRET,
      redirect_uri: process.env.MONDAY_REDIRECT_URI || 'http://localhost:3000/auth/monday/callback',
      grant_type: 'authorization_code',
      code: code
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    logger.info('Token exchange successful');
    return response.data;

  } catch (error) {
    logger.error('Error exchanging code for tokens:', error.response?.data || error.message);
    throw new Error('Failed to exchange authorization code for tokens');
  }
};

/**
 * Refresh access token using refresh token
 */
const refreshAccessToken = async (refreshToken) => {
  try {
    const response = await axios.post(MONDAY_AUTH_URL, {
      client_id: process.env.MONDAY_CLIENT_ID,
      client_secret: process.env.MONDAY_CLIENT_SECRET,
      grant_type: 'refresh_token',
      refresh_token: refreshToken
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    logger.info('Token refresh successful');
    return response.data;

  } catch (error) {
    logger.error('Error refreshing access token:', error.response?.data || error.message);
    throw new Error('Failed to refresh access token');
  }
};

// ==============================================
// GRAPHQL QUERY HELPERS
// ==============================================

/**
 * Execute GraphQL query against Monday.com API
 */
const executeGraphQLQuery = async (accessToken, query, variables = {}) => {
  try {
    const response = await axios.post(MONDAY_API_URL, {
      query: query,
      variables: variables
    }, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'API-Version': '2025-07'
      },
      timeout: 10000
    });

    if (response.data.errors) {
      logger.error('Monday.com GraphQL errors:', response.data.errors);
      throw new Error(`GraphQL errors: ${response.data.errors.map(e => e.message).join(', ')}`);
    }

    return response.data.data;

  } catch (error) {
    if (error.response) {
      logger.error('Monday.com API error:', {
        status: error.response.status,
        data: error.response.data
      });
    } else {
      logger.error('Monday.com API request error:', error.message);
    }
    throw error;
  }
};

// ==============================================
// USER SERVICES
// ==============================================

/**
 * Get current user information
 */
const getCurrentUser = async (accessToken) => {
  const query = `
    query {
      me {
        id
        name
        email
        photo_original
        photo_small
        enabled
        is_admin
        is_guest
        account {
          id
          name
          slug
          plan {
            max_users
            period
            tier
            version
          }
        }
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, query);
    return data.me;
  } catch (error) {
    logger.error('Error fetching current user:', error);
    throw error;
  }
};

/**
 * Test API connection
 */
const testApiConnection = async (accessToken) => {
  const startTime = Date.now();
  
  try {
    const user = await getCurrentUser(accessToken);
    const responseTime = Date.now() - startTime;

    return {
      connected: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      },
      responseTime: responseTime
    };
  } catch (error) {
    return {
      connected: false,
      error: error.message,
      responseTime: Date.now() - startTime
    };
  }
};

// ==============================================
// BOARD SERVICES
// ==============================================

/**
 * Get user's boards
 */
const getUserBoards = async (accessToken, options = {}) => {
  const { limit = 50, page = 1 } = options;
  
  const query = `
    query GetBoards($limit: Int, $page: Int) {
      boards(limit: $limit, page: $page, order_by: created_at) {
        id
        name
        description
        state
        created_at
        updated_at
        columns {
          id
          title
          type
          description
          settings_str
          archived
        }
        groups {
          id
          title
          color
          archived
        }
        items_count
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, query, { limit, page });
    return data.boards || [];
  } catch (error) {
    logger.error('Error fetching user boards:', error);
    throw error;
  }
};

/**
 * Get board columns
 */
const getBoardColumns = async (accessToken, boardId) => {
  const query = `
    query GetBoardColumns($boardId: [ID!]) {
      boards(ids: $boardId) {
        columns {
          id
          title
          type
          description
          settings_str
          archived
        }
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, query, { boardId: [boardId] });
    return data.boards[0]?.columns || [];
  } catch (error) {
    logger.error('Error fetching board columns:', error);
    throw error;
  }
};

// ==============================================
// ITEM SERVICES
// ==============================================

/**
 * Get board items
 */
const getBoardItems = async (accessToken, boardId, options = {}) => {
  const { limit = 50, page = 1 } = options;
  
  const query = `
    query GetBoardItems($boardId: [ID!], $limit: Int, $page: Int) {
      boards(ids: $boardId) {
        items_page(limit: $limit, page: $page) {
          cursor
          items {
            id
            name
            state
            created_at
            updated_at
            group {
              id
              title
              color
            }
            column_values {
              id
              title
              value
              text
              type
            }
          }
        }
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, query, { 
      boardId: [boardId], 
      limit, 
      page 
    });
    
    const board = data.boards[0];
    if (!board) {
      throw new Error('Board not found');
    }

    const itemsPage = board.items_page;
    return {
      items: itemsPage.items || [],
      cursor: itemsPage.cursor,
      total: itemsPage.items?.length || 0,
      hasMore: itemsPage.items?.length === limit
    };
  } catch (error) {
    logger.error('Error fetching board items:', error);
    throw error;
  }
};

/**
 * Get item by ID
 */
const getItemById = async (accessToken, itemId) => {
  const query = `
    query GetItem($itemId: [ID!]) {
      items(ids: $itemId) {
        id
        name
        state
        created_at
        updated_at
        board {
          id
          name
        }
        group {
          id
          title
          color
        }
        column_values {
          id
          title
          value
          text
          type
        }
        subitems {
          id
          name
          column_values {
            id
            title
            value
            text
            type
          }
        }
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, query, { itemId: [itemId] });
    return data.items[0] || null;
  } catch (error) {
    logger.error('Error fetching item:', error);
    throw error;
  }
};

/**
 * Create board item
 */
const createBoardItem = async (accessToken, boardId, itemData) => {
  const { name, columnValues = {}, groupId } = itemData;
  
  const mutation = `
    mutation CreateItem($boardId: ID!, $itemName: String!, $columnValues: JSON, $groupId: String) {
      create_item(
        board_id: $boardId
        item_name: $itemName
        column_values: $columnValues
        group_id: $groupId
      ) {
        id
        name
        group {
          id
          title
        }
        column_values {
          id
          title
          value
          text
          type
        }
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, mutation, {
      boardId,
      itemName: name,
      columnValues: JSON.stringify(columnValues),
      groupId
    });
    
    return data.create_item;
  } catch (error) {
    logger.error('Error creating board item:', error);
    throw error;
  }
};

/**
 * Update item column values
 */
const updateItem = async (accessToken, itemId, columnValues) => {
  const mutation = `
    mutation UpdateItem($itemId: ID!, $columnValues: JSON!) {
      change_multiple_column_values(
        item_id: $itemId
        column_values: $columnValues
      ) {
        id
        name
        column_values {
          id
          title
          value
          text
          type
        }
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, mutation, {
      itemId,
      columnValues: JSON.stringify(columnValues)
    });
    
    return data.change_multiple_column_values;
  } catch (error) {
    logger.error('Error updating item:', error);
    throw error;
  }
};

// ==============================================
// SEARCH SERVICES
// ==============================================

/**
 * Search items across boards
 */
const searchItems = async (accessToken, searchOptions) => {
  const { query, boardIds, limit = 50 } = searchOptions;
  
  const graphqlQuery = `
    query SearchItems($query: String!, $limit: Int, $boardIds: [ID]) {
      items_page_by_column_values(
        limit: $limit
        column_id: "name"
        column_value: $query
        board_ids: $boardIds
      ) {
        cursor
        items {
          id
          name
          board {
            id
            name
          }
          group {
            id
            title
          }
          column_values {
            id
            title
            value
            text
          }
        }
      }
    }
  `;

  try {
    const startTime = Date.now();
    const data = await executeGraphQLQuery(accessToken, graphqlQuery, {
      query,
      limit,
      boardIds
    });
    
    const executionTime = Date.now() - startTime;
    const itemsPage = data.items_page_by_column_values;

    return {
      items: itemsPage.items || [],
      total: itemsPage.items?.length || 0,
      executionTime
    };
  } catch (error) {
    logger.error('Error searching items:', error);
    throw error;
  }
};

// ==============================================
// BATCH OPERATIONS
// ==============================================

/**
 * Batch update multiple items
 */
const batchUpdateItems = async (accessToken, updates) => {
  const results = {
    successful: 0,
    failed: 0,
    details: []
  };

  // Process updates in batches of 10 to avoid rate limits
  const batchSize = 10;
  for (let i = 0; i < updates.length; i += batchSize) {
    const batch = updates.slice(i, i + batchSize);
    
    await Promise.all(batch.map(async (update) => {
      try {
        const { itemId, columnValues } = update;
        await updateItem(accessToken, itemId, columnValues);
        
        results.successful++;
        results.details.push({
          itemId,
          status: 'success'
        });
      } catch (error) {
        results.failed++;
        results.details.push({
          itemId: update.itemId,
          status: 'failed',
          error: error.message
        });
      }
    }));

    // Add delay between batches to respect rate limits
    if (i + batchSize < updates.length) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  return results;
};

// ==============================================
// WORKSPACE SERVICES
// ==============================================

/**
 * Get workspace information
 */
const getWorkspace = async (accessToken) => {
  const query = `
    query GetWorkspace {
      account {
        id
        name
        slug
        plan {
          max_users
          period
          tier
          version
        }
      }
      users {
        id
        name
        email
        enabled
        is_admin
        is_guest
      }
      teams {
        id
        name
        users {
          id
          name
        }
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, query);
    return data;
  } catch (error) {
    logger.error('Error fetching workspace info:', error);
    throw error;
  }
};

// ==============================================
// WEBHOOK SERVICES
// ==============================================

/**
 * Create webhook subscription
 */
const createWebhook = async (accessToken, webhookData) => {
  const { boardId, url, event } = webhookData;
  
  const mutation = `
    mutation CreateWebhook($boardId: ID!, $url: String!, $event: WebhookEventType!) {
      create_webhook(
        board_id: $boardId
        url: $url
        event: $event
      ) {
        id
        board_id
        config
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, mutation, {
      boardId,
      url,
      event
    });
    
    return data.create_webhook;
  } catch (error) {
    logger.error('Error creating webhook:', error);
    throw error;
  }
};

/**
 * Delete webhook subscription
 */
const deleteWebhook = async (accessToken, webhookId) => {
  const mutation = `
    mutation DeleteWebhook($webhookId: ID!) {
      delete_webhook(id: $webhookId) {
        id
      }
    }
  `;

  try {
    const data = await executeGraphQLQuery(accessToken, mutation, { webhookId });
    return data.delete_webhook;
  } catch (error) {
    logger.error('Error deleting webhook:', error);
    throw error;
  }
};

// ==============================================
// RATE LIMITING HELPERS
// ==============================================

/**
 * Sleep function for rate limiting
 */
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Execute request with retry logic
 */
const executeWithRetry = async (fn, maxRetries = 3, delay = 1000) => {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxRetries) {
        throw error;
      }

      // Check if it's a rate limit error
      if (error.response && error.response.status === 429) {
        const retryAfter = error.response.headers['retry-after'];
        const waitTime = retryAfter ? parseInt(retryAfter) * 1000 : delay * attempt;
        
        logger.warn(`Rate limit hit, retrying in ${waitTime}ms (attempt ${attempt}/${maxRetries})`);
        await sleep(waitTime);
      } else {
        await sleep(delay * attempt);
      }
    }
  }
};

/**
 * Upload file to a Monday.com file column
 * Uses the add_file_to_column mutation as per Monday.com API documentation
 * @param {string} itemId - The item ID to attach the file to  
 * @param {string} columnId - The file column ID
 * @param {Buffer} fileBuffer - The file data as a buffer
 * @param {string} filename - The filename
 * @param {string} mimeType - The MIME type of the file
 * @param {string} accessToken - Monday.com access token
 * @returns {Object} Upload result with file information
 */
const uploadFileToColumn = async (itemId, columnId, fileBuffer, filename, mimeType, accessToken) => {
  try {
    logger.mondayApi('upload_file_start', { itemId, columnId, filename, fileSize: fileBuffer.length });

    // Use the correct Monday.com API approach with add_file_to_column
    // Reference: https://developer.monday.com/api-reference/reference/files-1
    const FormData = require('form-data');
    const { Readable } = require('stream');
    
    const form = new FormData();
    
    // Create a readable stream from the buffer for proper file upload
    const fileStream = new Readable();
    fileStream.push(fileBuffer);
    fileStream.push(null); // End the stream
    
    // Add the GraphQL mutation query (EXACTLY as shown in Monday.com docs)
    form.append('query', 'mutation($item_id: ID!, $column_id: String!, $file: File!) { add_file_to_column(item_id: $item_id, column_id: $column_id, file: $file) { id } }');
    
    // Add variables (EXACTLY as shown in Monday.com docs)
    form.append('variables', JSON.stringify({
      item_id: parseInt(itemId),
      column_id: columnId
    }));
    
    // Add the file mapping (EXACTLY as shown in Monday.com docs)
    form.append('map', '{"file":"variables.file"}');
    
    // Add the actual file data (key must match the map - "file" not "image")
    form.append('file', fileStream, {
      filename: filename,
      contentType: mimeType,
      knownLength: fileBuffer.length
    });

    logger.mondayApi('file_upload_request', {
      itemId: parseInt(itemId),
      columnId,
      filename,
      fileSize: fileBuffer.length,
      mimeType
    });

    const uploadResponse = await axios.post(
      'https://api.monday.com/v2/file',
      form,
      {
        headers: {
          ...form.getHeaders(),
          'Authorization': accessToken.startsWith('Bearer ') ? accessToken : `Bearer ${accessToken}`,
          'API-Version': '2025-07'
        },
        timeout: 30000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity
      }
    );

    logger.mondayApi('file_upload_response', { 
      success: !uploadResponse.data.errors,
      hasData: !!uploadResponse.data.data
    });

    if (uploadResponse.data.errors) {
      logger.error('Monday.com file upload failed', { errors: uploadResponse.data.errors });
      throw new Error(`Monday.com file upload failed: ${JSON.stringify(uploadResponse.data.errors)}`);
    }

    if (!uploadResponse.data || !uploadResponse.data.data || !uploadResponse.data.data.add_file_to_column) {
      logger.error('Unexpected response structure from Monday.com', { response: uploadResponse.data });
      throw new Error('Unexpected response structure from Monday.com file upload');
    }

    const result = uploadResponse.data.data.add_file_to_column;
    
    logger.mondayApi('upload_file_success', { 
      itemId, 
      columnId, 
      filename, 
      uploadId: result.id 
    });

    return {
      success: true,
      id: result.id,
      filename: filename,
      itemId: itemId,
      columnId: columnId
    };

  } catch (error) {
    logger.error('Error uploading file to Monday.com column:', {
      itemId,
      columnId,
      filename,
      error: error.message,
      stack: error.stack,
      response: error.response?.data
    });

    if (process.env.NODE_ENV === 'development') {
      console.log('File upload error details:', {
        message: error.message,
        status: error.response?.status
      });
    }

    throw new Error(`Failed to upload file to Monday.com: ${error.message}`);
  }
};

// ==============================================
// UTILITY FUNCTIONS
// ==============================================

/**
 * Format Monday.com date string
 */
const formatMondayDate = (dateString) => {
  if (!dateString) return null;
  try {
    return new Date(dateString).toISOString();
  } catch (error) {
    logger.warn('Invalid date string:', dateString);
    return null;
  }
};

/**
 * Parse Monday.com column value based on type
 */
const parseColumnValue = (columnValue) => {
  const { type, value, text } = columnValue;
  
  switch (type) {
    case 'date':
      return formatMondayDate(value);
    case 'numeric':
      return value ? parseFloat(value) : null;
    case 'checkbox':
      return value === 'true';
    case 'status':
    case 'dropdown':
      return text || value;
    default:
      return text || value;
  }
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  // Authentication
  exchangeCodeForTokens,
  refreshAccessToken,
  
  // GraphQL helpers
  executeGraphQLQuery,
  
  // User services
  getCurrentUser,
  testApiConnection,
  
  // Board services
  getUserBoards,
  getBoardColumns,
  
  // Item services
  getBoardItems,
  getItemById,
  createBoardItem,
  updateItem,
  
  // Search services
  searchItems,
  
  // Batch operations
  batchUpdateItems,
  
  // Workspace services
  getWorkspace,
  
  // File services
  uploadFileToColumn,
  
  // Webhook services
  createWebhook,
  deleteWebhook,
  
  // Utilities
  executeWithRetry,
  formatMondayDate,
  parseColumnValue
}; 