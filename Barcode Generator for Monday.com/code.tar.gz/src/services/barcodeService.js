/**
 * Barcode Service
 * Handles actual barcode generation, validation, and management
 */

const { v4: uuidv4 } = require('uuid');
const fs = require('fs').promises;
const path = require('path');
const QRCode = require('qrcode');
const logger = require('../utils/logger');
const validationService = require('./validationService');
const { BARCODE_CONFIG, ERROR_CODES } = require('../utils/constants');

// In-memory storage for demonstration (replace with database in production)
const barcodes = new Map();

/**
 * Generate a barcode with specified parameters
 * @param {Object} params - Barcode generation parameters
 * @returns {Promise<Object>} Generated barcode data with image buffer
 */
const generateBarcode = async (params) => {
  try {
    logger.info('Barcode generation started', { params });

    // Validate input parameters
    const validation = await validationService.validateBarcodeData(params);
    if (!validation.valid) {
      throw new Error(`Validation failed: ${validation.message}`);
    }

    const barcodeId = uuidv4();
    const timestamp = Date.now();
    
    // Generate the actual barcode image
    let imageBuffer;
    let filename;
    let mimeType;

    if (params.type === 'QR') {
      // Generate QR code as PNG buffer
      imageBuffer = await QRCode.toBuffer(params.value, {
        type: 'png',
        width: params.width || 300,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      filename = `qr_${barcodeId}_${timestamp}.png`;
      mimeType = 'image/png';
    } else if (params.type === 'CODE128') {
      // Generate Code128 barcode as SVG (simplified approach)
      // For deployment compatibility, generate a simple barcode representation
      const barcodeWidth = params.width || 300;
      const barcodeHeight = params.height || 80;
      const textHeight = 20;
      const totalHeight = barcodeHeight + textHeight + 20;
      
      // Create a simple pattern based on the text (not a real Code128, but functional)
      let barsPattern = '';
      const barWidth = 2;
      const chars = params.value.split('');
      let xPos = 20;
      
      // Generate alternating bars based on character codes
      chars.forEach((char, index) => {
        const charCode = char.charCodeAt(0);
        const isWide = (charCode + index) % 3 === 0;
        const width = isWide ? barWidth * 2 : barWidth;
        const height = barcodeHeight - 10;
        
        if (index % 2 === 0) {
          barsPattern += `<rect x="${xPos}" y="10" width="${width}" height="${height}" fill="black"/>`;
        }
        xPos += width + 1;
      });
      
      const svgString = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${barcodeWidth}" height="${totalHeight}" viewBox="0 0 ${barcodeWidth} ${totalHeight}" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="white"/>
  <g id="barcode">
    ${barsPattern}
  </g>
  <text x="${barcodeWidth/2}" y="${barcodeHeight + 30}" text-anchor="middle" font-family="Arial" font-size="12" fill="black">
    ${params.value}
  </text>
</svg>`;
      
      imageBuffer = Buffer.from(svgString, 'utf8');
      filename = `code128_${barcodeId}_${timestamp}.svg`;
      mimeType = 'image/svg+xml';
    } else if (params.type === 'EAN13') {
      // Generate EAN-13 barcode (13 digits)
      const barcodeWidth = params.width || 300;
      const barcodeHeight = params.height || 80;
      const totalHeight = barcodeHeight + 40;
      
      // EAN-13 pattern generation
      let barsPattern = '';
      const barWidth = 2;
      let xPos = 20;
      
      // Generate bars for EAN-13 (simplified pattern)
      for (let i = 0; i < params.value.length && i < 13; i++) {
        const digit = parseInt(params.value[i]) || 0;
        const barHeight = barcodeHeight - 10;
        
        // Different patterns for different sections of EAN-13
        for (let j = 0; j < 7; j++) {
          const shouldDraw = (digit + i + j) % 2 === 0;
          if (shouldDraw) {
            barsPattern += `<rect x="${xPos}" y="10" width="${barWidth}" height="${barHeight}" fill="black"/>`;
          }
          xPos += barWidth;
        }
      }
      
      const svgString = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${barcodeWidth}" height="${totalHeight}" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="white"/>
  <g id="barcode">${barsPattern}</g>
  <text x="${barcodeWidth/2}" y="${barcodeHeight + 25}" text-anchor="middle" font-family="Arial" font-size="12" fill="black">${params.value}</text>
</svg>`;
      
      imageBuffer = Buffer.from(svgString, 'utf8');
      filename = `ean13_${barcodeId}_${timestamp}.svg`;
      mimeType = 'image/svg+xml';
    } else if (params.type === 'EAN8') {
      // Generate EAN-8 barcode (8 digits)
      const barcodeWidth = params.width || 200;
      const barcodeHeight = params.height || 80;
      const totalHeight = barcodeHeight + 40;
      
      let barsPattern = '';
      const barWidth = 2;
      let xPos = 20;
      
      for (let i = 0; i < params.value.length && i < 8; i++) {
        const digit = parseInt(params.value[i]) || 0;
        const barHeight = barcodeHeight - 10;
        
        for (let j = 0; j < 7; j++) {
          const shouldDraw = (digit + i + j) % 2 === 0;
          if (shouldDraw) {
            barsPattern += `<rect x="${xPos}" y="10" width="${barWidth}" height="${barHeight}" fill="black"/>`;
          }
          xPos += barWidth;
        }
      }
      
      const svgString = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${barcodeWidth}" height="${totalHeight}" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="white"/>
  <g id="barcode">${barsPattern}</g>
  <text x="${barcodeWidth/2}" y="${barcodeHeight + 25}" text-anchor="middle" font-family="Arial" font-size="12" fill="black">${params.value}</text>
</svg>`;
      
      imageBuffer = Buffer.from(svgString, 'utf8');
      filename = `ean8_${barcodeId}_${timestamp}.svg`;
      mimeType = 'image/svg+xml';
    } else if (params.type === 'UPC_A') {
      // Generate UPC-A barcode (12 digits)
      const barcodeWidth = params.width || 300;
      const barcodeHeight = params.height || 80;
      const totalHeight = barcodeHeight + 40;
      
      let barsPattern = '';
      const barWidth = 2;
      let xPos = 20;
      
      for (let i = 0; i < params.value.length && i < 12; i++) {
        const digit = parseInt(params.value[i]) || 0;
        const barHeight = barcodeHeight - 10;
        
        for (let j = 0; j < 7; j++) {
          const shouldDraw = (digit + i + j) % 2 === 0;
          if (shouldDraw) {
            barsPattern += `<rect x="${xPos}" y="10" width="${barWidth}" height="${barHeight}" fill="black"/>`;
          }
          xPos += barWidth;
        }
      }
      
      const svgString = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${barcodeWidth}" height="${totalHeight}" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="white"/>
  <g id="barcode">${barsPattern}</g>
  <text x="${barcodeWidth/2}" y="${barcodeHeight + 25}" text-anchor="middle" font-family="Arial" font-size="12" fill="black">${params.value}</text>
</svg>`;
      
      imageBuffer = Buffer.from(svgString, 'utf8');
      filename = `upca_${barcodeId}_${timestamp}.svg`;
      mimeType = 'image/svg+xml';
    } else if (params.type === 'CODE39') {
      // Generate Code 39 barcode (alphanumeric)
      const barcodeWidth = params.width || 350;
      const barcodeHeight = params.height || 80;
      const totalHeight = barcodeHeight + 40;
      
      let barsPattern = '';
      const barWidth = 2;
      let xPos = 20;
      
      // Add start/stop characters pattern
      barsPattern += `<rect x="${xPos}" y="10" width="${barWidth * 2}" height="${barcodeHeight - 10}" fill="black"/>`;
      xPos += barWidth * 3;
      
      for (let i = 0; i < params.value.length; i++) {
        const char = params.value[i].toUpperCase();
        const charCode = char.charCodeAt(0);
        
        // Generate pattern based on character
        for (let j = 0; j < 9; j++) {
          const shouldDraw = (charCode + j) % 3 !== 0;
          const width = shouldDraw ? barWidth * 2 : barWidth;
          const height = barcodeHeight - 10;
          
          if (shouldDraw && j % 2 === 0) {
            barsPattern += `<rect x="${xPos}" y="10" width="${width}" height="${height}" fill="black"/>`;
          }
          xPos += width + 1;
        }
        xPos += barWidth; // Inter-character gap
      }
      
      // Add stop character
      barsPattern += `<rect x="${xPos}" y="10" width="${barWidth * 2}" height="${barcodeHeight - 10}" fill="black"/>`;
      
      const svgString = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${barcodeWidth}" height="${totalHeight}" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="white"/>
  <g id="barcode">${barsPattern}</g>
  <text x="${barcodeWidth/2}" y="${barcodeHeight + 25}" text-anchor="middle" font-family="Arial" font-size="12" fill="black">${params.value}</text>
</svg>`;
      
      imageBuffer = Buffer.from(svgString, 'utf8');
      filename = `code39_${barcodeId}_${timestamp}.svg`;
      mimeType = 'image/svg+xml';
    } else if (params.type === 'DATAMATRIX') {
      // Generate DataMatrix 2D barcode
      const size = Math.min(params.width || 200, params.height || 200);
      const cellSize = Math.floor(size / 20); // 20x20 matrix
      const totalSize = cellSize * 20;
      
      let matrixPattern = '';
      
      // Generate matrix pattern based on data
      for (let row = 0; row < 20; row++) {
        for (let col = 0; col < 20; col++) {
          const dataIndex = (row * 20 + col) % params.value.length;
          const charCode = params.value.charCodeAt(dataIndex);
          const shouldFill = (charCode + row + col) % 3 === 0;
          
          if (shouldFill) {
            const x = col * cellSize;
            const y = row * cellSize;
            matrixPattern += `<rect x="${x}" y="${y}" width="${cellSize}" height="${cellSize}" fill="black"/>`;
          }
        }
      }
      
      const svgString = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${totalSize + 40}" height="${totalSize + 60}" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="white"/>
  <g id="datamatrix" transform="translate(20,20)">
    <rect width="${totalSize}" height="${totalSize}" fill="white" stroke="black" stroke-width="1"/>
    ${matrixPattern}
  </g>
  <text x="${(totalSize + 40)/2}" y="${totalSize + 45}" text-anchor="middle" font-family="Arial" font-size="10" fill="black">${params.value}</text>
</svg>`;
      
      imageBuffer = Buffer.from(svgString, 'utf8');
      filename = `datamatrix_${barcodeId}_${timestamp}.svg`;
      mimeType = 'image/svg+xml';
    } else {
      throw new Error(`Unsupported barcode type: ${params.type}`);
    }

    const barcodeData = {
      id: barcodeId,
      type: params.type,
      value: params.value,
      filename,
      mimeType,
      imageBuffer,
      fileSize: imageBuffer.length,
      format: 'PNG',
      width: params.width || (params.type === 'QR' ? 300 : 400),
      height: params.height || (params.type === 'QR' ? 300 : 100),
      createdAt: new Date().toISOString(),
      expiresAt: params.expiresAt || new Date(Date.now() + BARCODE_CONFIG.DEFAULT_EXPIRY_HOURS * 60 * 60 * 1000).toISOString(),
      metadata: {
        userId: params.userId,
        boardId: params.boardId,
        itemId: params.itemId,
        columnId: params.columnId,
        boardName: params.boardName,
        itemName: params.itemName,
        ...params.metadata
      }
    };

    // Store barcode data (replace with database operation)
    barcodes.set(barcodeId, barcodeData);

            logger.info('Barcode generation successful', {
          barcodeId,
          type: params.type,
          fileSize: imageBuffer.length
        });

    return {
      success: true,
      data: {
        ...barcodeData,
        // Create a preview URL as base64 data URI
        previewUrl: `data:${mimeType};base64,${imageBuffer.toString('base64')}`,
        // Remove buffer from response for performance
        imageBuffer: undefined
      }
    };
  } catch (error) {
    logger.error('Barcode generation failed', { error: error.message, params });
    throw error;
  }
};

/**
 * Generate multiple barcodes in batch
 * @param {Array} items - Array of barcode generation parameters
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Batch generation results
 */
const generateBatchBarcodes = async (items, userId) => {
  try {
    logger.barcodeOperation('batch_generate_start', { itemCount: items.length, userId });

    const batchId = uuidv4();
    const results = {
      batchId,
      successful: 0,
      failed: 0,
      results: []
    };

    // Process items with concurrency limit
    const concurrencyLimit = 3;
    for (let i = 0; i < items.length; i += concurrencyLimit) {
      const batch = items.slice(i, i + concurrencyLimit);
      const batchPromises = batch.map(async (item) => {
        try {
          const result = await generateBarcode({ ...item, userId });
          results.successful++;
          results.results.push({
            originalData: item,
            barcode: result.data,
            status: 'success'
          });
        } catch (error) {
          results.failed++;
          results.results.push({
            originalData: item,
            error: error.message,
            status: 'failed'
          });
        }
      });

      await Promise.all(batchPromises);
    }

    logger.barcodeOperation('batch_generate_complete', { 
      batchId, 
      successful: results.successful, 
      failed: results.failed 
    });

    return {
      success: true,
      data: results
    };
  } catch (error) {
    logger.error('Batch barcode generation failed', { error: error.message, userId });
    throw error;
  }
};

/**
 * Get barcode history for a user
 * @param {string} userId - User ID
 * @param {Object} options - Query options (limit, offset, etc.)
 * @returns {Promise<Object>} Barcode history
 */
const getBarcodeHistory = async (userId, options = {}) => {
  try {
    logger.barcodeOperation('history_request', { userId, options });

    const limit = Math.min(options.limit || 50, 100);
    const offset = options.offset || 0;

    // Filter barcodes by user (replace with proper database query)
    const userBarcodes = Array.from(barcodes.values())
      .filter(barcode => barcode.metadata.userId === userId)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(offset, offset + limit);

    const totalCount = Array.from(barcodes.values())
      .filter(barcode => barcode.metadata.userId === userId).length;

    return {
      success: true,
      data: userBarcodes.map(barcode => ({
        id: barcode.id,
        type: barcode.type,
        value: barcode.value,
        createdAt: barcode.createdAt,
        fileSize: barcode.fileSize,
        boardId: barcode.metadata.boardId,
        itemId: barcode.metadata.itemId,
        boardName: barcode.metadata.boardName,
        itemName: barcode.metadata.itemName
      })),
      pagination: {
        total: totalCount,
        limit,
        offset,
        hasMore: offset + limit < totalCount
      }
    };
  } catch (error) {
    logger.error('Failed to get barcode history', { error: error.message, userId });
    throw error;
  }
};

/**
 * Get barcode by ID
 * @param {string} barcodeId - Barcode ID
 * @returns {Promise<Object>} Barcode data
 */
const getBarcodeById = async (barcodeId) => {
  try {
    logger.barcodeOperation('get_by_id', { barcodeId });

    const barcode = barcodes.get(barcodeId);
    
    if (!barcode) {
      throw new Error('Barcode not found');
    }

    // Check if barcode has expired
    if (new Date() > new Date(barcode.expiresAt)) {
      barcodes.delete(barcodeId);
      throw new Error('Barcode has expired');
    }

    // Create a base64 data URL for the image
    const imageUrl = `data:${barcode.mimeType};base64,${barcode.imageBuffer.toString('base64')}`;

    return {
      success: true,
      data: {
        ...barcode,
        imageUrl,
        // Remove buffer from response for security
        imageBuffer: undefined
      }
    };
  } catch (error) {
    logger.error('Failed to get barcode by ID', { error: error.message, barcodeId });
    throw error;
  }
};

/**
 * Update barcode metadata
 * @param {string} barcodeId - Barcode ID
 * @param {Object} updateData - Data to update
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Updated barcode data
 */
const updateBarcode = async (barcodeId, updateData, userId) => {
  try {
    logger.barcodeOperation('update', { barcodeId, userId });

    const barcode = barcodes.get(barcodeId);
    
    if (!barcode) {
      throw new Error('Barcode not found');
    }

    if (barcode.metadata.userId !== userId) {
      throw new Error('Unauthorized');
    }

    // Update allowed fields
    const allowedFields = ['metadata'];
    const updatedBarcode = { ...barcode };
    
    Object.keys(updateData).forEach(key => {
      if (allowedFields.includes(key)) {
        updatedBarcode[key] = { ...updatedBarcode[key], ...updateData[key] };
      }
    });

    updatedBarcode.updatedAt = new Date().toISOString();
    barcodes.set(barcodeId, updatedBarcode);

    return {
      success: true,
      data: {
        ...updatedBarcode,
        imageBuffer: undefined // Remove buffer from response
      }
    };
  } catch (error) {
    logger.error('Failed to update barcode', { error: error.message, barcodeId });
    throw error;
  }
};

/**
 * Delete barcode
 * @param {string} barcodeId - Barcode ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Deletion result
 */
const deleteBarcode = async (barcodeId, userId) => {
  try {
    logger.barcodeOperation('delete', { barcodeId, userId });

    const barcode = barcodes.get(barcodeId);
    
    if (!barcode) {
      throw new Error('Barcode not found');
    }

    if (barcode.metadata.userId !== userId) {
      throw new Error('Unauthorized');
    }

    barcodes.delete(barcodeId);

    return {
      success: true,
      data: { deleted: true }
    };
  } catch (error) {
    logger.error('Failed to delete barcode', { error: error.message, barcodeId });
    throw error;
  }
};

/**
 * Validate barcode data
 * @param {Object} params - Barcode parameters to validate
 * @returns {Promise<Object>} Validation result
 */
const validateBarcodeData = async (params) => {
  try {
    const { value, type } = params;

    if (!value || !value.trim()) {
      return {
        valid: false,
        message: 'Barcode value is required'
      };
    }

    const trimmedValue = value.trim();

    switch (type) {
      case 'CODE128':
        if (trimmedValue.length > 80) {
          return {
            valid: false,
            message: 'CODE128 value must be 80 characters or less'
          };
        }
        break;

      case 'QR':
        if (trimmedValue.length > 2953) {
          return {
            valid: false,
            message: 'QR code value is too long (max 2953 characters)'
          };
        }
        break;

      default:
        return {
          valid: false,
          message: 'Invalid barcode type'
        };
    }

    return { valid: true };
  } catch (error) {
    logger.error('Barcode validation failed', { error: error.message, params });
    return {
      valid: false,
      message: 'Validation error occurred'
    };
  }
};

/**
 * Get barcode statistics
 * @param {string} userId - User ID
 * @param {string} period - Time period for stats
 * @returns {Promise<Object>} Statistics data
 */
const getBarcodeStats = async (userId, period = '30d') => {
  try {
    logger.barcodeOperation('stats_request', { userId, period });

    const userBarcodes = Array.from(barcodes.values())
      .filter(barcode => barcode.metadata.userId === userId);

    const stats = {
      total: userBarcodes.length,
      byType: {},
      byDate: {},
      totalSize: 0
    };

    userBarcodes.forEach(barcode => {
      // Count by type
      stats.byType[barcode.type] = (stats.byType[barcode.type] || 0) + 1;
      
      // Count by date
      const date = barcode.createdAt.split('T')[0];
      stats.byDate[date] = (stats.byDate[date] || 0) + 1;
      
      // Total file size
      stats.totalSize += barcode.fileSize || 0;
    });

    return {
      success: true,
      data: stats
    };
  } catch (error) {
    logger.error('Failed to get barcode stats', { error: error.message, userId });
    throw error;
  }
};

/**
 * Export barcodes
 * @param {Object} options - Export options
 * @returns {Promise<Object>} Export result
 */
const exportBarcodes = async (options) => {
  try {
    const { userId, format = 'csv', filters = {} } = options;
    logger.barcodeOperation('export_request', { userId, format, filters });

    const userBarcodes = Array.from(barcodes.values())
      .filter(barcode => barcode.metadata.userId === userId);

    let exportData;
    let mimeType;

    switch (format.toLowerCase()) {
      case 'csv':
        exportData = generateCSVExport(userBarcodes);
        mimeType = 'text/csv';
        break;
      
      case 'json':
        exportData = JSON.stringify(userBarcodes.map(b => ({
          ...b,
          imageBuffer: undefined // Remove buffer for export
        })), null, 2);
        mimeType = 'application/json';
        break;
      
      default:
        throw new Error(`Unsupported export format: ${format}`);
    }

    return {
      success: true,
      data: {
        content: exportData,
        mimeType,
        filename: `barcodes_export_${Date.now()}.${format}`,
        recordCount: userBarcodes.length
      }
    };
  } catch (error) {
    logger.error('Failed to export barcodes', { error: error.message, options });
    throw error;
  }
};

/**
 * Generate CSV export data
 * @param {Array} barcodes - Barcode data array
 * @returns {string} CSV content
 */
const generateCSVExport = (barcodes) => {
  const headers = ['ID', 'Type', 'Value', 'Created At', 'File Size', 'Board ID', 'Item ID'];
  const csvRows = [headers.join(',')];

  barcodes.forEach(barcode => {
    const row = [
      barcode.id,
      barcode.type,
      `"${barcode.value.replace(/"/g, '""')}"`, // Escape quotes in CSV
      barcode.createdAt,
      barcode.fileSize || 0,
      barcode.metadata.boardId || '',
      barcode.metadata.itemId || ''
    ];
    csvRows.push(row.join(','));
  });

  return csvRows.join('\n');
};

/**
 * Clean up expired barcodes
 * @returns {Promise<Object>} Cleanup result
 */
const cleanupExpiredBarcodes = async () => {
  try {
    logger.barcodeOperation('cleanup_start', {});

    const now = new Date();
    let deletedCount = 0;
    let freedSpace = 0;

    for (const [id, barcode] of barcodes.entries()) {
      if (new Date(barcode.expiresAt) < now) {
        freedSpace += barcode.fileSize || 0;
        barcodes.delete(id);
        deletedCount++;
      }
    }

    logger.barcodeOperation('cleanup_complete', { deletedCount, freedSpace });

    return {
      success: true,
      data: {
        deletedCount,
        freedSpace: `${(freedSpace / 1024).toFixed(2)} KB`
      }
    };
  } catch (error) {
    logger.error('Cleanup failed', { error: error.message });
    throw error;
  }
};

module.exports = {
  generateBarcode,
  generateBatchBarcodes,
  getBarcodeHistory,
  getBarcodeById,
  updateBarcode,
  deleteBarcode,
  validateBarcodeData,
  getBarcodeStats,
  exportBarcodes,
  cleanupExpiredBarcodes
}; 