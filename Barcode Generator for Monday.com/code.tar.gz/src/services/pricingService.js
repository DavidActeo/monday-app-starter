/**
 * Pricing Service
 * Handles seat-based pricing, plan validation, and feature access control
 */

const fs = require('fs').promises;
const path = require('path');
const logger = require('../utils/logger');

// Load pricing configuration
let pricingConfig = null;

const loadPricingConfig = async () => {
  if (!pricingConfig) {
    try {
      const configPath = path.join(__dirname, '../../pricing.json');
      const configData = await fs.readFile(configPath, 'utf8');
      pricingConfig = JSON.parse(configData);
    } catch (error) {
      logger.error('Failed to load pricing configuration', { error: error.message });
      throw new Error('Pricing configuration not available');
    }
  }
  return pricingConfig;
};

/**
 * Get available pricing plans
 */
const getPricingPlans = async () => {
  const config = await loadPricingConfig();
  return config.pricing_plans;
};

/**
 * Get specific pricing plan by ID
 */
const getPricingPlan = async (planId) => {
  const config = await loadPricingConfig();
  return config.pricing_plans.find(plan => plan.id === planId);
};

/**
 * Validate user's access to barcode type based on their plan
 */
const validateBarcodeTypeAccess = async (userPlan, barcodeType) => {
  const config = await loadPricingConfig();
  
  // Without a plan, require trial or paid plan
  if (!userPlan) {
    return {
      allowed: false,
      reason: 'Start your free trial to access barcode generation'
    };
  }
  
  const plan = await getPricingPlan(userPlan);
  if (!plan) {
    return {
      allowed: false,
      reason: 'Invalid subscription plan'
    };
  }
  
  // All plans (including trial) have access to all barcode types
  return {
    allowed: true,
    reason: null
  };
};

/**
 * Check monthly usage limits (removed - no usage limits)
 */
const checkUsageLimit = async (userId, userPlan, currentMonthUsage) => {
  // No usage limits - all plans have unlimited barcode generation
  return {
    withinLimit: true,
    limit: 'unlimited',
    used: currentMonthUsage,
    remaining: 'unlimited'
  };
};

/**
 * Get feature access for a specific plan
 */
const getFeatureAccess = async (userPlan) => {
  const config = await loadPricingConfig();
  
  if (!userPlan) {
    return {
      barcodeTypes: [],
      monthlyLimit: 0,
      features: ['Start free trial to access features'],
      support: 'none'
    };
  }
  
  const plan = await getPricingPlan(userPlan);
  if (!plan) {
    return null;
  }
  
  // All plans have access to all barcode types and unlimited generation
  const allBarcodeTypes = ['QR', 'CODE128', 'EAN13', 'EAN8', 'UPC_A', 'CODE39', 'DATAMATRIX'];
  
  const featureMap = {
    trial: {
      barcodeTypes: allBarcodeTypes,
      monthlyLimit: 'unlimited',
      features: plan.features,
      support: 'basic'
    },
    basic: {
      barcodeTypes: allBarcodeTypes,
      monthlyLimit: 'unlimited',
      features: plan.features,
      support: 'basic'
    },
    professional: {
      barcodeTypes: allBarcodeTypes,
      monthlyLimit: 'unlimited',
      features: plan.features,
      support: 'priority'
    },
    enterprise: {
      barcodeTypes: allBarcodeTypes,
      monthlyLimit: 'unlimited',
      features: plan.features,
      support: 'premium'
    }
  };
  
  return featureMap[plan.id] || null;
};

/**
 * Calculate pricing for a given number of seats
 */
const calculatePricing = async (planId, seatCount, billingPeriod = 'monthly') => {
  const plan = await getPricingPlan(planId);
  if (!plan) {
    throw new Error('Invalid plan ID');
  }
  
  // Handle unlimited seats
  const maxSeats = plan.max_seats === 'unlimited' ? Infinity : plan.max_seats;
  if (seatCount < plan.min_seats || seatCount > maxSeats) {
    throw new Error(`Seat count must be between ${plan.min_seats} and ${plan.max_seats} for ${plan.name}`);
  }
  
  // Get price based on billing period (prices are in cents)
  const pricePerSeat = billingPeriod === 'yearly' ? plan.yearly_price : plan.monthly_price;
  const totalPrice = pricePerSeat * seatCount;
  
  // Convert cents to dollars for display
  return {
    plan: plan.name,
    seats: seatCount,
    pricePerSeat: pricePerSeat / 100, // Convert cents to dollars
    totalPrice: totalPrice / 100, // Convert cents to dollars
    currency: plan.currency,
    billingPeriod: billingPeriod,
    pricePerSeatCents: pricePerSeat, // Keep original cents value
    totalPriceCents: totalPrice // Keep original cents value
  };
};

/**
 * Get Monday.com account seat count
 */
const getAccountSeatCount = async (authToken) => {
  try {
    const mondayService = require('./mondayService');
    
    const query = `
      query {
        apps_monetization_info {
          seats_count
        }
      }
    `;
    
    const response = await mondayService.executeGraphQLQuery(query, {}, authToken);
    return response.data.apps_monetization_info.seats_count;
  } catch (error) {
    logger.error('Failed to fetch seat count from Monday.com', { error: error.message });
    throw new Error('Unable to determine account seat count');
  }
};

/**
 * Recommend best plan based on seat count
 */
const recommendPlan = async (seatCount) => {
  const plans = await getPricingPlans();
  
  // Filter out trial plans for recommendations
  const paidPlans = plans.filter(plan => !plan.is_trial);
  
  // Find the most suitable plan
  for (const plan of paidPlans) {
    const maxSeats = plan.max_seats === 'unlimited' ? Infinity : plan.max_seats;
    if (seatCount >= plan.min_seats && seatCount <= maxSeats) {
      return plan;
    }
  }
  
  // If no plan fits, recommend the enterprise plan
  return paidPlans.find(plan => plan.id === 'enterprise') || paidPlans[paidPlans.length - 1];
};

/**
 * Get free trial information
 */
const getFreeTrial = async () => {
  const config = await loadPricingConfig();
  return config.pricing_plans.find(plan => plan.is_trial) || null;
};

module.exports = {
  getPricingPlans,
  getPricingPlan,
  validateBarcodeTypeAccess,
  checkUsageLimit,
  getFeatureAccess,
  calculatePricing,
  getFreeTrial,
  getAccountSeatCount,
  recommendPlan
};