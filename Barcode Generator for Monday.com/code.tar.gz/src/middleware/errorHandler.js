/**
 * Error Handler Middleware
 * 
 * This file contains global error handling middleware for the Express application.
 * It handles various types of errors and provides consistent error responses.
 */

const logger = require('../utils/logger');

// ==============================================
// MAIN ERROR HANDLER
// ==============================================

/**
 * Global error handling middleware
 * This should be the last middleware in the application
 */
const errorHandler = (error, req, res, next) => {
  // Log the error details
  logger.error('Application error:', {
    message: error.message,
    stack: error.stack,
    url: req.originalUrl,
    method: req.method,
    userId: req.user ? req.user.id : 'anonymous',
    timestamp: new Date().toISOString(),
    userAgent: req.get('User-Agent'),
    ip: req.ip
  });

  // Set default error values
  let statusCode = error.statusCode || 500;
  let errorCode = error.code || 'INTERNAL_SERVER_ERROR';
  let message = error.message || 'An internal server error occurred';

  // Handle specific error types
  switch (error.name) {
    case 'ValidationError':
      statusCode = 400;
      errorCode = 'VALIDATION_ERROR';
      message = 'Validation failed';
      break;
      
    case 'JsonWebTokenError':
      statusCode = 401;
      errorCode = 'INVALID_JWT_TOKEN';
      message = 'Invalid authentication token';
      break;
      
    case 'TokenExpiredError':
      statusCode = 401;
      errorCode = 'JWT_TOKEN_EXPIRED';
      message = 'Authentication token has expired';
      break;
      
    case 'MongoError':
    case 'MongooseError':
      statusCode = 500;
      errorCode = 'DATABASE_ERROR';
      message = 'Database operation failed';
      break;
      
    case 'CastError':
      statusCode = 400;
      errorCode = 'INVALID_ID_FORMAT';
      message = 'Invalid ID format provided';
      break;
      
    case 'MulterError':
      statusCode = 400;
      errorCode = 'FILE_UPLOAD_ERROR';
      message = handleMulterError(error);
      break;
      
    case 'SyntaxError':
      if (error.message.includes('JSON')) {
        statusCode = 400;
        errorCode = 'INVALID_JSON';
        message = 'Invalid JSON in request body';
      }
      break;
  }

  // Handle axios/HTTP errors from external API calls
  if (error.response) {
    statusCode = error.response.status || 500;
    errorCode = 'EXTERNAL_API_ERROR';
    message = `External API error: ${error.response.statusText || 'Unknown error'}`;
    
    // Handle Monday.com API specific errors
    if (error.response.config && error.response.config.url && error.response.config.url.includes('monday.com')) {
      errorCode = 'MONDAY_API_ERROR';
      message = 'Monday.com API error';
      
      if (error.response.data && error.response.data.errors) {
        message = error.response.data.errors[0]?.message || message;
      }
    }
  }

  // Handle network errors
  if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
    statusCode = 503;
    errorCode = 'SERVICE_UNAVAILABLE';
    message = 'External service unavailable';
  }

  // Create error response object
  const errorResponse = {
    status: 'error',
    message: message,
    code: errorCode,
    timestamp: new Date().toISOString()
  };

  // Add additional error details in development mode
  if (process.env.NODE_ENV === 'development') {
    errorResponse.details = {
      stack: error.stack,
      originalError: error.message,
      url: req.originalUrl,
      method: req.method
    };
  }

  // Add validation errors if available
  if (error.errors) {
    errorResponse.validationErrors = error.errors;
  }

  // Send error response
  res.status(statusCode).json(errorResponse);
};

// ==============================================
// SPECIFIC ERROR HANDLERS
// ==============================================

/**
 * Handle Multer file upload errors
 */
const handleMulterError = (error) => {
  switch (error.code) {
    case 'LIMIT_FILE_SIZE':
      return 'File size exceeds the allowed limit';
    case 'LIMIT_FILE_COUNT':
      return 'Too many files uploaded';
    case 'LIMIT_UNEXPECTED_FILE':
      return 'Unexpected file field';
    case 'LIMIT_FIELD_COUNT':
      return 'Too many fields';
    case 'LIMIT_FIELD_KEY':
      return 'Field name too long';
    case 'LIMIT_FIELD_VALUE':
      return 'Field value too long';
    case 'LIMIT_PART_COUNT':
      return 'Too many parts';
    default:
      return 'File upload error';
  }
};

/**
 * Handle 404 errors for undefined routes
 */
const notFoundHandler = (req, res, next) => {
  const error = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  error.statusCode = 404;
  error.code = 'ROUTE_NOT_FOUND';
  
  logger.warn('Route not found:', {
    url: req.originalUrl,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent')
  });
  
  next(error);
};

/**
 * Handle async route errors
 */
const asyncHandler = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

// ==============================================
// ERROR LOGGING HELPERS
// ==============================================

/**
 * Log critical errors that need immediate attention
 */
const logCriticalError = (error, req) => {
  const criticalErrors = [
    'ECONNREFUSED',
    'ENOTFOUND',
    'DATABASE_CONNECTION_ERROR',
    'MONGODB_ERROR',
    'AUTHENTICATION_SERVICE_DOWN'
  ];
  
  if (criticalErrors.includes(error.code) || error.statusCode >= 500) {
    logger.error('CRITICAL ERROR:', {
      message: error.message,
      code: error.code,
      stack: error.stack,
      url: req.originalUrl,
      method: req.method,
      timestamp: new Date().toISOString(),
      level: 'CRITICAL'
    });
    
    // In production, you might want to send alerts to monitoring services
    if (process.env.NODE_ENV === 'production') {
      // Send to error monitoring service (e.g., Sentry, DataDog)
      // Example: sendToMonitoringService(error, req);
    }
  }
};

/**
 * Create standardized error objects
 */
const createError = (statusCode, message, code = null) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  error.code = code || getErrorCodeFromStatus(statusCode);
  return error;
};

/**
 * Get error code from HTTP status code
 */
const getErrorCodeFromStatus = (statusCode) => {
  const statusCodeMap = {
    400: 'BAD_REQUEST',
    401: 'UNAUTHORIZED',
    403: 'FORBIDDEN',
    404: 'NOT_FOUND',
    405: 'METHOD_NOT_ALLOWED',
    409: 'CONFLICT',
    422: 'UNPROCESSABLE_ENTITY',
    429: 'TOO_MANY_REQUESTS',
    500: 'INTERNAL_SERVER_ERROR',
    502: 'BAD_GATEWAY',
    503: 'SERVICE_UNAVAILABLE',
    504: 'GATEWAY_TIMEOUT'
  };
  
  return statusCodeMap[statusCode] || 'UNKNOWN_ERROR';
};

// ==============================================
// ERROR RESPONSE FORMATTERS
// ==============================================

/**
 * Format API error responses consistently
 */
const formatApiError = (statusCode, message, code = null, details = null) => {
  const error = {
    status: 'error',
    message: message,
    code: code || getErrorCodeFromStatus(statusCode),
    timestamp: new Date().toISOString()
  };
  
  if (details && process.env.NODE_ENV === 'development') {
    error.details = details;
  }
  
  return error;
};

/**
 * Format validation errors
 */
const formatValidationError = (validationErrors) => {
  return {
    status: 'error',
    message: 'Validation failed',
    code: 'VALIDATION_ERROR',
    errors: validationErrors.map(error => ({
      field: error.param,
      message: error.msg,
      value: error.value
    })),
    timestamp: new Date().toISOString()
  };
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  errorHandler,
  notFoundHandler,
  asyncHandler,
  createError,
  formatApiError,
  formatValidationError,
  logCriticalError
}; 