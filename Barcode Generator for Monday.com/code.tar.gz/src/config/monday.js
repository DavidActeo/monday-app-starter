/**
 * Monday.com Configuration
 * 
 * This file contains configuration settings specific to Monday.com
 * integration including OAuth, API endpoints, and app settings.
 */

const { MONDAY_CONFIG } = require('../utils/constants');

// ==============================================
// MONDAY.COM APP CONFIGURATION
// ==============================================

const config = {
  // App Information
  appId: process.env.MONDAY_APP_ID || '10481518',
  clientId: process.env.MONDAY_CLIENT_ID,
  clientSecret: process.env.MONDAY_CLIENT_SECRET,
  signingSecret: process.env.MONDAY_SIGNING_SECRET,
  
  // OAuth Configuration
  oauth: {
    authUrl: MONDAY_CONFIG.AUTH_URL,
    tokenUrl: MONDAY_CONFIG.TOKEN_URL,
    redirectUri: process.env.MONDAY_REDIRECT_URI || 'http://localhost:3000/auth/monday/callback',
    scopes: MONDAY_CONFIG.SCOPES,
    state: {
      enabled: true,
      secret: process.env.OAUTH_STATE_SECRET || 'monday-barcode-oauth-state'
    }
  },
  
  // API Configuration
  api: {
    baseUrl: MONDAY_CONFIG.API_URL,
    version: MONDAY_CONFIG.API_VERSION,
    timeout: parseInt(process.env.MONDAY_API_TIMEOUT) || 10000,
    retries: parseInt(process.env.MONDAY_API_RETRIES) || 3,
    retryDelay: parseInt(process.env.MONDAY_API_RETRY_DELAY) || 1000
  },
  
  // Webhook Configuration
  webhooks: {
    enabled: process.env.ENABLE_WEBHOOKS === 'true',
    signingSecret: process.env.MONDAY_SIGNING_SECRET,
    timeout: parseInt(process.env.WEBHOOK_TIMEOUT) || 5000,
    events: MONDAY_CONFIG.WEBHOOK_EVENTS,
    baseUrl: process.env.WEBHOOK_BASE_URL || 'http://localhost:3000/webhooks'
  },
  
  // Rate Limiting for Monday.com API
  rateLimits: {
    requests: {
      perMinute: parseInt(process.env.MONDAY_RATE_LIMIT_PER_MINUTE) || 60,
      perHour: parseInt(process.env.MONDAY_RATE_LIMIT_PER_HOUR) || 1000,
      burst: parseInt(process.env.MONDAY_RATE_LIMIT_BURST) || 10
    },
    backoff: {
      enabled: true,
      baseDelay: 1000,
      maxDelay: 30000,
      factor: 2
    }
  },
  
  // Caching Configuration
  cache: {
    enabled: process.env.ENABLE_MONDAY_CACHE === 'true',
    ttl: {
      user: parseInt(process.env.CACHE_TTL_USER) || 300, // 5 minutes
      boards: parseInt(process.env.CACHE_TTL_BOARDS) || 600, // 10 minutes
      items: parseInt(process.env.CACHE_TTL_ITEMS) || 60, // 1 minute
      columns: parseInt(process.env.CACHE_TTL_COLUMNS) || 1800 // 30 minutes
    }
  },
  
  // Feature Flags
  features: {
    webhookSubscriptions: process.env.ENABLE_WEBHOOK_SUBSCRIPTIONS === 'true',
    batchOperations: process.env.ENABLE_BATCH_OPERATIONS === 'true',
    realTimeUpdates: process.env.ENABLE_REALTIME_UPDATES === 'true',
    auditLogs: process.env.ENABLE_AUDIT_LOGS === 'true'
  }
};

// ==============================================
// VALIDATION
// ==============================================

/**
 * Validate Monday.com configuration
 */
const validateConfig = () => {
  const errors = [];
  
  if (!config.clientId) {
    errors.push('MONDAY_CLIENT_ID is required');
  }
  
  if (!config.clientSecret) {
    errors.push('MONDAY_CLIENT_SECRET is required');
  }
  
  if (config.webhooks.enabled && !config.webhooks.signingSecret) {
    errors.push('MONDAY_SIGNING_SECRET is required when webhooks are enabled');
  }
  
  if (!config.oauth.redirectUri.startsWith('http')) {
    errors.push('MONDAY_REDIRECT_URI must be a valid URL');
  }
  
  if (errors.length > 0) {
    throw new Error(`Monday.com configuration errors: ${errors.join(', ')}`);
  }
};

// ==============================================
// HELPER FUNCTIONS
// ==============================================

/**
 * Get OAuth authorization URL
 */
const getAuthUrl = (state = null) => {
  const params = new URLSearchParams({
    client_id: config.clientId,
    response_type: 'code',
    redirect_uri: config.oauth.redirectUri,
    scope: config.oauth.scopes.join(' ')
  });
  
  if (state) {
    params.append('state', state);
  }
  
  return `${config.oauth.authUrl}?${params.toString()}`;
};

/**
 * Get webhook subscription URL
 */
const getWebhookUrl = (event) => {
  return `${config.webhooks.baseUrl}/monday`;
};

/**
 * Check if feature is enabled
 */
const isFeatureEnabled = (feature) => {
  return config.features[feature] === true;
};

/**
 * Get API headers with authentication
 */
const getApiHeaders = (accessToken, additionalHeaders = {}) => {
  return {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
    'API-Version': config.api.version,
    'User-Agent': `monday-barcode-generator/${process.env.npm_package_version || '1.0.0'}`,
    ...additionalHeaders
  };
};

/**
 * Get current environment configuration
 */
const getEnvironmentConfig = () => {
  const env = process.env.NODE_ENV || 'development';
  
  const envConfigs = {
    development: {
      debug: true,
      verbose: true,
      strictSSL: false
    },
    staging: {
      debug: false,
      verbose: true,
      strictSSL: true
    },
    production: {
      debug: false,
      verbose: false,
      strictSSL: true
    }
  };
  
  return envConfigs[env] || envConfigs.development;
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  config,
  validateConfig,
  getAuthUrl,
  getWebhookUrl,
  isFeatureEnabled,
  getApiHeaders,
  getEnvironmentConfig
}; 