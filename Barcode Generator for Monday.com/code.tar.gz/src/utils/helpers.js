/**
 * Helper Utilities
 * 
 * This file contains utility functions used throughout the Monday.com 
 * Barcode Generator application for common operations like data formatting,
 * validation, and manipulation.
 */

const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const logger = require('./logger');

// ==============================================
// STRING UTILITIES
// ==============================================

/**
 * Capitalize first letter of a string
 */
const capitalize = (str) => {
  if (!str || typeof str !== 'string') return str;
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

/**
 * Convert string to camelCase
 */
const toCamelCase = (str) => {
  if (!str || typeof str !== 'string') return str;
  return str.replace(/[-_\s]+(.)?/g, (_, char) => char ? char.toUpperCase() : '');
};

/**
 * Convert string to snake_case
 */
const toSnakeCase = (str) => {
  if (!str || typeof str !== 'string') return str;
  return str.replace(/([A-Z])/g, '_$1').toLowerCase().replace(/^_/, '');
};

/**
 * Convert string to kebab-case
 */
const toKebabCase = (str) => {
  if (!str || typeof str !== 'string') return str;
  return str.replace(/([A-Z])/g, '-$1').toLowerCase().replace(/^-/, '');
};

/**
 * Truncate string to specified length with ellipsis
 */
const truncate = (str, length = 100, suffix = '...') => {
  if (!str || typeof str !== 'string') return str;
  if (str.length <= length) return str;
  return str.substring(0, length - suffix.length) + suffix;
};

/**
 * Remove HTML tags from string
 */
const stripHtml = (str) => {
  if (!str || typeof str !== 'string') return str;
  return str.replace(/<[^>]*>/g, '');
};

/**
 * Escape HTML characters
 */
const escapeHtml = (str) => {
  if (!str || typeof str !== 'string') return str;
  const htmlEscapes = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;'
  };
  return str.replace(/[&<>"'\/]/g, (char) => htmlEscapes[char]);
};

/**
 * Generate random string
 */
const generateRandomString = (length = 32, charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') => {
  let result = '';
  for (let i = 0; i < length; i++) {
    result += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  return result;
};

// ==============================================
// DATE AND TIME UTILITIES
// ==============================================

/**
 * Format date to ISO string
 */
const formatDateISO = (date) => {
  if (!date) return null;
  try {
    return new Date(date).toISOString();
  } catch (error) {
    logger.warn('Invalid date format:', date);
    return null;
  }
};

/**
 * Format date for display
 */
const formatDateDisplay = (date, locale = 'en-US', options = {}) => {
  if (!date) return '';
  try {
    const defaultOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    return new Date(date).toLocaleDateString(locale, { ...defaultOptions, ...options });
  } catch (error) {
    logger.warn('Error formatting date:', error);
    return String(date);
  }
};

/**
 * Get relative time (e.g., "2 hours ago")
 */
const getRelativeTime = (date) => {
  if (!date) return '';
  try {
    const now = new Date();
    const past = new Date(date);
    const diffMs = now - past;
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffSecs < 60) return 'just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    return formatDateDisplay(date);
  } catch (error) {
    logger.warn('Error calculating relative time:', error);
    return String(date);
  }
};

/**
 * Add time to date
 */
const addTimeToDate = (date, amount, unit = 'hours') => {
  try {
    const newDate = new Date(date);
    switch (unit) {
      case 'seconds':
        newDate.setSeconds(newDate.getSeconds() + amount);
        break;
      case 'minutes':
        newDate.setMinutes(newDate.getMinutes() + amount);
        break;
      case 'hours':
        newDate.setHours(newDate.getHours() + amount);
        break;
      case 'days':
        newDate.setDate(newDate.getDate() + amount);
        break;
      case 'weeks':
        newDate.setDate(newDate.getDate() + (amount * 7));
        break;
      case 'months':
        newDate.setMonth(newDate.getMonth() + amount);
        break;
      case 'years':
        newDate.setFullYear(newDate.getFullYear() + amount);
        break;
      default:
        throw new Error(`Unknown time unit: ${unit}`);
    }
    return newDate;
  } catch (error) {
    logger.error('Error adding time to date:', error);
    return new Date(date);
  }
};

// ==============================================
// OBJECT UTILITIES
// ==============================================

/**
 * Deep clone an object
 */
const deepClone = (obj) => {
  if (obj === null || typeof obj !== 'object') return obj;
  if (obj instanceof Date) return new Date(obj.getTime());
  if (obj instanceof Array) return obj.map(item => deepClone(item));
  if (typeof obj === 'object') {
    const cloned = {};
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        cloned[key] = deepClone(obj[key]);
      }
    }
    return cloned;
  }
  return obj;
};

/**
 * Deep merge objects
 */
const deepMerge = (target, source) => {
  const result = { ...target };
  
  for (const key in source) {
    if (source.hasOwnProperty(key)) {
      if (typeof source[key] === 'object' && source[key] !== null && !Array.isArray(source[key])) {
        result[key] = deepMerge(result[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    }
  }
  
  return result;
};

/**
 * Get nested object property safely
 */
const getNestedProperty = (obj, path, defaultValue = undefined) => {
  if (!obj || typeof path !== 'string') return defaultValue;
  
  const keys = path.split('.');
  let current = obj;
  
  for (const key of keys) {
    if (current === null || current === undefined || !(key in current)) {
      return defaultValue;
    }
    current = current[key];
  }
  
  return current;
};

/**
 * Set nested object property
 */
const setNestedProperty = (obj, path, value) => {
  if (!obj || typeof path !== 'string') return obj;
  
  const keys = path.split('.');
  let current = obj;
  
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    if (!(key in current) || typeof current[key] !== 'object') {
      current[key] = {};
    }
    current = current[key];
  }
  
  current[keys[keys.length - 1]] = value;
  return obj;
};

/**
 * Remove empty properties from object
 */
const removeEmptyProperties = (obj) => {
  const cleaned = {};
  
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const value = obj[key];
      
      if (value !== null && value !== undefined && value !== '' && !(Array.isArray(value) && value.length === 0)) {
        if (typeof value === 'object' && !Array.isArray(value)) {
          const cleanedNested = removeEmptyProperties(value);
          if (Object.keys(cleanedNested).length > 0) {
            cleaned[key] = cleanedNested;
          }
        } else {
          cleaned[key] = value;
        }
      }
    }
  }
  
  return cleaned;
};

// ==============================================
// ARRAY UTILITIES
// ==============================================

/**
 * Remove duplicates from array
 */
const removeDuplicates = (arr, key = null) => {
  if (!Array.isArray(arr)) return arr;
  
  if (key) {
    const seen = new Set();
    return arr.filter(item => {
      const value = getNestedProperty(item, key);
      if (seen.has(value)) {
        return false;
      }
      seen.add(value);
      return true;
    });
  }
  
  return [...new Set(arr)];
};

/**
 * Chunk array into smaller arrays
 */
const chunkArray = (arr, size) => {
  if (!Array.isArray(arr) || size <= 0) return arr;
  
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
};

/**
 * Shuffle array
 */
const shuffleArray = (arr) => {
  if (!Array.isArray(arr)) return arr;
  
  const shuffled = [...arr];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

/**
 * Sort array of objects by property
 */
const sortByProperty = (arr, property, direction = 'asc') => {
  if (!Array.isArray(arr)) return arr;
  
  return arr.sort((a, b) => {
    const aVal = getNestedProperty(a, property);
    const bVal = getNestedProperty(b, property);
    
    if (aVal < bVal) return direction === 'asc' ? -1 : 1;
    if (aVal > bVal) return direction === 'asc' ? 1 : -1;
    return 0;
  });
};

// ==============================================
// VALIDATION UTILITIES
// ==============================================

/**
 * Check if value is empty
 */
const isEmpty = (value) => {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') return Object.keys(value).length === 0;
  return false;
};

/**
 * Check if value is a valid email
 */
const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Check if value is a valid URL
 */
const isValidUrl = (url) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

/**
 * Check if value is a valid UUID
 */
const isValidUuid = (uuid) => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
};

// ==============================================
// ENCRYPTION AND HASHING
// ==============================================

/**
 * Generate UUID
 */
const generateUuid = () => {
  return uuidv4();
};

/**
 * Generate hash
 */
const generateHash = (data, algorithm = 'sha256') => {
  return crypto.createHash(algorithm).update(data).digest('hex');
};

/**
 * Generate HMAC
 */
const generateHmac = (data, secret, algorithm = 'sha256') => {
  return crypto.createHmac(algorithm, secret).update(data).digest('hex');
};

/**
 * Encrypt data (simple encryption for non-sensitive data)
 */
const encryptData = (text, secret) => {
  try {
    const algorithm = 'aes-256-cbc';
    const key = crypto.scryptSync(secret, 'salt', 32);
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipher(algorithm, key);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return `${iv.toString('hex')}:${encrypted}`;
  } catch (error) {
    logger.error('Error encrypting data:', error);
    return null;
  }
};

/**
 * Decrypt data
 */
const decryptData = (encryptedText, secret) => {
  try {
    const algorithm = 'aes-256-cbc';
    const key = crypto.scryptSync(secret, 'salt', 32);
    const [ivHex, encrypted] = encryptedText.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipher(algorithm, key);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    logger.error('Error decrypting data:', error);
    return null;
  }
};

// ==============================================
// FORMAT UTILITIES
// ==============================================

/**
 * Format file size in human readable format
 */
const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * Format number with commas
 */
const formatNumber = (num) => {
  if (typeof num !== 'number') return num;
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

/**
 * Format percentage
 */
const formatPercentage = (value, total, decimals = 1) => {
  if (total === 0) return '0%';
  const percentage = (value / total) * 100;
  return `${percentage.toFixed(decimals)}%`;
};

// ==============================================
// ASYNC UTILITIES
// ==============================================

/**
 * Sleep/delay function
 */
const sleep = (ms) => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Retry function with exponential backoff
 */
const retry = async (fn, maxAttempts = 3, baseDelay = 1000) => {
  let attempt = 1;
  
  while (attempt <= maxAttempts) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxAttempts) {
        throw error;
      }
      
      const delay = baseDelay * Math.pow(2, attempt - 1);
      logger.warn(`Attempt ${attempt} failed, retrying in ${delay}ms:`, error.message);
      await sleep(delay);
      attempt++;
    }
  }
};

/**
 * Timeout wrapper for promises
 */
const withTimeout = (promise, timeoutMs) => {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Operation timed out')), timeoutMs)
    )
  ]);
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  // String utilities
  capitalize,
  toCamelCase,
  toSnakeCase,
  toKebabCase,
  truncate,
  stripHtml,
  escapeHtml,
  generateRandomString,
  
  // Date utilities
  formatDateISO,
  formatDateDisplay,
  getRelativeTime,
  addTimeToDate,
  
  // Object utilities
  deepClone,
  deepMerge,
  getNestedProperty,
  setNestedProperty,
  removeEmptyProperties,
  
  // Array utilities
  removeDuplicates,
  chunkArray,
  shuffleArray,
  sortByProperty,
  
  // Validation utilities
  isEmpty,
  isValidEmail,
  isValidUrl,
  isValidUuid,
  
  // Encryption utilities
  generateUuid,
  generateHash,
  generateHmac,
  encryptData,
  decryptData,
  
  // Format utilities
  formatFileSize,
  formatNumber,
  formatPercentage,
  
  // Async utilities
  sleep,
  retry,
  withTimeout
}; 