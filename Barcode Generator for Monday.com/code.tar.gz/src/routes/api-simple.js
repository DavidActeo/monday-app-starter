/**
 * SIMPLIFIED API Routes for Monday.com Action Blocks
 * This version handles Monday.com's actual payload structure
 */

const express = require('express');
const router = express.Router();
const logger = require('../utils/logger');
const mondayService = require('../services/mondayService');
const barcodeService = require('../services/barcodeService');

/**
 * Shared handler for all barcode action endpoints
 * COMPLETELY REWRITTEN - Handles Monday.com's actual payload structure
 */
async function handleBarcodeAction(req, res, barcodeType) {
  try {
    // Set CORS headers
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    console.log('=== BARCODE ACTION REQUEST ===');
    console.log('Type:', barcodeType);
    console.log('Headers:', JSON.stringify(req.headers, null, 2));
    console.log('Body:', JSON.stringify(req.body, null, 2));
    
    // Parse payload if it's a string (Monday.com sometimes sends stringified JSON)
    if (req.body.payload && typeof req.body.payload === 'string') {
      try {
        req.body.payload = JSON.parse(req.body.payload);
        console.log('📦 Parsed payload from string:', JSON.stringify(req.body.payload, null, 2));
      } catch (e) {
        console.error('❌ Failed to parse payload string:', e);
      }
    }
    
    // Get auth token - Monday.com sends it in different ways
    let authToken = req.headers.authorization || req.headers.Authorization;
    
    // Also check for token in body and payload
    if (!authToken && req.body.token) {
      authToken = req.body.token;
    }
    
    // Check in payload structure (Monday.com sometimes nests it)
    if (!authToken && req.body.payload?.token) {
      authToken = req.body.payload.token;
    }
    
    // Check for shortLivedToken (Monday.com uses this for action blocks)
    if (!authToken && req.body.shortLivedToken) {
      authToken = req.body.shortLivedToken;
    }
    
    if (!authToken) {
      console.log('❌ NO AUTH TOKEN FOUND. Headers:', req.headers);
      console.log('❌ NO AUTH TOKEN FOUND. Body token:', req.body.token);
      console.log('❌ NO AUTH TOKEN FOUND. Payload token:', req.body.payload?.token);
      console.log('❌ NO AUTH TOKEN FOUND. ShortLivedToken:', req.body.shortLivedToken);
      return res.status(401).json({ 
        error: 'Missing authorization',
        message: 'No authorization token provided' 
      });
    }
    
    // Extract token - remove Bearer prefix if present
    const actualToken = authToken.startsWith('Bearer ') 
      ? authToken.substring(7) 
      : authToken;
      
    console.log('🔐 Auth token found:', actualToken ? `${actualToken.substring(0, 20)}...` : 'none');
    
    // COMPREHENSIVE PAYLOAD EXTRACTION - Handle ALL possible Monday.com payload structures
    console.log('=== COMPREHENSIVE PAYLOAD EXTRACTION ===');
    console.log('🔍 FULL REQUEST BODY STRUCTURE:', JSON.stringify(req.body, null, 2));
    console.log('🔍 PAYLOAD STRUCTURE:', JSON.stringify(req.body.payload, null, 2));
    console.log('🔍 INBOUND FIELD VALUES:', JSON.stringify(req.body.inboundFieldValues, null, 2));
    console.log('🔍 INPUT FIELDS:', JSON.stringify(req.body.inputFields, null, 2));
    console.log('🔍 RUNTIME METADATA:', JSON.stringify(req.body.runtimeMetadata, null, 2));
    console.log('🔍 CONTEXT DATA:', JSON.stringify(req.body.context, null, 2));
    
    // Extract from ALL possible locations - THE DATA IS IN payload.inputFields!
    const boardId = req.body.boardId || 
                   req.body.payload?.inputFields?.boardId ||
                   req.body.payload?.boardId || 
                   req.body.inboundFieldValues?.boardId ||
                   req.body.inputFields?.boardId ||
                   req.body.context?.boardId ||
                   req.body.recipe?.boardId ||
                   req.body.runtimeMetadata?.boardId;
                   
    const itemId = req.body.itemId || 
                  req.body.payload?.inputFields?.itemId ||
                  req.body.payload?.itemId || 
                  req.body.inboundFieldValues?.itemId ||
                  req.body.inputFields?.itemId ||
                  req.body.context?.itemId ||
                  req.body.recipe?.itemId ||
                  req.body.runtimeMetadata?.itemId;
                  
    const sourceColumnId = req.body.sourceColumnId || 
                          req.body.payload?.inputFields?.sourceColumnId ||
                          req.body.payload?.sourceColumnId || 
                          req.body.inboundFieldValues?.sourceColumnId ||
                          req.body.inputFields?.sourceColumnId ||
                          req.body.inputFields?.linkColumnId;
                          
    const targetColumnId = req.body.targetColumnId || 
                          req.body.targetFileColumnId ||
                          req.body.payload?.inputFields?.targetColumnId ||
                          req.body.payload?.targetColumnId || 
                          req.body.payload?.targetFileColumnId ||
                          req.body.inboundFieldValues?.targetColumnId ||
                          req.body.inboundFieldValues?.targetFileColumnId ||
                          req.body.inputFields?.targetColumnId ||
                          req.body.inputFields?.targetFileColumnId ||
                          req.body.inputFields?.fileColumnId;
    
    // Log ALL extraction attempts
    console.log('=== EXTRACTION RESULTS ===');
    console.log('Board ID extraction attempts:', {
      fromBody: req.body.boardId,
      fromPayload: req.body.payload?.boardId,
      fromInboundFieldValues: req.body.inboundFieldValues?.boardId,
      fromInputFields: req.body.inputFields?.boardId,
      final: boardId
    });
    
    console.log('Item ID extraction attempts:', {
      fromBody: req.body.itemId,
      fromPayload: req.body.payload?.itemId,
      fromInboundFieldValues: req.body.inboundFieldValues?.itemId,
      fromInputFields: req.body.inputFields?.itemId,
      final: itemId
    });
    
    console.log('Source Column ID extraction attempts:', {
      fromBody: req.body.sourceColumnId,
      fromPayload: req.body.payload?.sourceColumnId,
      fromInboundFieldValues: req.body.inboundFieldValues?.sourceColumnId,
      fromInputFields: req.body.inputFields?.sourceColumnId,
      fromInputFieldsLink: req.body.inputFields?.linkColumnId,
      final: sourceColumnId
    });
    
    console.log('Target Column ID extraction attempts:', {
      fromBody: req.body.targetColumnId,
      fromBodyTargetFile: req.body.targetFileColumnId,
      fromPayload: req.body.payload?.targetColumnId,
      fromPayloadTargetFile: req.body.payload?.targetFileColumnId,
      fromInboundFieldValues: req.body.inboundFieldValues?.targetColumnId,
      fromInboundFieldValuesTargetFile: req.body.inboundFieldValues?.targetFileColumnId,
      fromInputFields: req.body.inputFields?.targetColumnId,
      fromInputFieldsTargetFile: req.body.inputFields?.targetFileColumnId,
      fromInputFieldsFile: req.body.inputFields?.fileColumnId,
      final: targetColumnId
    });
    
    // VALIDATION WITH DETAILED ERROR MESSAGES
    console.log('=== VALIDATION START ===');
    
    if (!boardId) {
      console.log('❌ VALIDATION FAILED: Missing boardId');
      console.log('Available boardId sources:', {
        reqBodyBoardId: req.body.boardId,
        reqBodyPayloadBoardId: req.body.payload?.boardId,
        reqBodyInboundFieldValuesBoardId: req.body.inboundFieldValues?.boardId,
        reqBodyInputFieldsBoardId: req.body.inputFields?.boardId
      });
      return res.status(400).json({ 
        error: 'Missing board ID',
        message: 'Board ID not found in any expected location',
        debug: {
          availableSources: {
            reqBodyBoardId: req.body.boardId,
            reqBodyPayloadBoardId: req.body.payload?.boardId,
            reqBodyInboundFieldValuesBoardId: req.body.inboundFieldValues?.boardId,
            reqBodyInputFieldsBoardId: req.body.inputFields?.boardId
          },
          fullBody: req.body
        }
      });
    }
    
    if (!itemId) {
      console.log('❌ VALIDATION FAILED: Missing itemId');
      return res.status(400).json({ 
        error: 'Missing item ID',
        message: 'Item ID not found in any expected location',
        debug: {
          availableSources: {
            reqBodyItemId: req.body.itemId,
            reqBodyPayloadItemId: req.body.payload?.itemId,
            reqBodyInboundFieldValuesItemId: req.body.inboundFieldValues?.itemId,
            reqBodyInputFieldsItemId: req.body.inputFields?.itemId
          },
          fullBody: req.body
        }
      });
    }
    
    if (!sourceColumnId) {
      console.log('❌ VALIDATION FAILED: Missing sourceColumnId');
      return res.status(400).json({ 
        error: 'Missing source column ID',
        message: 'Source column ID not found in any expected location',
        debug: {
          availableSources: {
            reqBodySourceColumnId: req.body.sourceColumnId,
            reqBodyPayloadSourceColumnId: req.body.payload?.sourceColumnId,
            reqBodyInboundFieldValuesSourceColumnId: req.body.inboundFieldValues?.sourceColumnId,
            reqBodyInputFieldsSourceColumnId: req.body.inputFields?.sourceColumnId,
            reqBodyInputFieldsLinkColumnId: req.body.inputFields?.linkColumnId
          },
          fullBody: req.body
        }
      });
    }
    
    if (!targetColumnId) {
      console.log('❌ VALIDATION FAILED: Missing targetColumnId');
      return res.status(400).json({ 
        error: 'Missing target column ID',
        message: 'Target column ID not found in any expected location',
        debug: {
          availableSources: {
            reqBodyTargetColumnId: req.body.targetColumnId,
            reqBodyTargetFileColumnId: req.body.targetFileColumnId,
            reqBodyPayloadTargetColumnId: req.body.payload?.targetColumnId,
            reqBodyPayloadTargetFileColumnId: req.body.payload?.targetFileColumnId,
            reqBodyInboundFieldValuesTargetColumnId: req.body.inboundFieldValues?.targetColumnId,
            reqBodyInboundFieldValuesTargetFileColumnId: req.body.inboundFieldValues?.targetFileColumnId,
            reqBodyInputFieldsTargetColumnId: req.body.inputFields?.targetColumnId,
            reqBodyInputFieldsTargetFileColumnId: req.body.inputFields?.targetFileColumnId,
            reqBodyInputFieldsFileColumnId: req.body.inputFields?.fileColumnId
          },
          fullBody: req.body
        }
      });
    }
    
    console.log('✅ VALIDATION PASSED - All required fields found');
    console.log('Final extracted values:', { boardId, itemId, sourceColumnId, targetColumnId });
    
    // GRAPHQL QUERY EXECUTION
    console.log('🔍 EXECUTING GRAPHQL QUERY ===');
    
    const query = `
      query GetItem($itemId: [ID!]) {
        items(ids: $itemId) {
          id
          name
          column_values {
            id
            text
            value
          }
        }
      }
    `;
    
    console.log('GraphQL Query Details:', {
      token: actualToken ? `${actualToken.substring(0, 10)}...` : 'undefined',
      itemId: itemId,
      query: query,
      variables: { itemId: [itemId] }
    });
    
    let itemData;
    try {
      itemData = await mondayService.executeGraphQLQuery(
        actualToken, 
        query, 
        { itemId: [itemId] }
      );
      
      console.log('📊 GRAPHQL RESPONSE RECEIVED ===');
      console.log('GraphQL response:', JSON.stringify(itemData, null, 2));
      
      if (!itemData?.items?.[0]) {
        console.log('❌ GRAPHQL ERROR: No items found in response');
        return res.status(404).json({ 
          error: 'Item not found',
          message: 'Could not find the specified item',
          debug: { itemData }
        });
      }
    } catch (error) {
      console.error('❌ GRAPHQL QUERY FAILED:', error);
      return res.status(500).json({ 
        error: 'GraphQL query failed',
        message: error.message,
        debug: { error: error.toString() }
      });
    }
    
    // PROCESS ITEM DATA
    console.log('🔍 PROCESSING ITEM DATA ===');
    
    const item = itemData.items[0];
    console.log('Item data:', JSON.stringify(item, null, 2));
    
    const sourceColumn = item.column_values.find(col => col.id === sourceColumnId);
    console.log('Column search results:', {
      lookingFor: sourceColumnId,
      availableColumns: item.column_values.map(col => ({ id: col.id, text: col.text })),
      foundColumn: sourceColumn
    });
    
    if (!sourceColumn || !sourceColumn.text) {
      console.log('❌ COLUMN ERROR: Source column not found or empty');
      return res.status(400).json({ 
        error: 'Empty source column',
        message: 'The source column is empty or not found',
        debug: { 
          sourceColumnId,
          availableColumns: item.column_values.map(col => ({ id: col.id, text: col.text })),
          foundColumn: sourceColumn
        }
      });
    }
    
    const barcodeValue = sourceColumn.text.trim();
    console.log('✅ COLUMN FOUND - Value:', barcodeValue);
    
    // GENERATE BARCODE
    console.log('🔄 GENERATING BARCODE ===');
    console.log('Barcode generation details:', {
      type: barcodeType,
      value: barcodeValue,
      targetColumn: targetColumnId
    });
    
    const barcodeResult = await barcodeService.generateBarcode({
      value: barcodeValue,
      type: barcodeType,
      userId: 'monday-action',
      boardId: boardId,
      itemId: itemId,
      columnId: targetColumnId
    });
    
    console.log('✅ BARCODE GENERATED - Uploading to Monday.com');
    
    // UPLOAD TO MONDAY.COM
    const uploadResult = await mondayService.uploadFileToColumn(
      itemId,
      targetColumnId,
      barcodeResult.data.imageBuffer,
      barcodeResult.data.filename,
      barcodeResult.data.mimeType,
      actualToken
    );
    
    console.log('✅ SUCCESS! Barcode generated and uploaded');
    console.log('Upload result:', uploadResult);
    
    res.status(200).json({
      success: true,
      message: `${barcodeType} barcode generated successfully`,
      data: {
        barcodeId: barcodeResult.data.id,
        filename: barcodeResult.data.filename,
        uploadId: uploadResult?.id
      }
    });
    
  } catch (error) {
    console.error('❌ ACTION FAILED:', error);
    logger.error(`${barcodeType} Action failed`, { error: error.message });
    
    res.status(500).json({
      error: 'Action failed',
      message: error.message || 'An error occurred processing the action'
    });
  }
}

// Create routes for each barcode type
const barcodeTypes = [
  { path: '/actions/create-qr-code', type: 'QR' },
  { path: '/actions/create-code128', type: 'CODE128' },
  { path: '/actions/create-ean13', type: 'EAN13' },
  { path: '/actions/create-ean8', type: 'EAN8' },
  { path: '/actions/create-upc-a', type: 'UPC_A' },
  { path: '/actions/create-code39', type: 'CODE39' },
  { path: '/actions/create-datamatrix', type: 'DATAMATRIX' }
];

// Register all routes
barcodeTypes.forEach(({ path, type }) => {
  router.post(path, (req, res) => handleBarcodeAction(req, res, type));
  router.options(path, (req, res) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.status(200).end();
  });
});

// Field definitions endpoint for Monday.com
router.get('/monday/fetchFieldDefs', async (req, res) => {
  try {
    const { boardId, field } = req.query;
    
    if (!boardId) {
      return res.status(400).json({ error: 'boardId is required' });
    }
    
    const authToken = req.headers.authorization;
    const actualToken = authToken?.startsWith('Bearer ') 
      ? authToken.substring(7) 
      : authToken;
    
    // Get board columns
    const query = `
      query GetBoard($boardId: [ID!]) {
        boards(ids: $boardId) {
          columns {
            id
            title
            type
          }
        }
      }
    `;
    
    const data = await mondayService.executeGraphQLQuery(
      actualToken,
      query,
      { boardId: [parseInt(boardId)] }
    );
    
    const columns = data?.boards?.[0]?.columns || [];
    
    // Format for Monday.com
    const options = columns.map(col => ({
      value: col.id,
      title: col.title
    }));
    
    res.json(options);
    
  } catch (error) {
    logger.error('Error fetching field definitions:', error);
    res.status(500).json({ error: 'Failed to fetch columns' });
  }
});

module.exports = router;