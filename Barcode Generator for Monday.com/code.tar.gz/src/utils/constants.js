/**
 * Application Constants
 * 
 * This file contains all the constants, enums, and configuration values
 * used throughout the Monday.com Barcode Generator application.
 */

// ==============================================
// APPLICATION CONSTANTS
// ==============================================

const APP_CONFIG = {
  NAME: 'Monday.com Barcode Generator',
  VERSION: '1.0.0',
  DESCRIPTION: 'A robust Monday.com app for generating and managing barcodes',
  APP_ID: '10481518',
  AUTHOR: 'Your Name',
  LICENSE: 'MIT'
};

// ==============================================
// API CONFIGURATION
// ==============================================

const API_CONFIG = {
  VERSION: 'v1',
  BASE_PATH: '/api',
  TIMEOUT: 30000, // 30 seconds
  MAX_REQUEST_SIZE: '10mb',
  RATE_LIMIT: {
    WINDOW_MS: 15 * 60 * 1000, // 15 minutes
    MAX_REQUESTS: 100,
    MESSAGE: 'Too many requests from this IP, please try again later.'
  }
};

// ==============================================
// MONDAY.COM CONFIGURATION
// ==============================================

const MONDAY_CONFIG = {
  API_URL: 'https://api.monday.com/v2',
  AUTH_URL: 'https://auth.monday.com/oauth2/authorize',
  TOKEN_URL: 'https://auth.monday.com/oauth2/token',
  API_VERSION: '2024-01',
  SCOPES: [
    'boards:read',
    'boards:write',
    'columns:read',
    'columns:write',
    'items:read',
    'items:write'
  ],
  WEBHOOK_EVENTS: [
    'create_item',
    'change_column_value',
    'create_subitem',
    'move_item',
    'archive_item',
    'delete_item',
    'create_board',
    'create_column'
  ]
};

// ==============================================
// BARCODE CONFIGURATION
// ==============================================

const BARCODE_CONFIG = {
  SUPPORTED_TYPES: [
    'code128',
    'code39',
    'code93',
    'ean13',
    'ean8',
    'upc',
    'qr',
    'datamatrix',
    'pdf417'
  ],
  SUPPORTED_FORMATS: [
    'png',
    'svg',
    'jpeg',
    'pdf'
  ],
  DEFAULT_DIMENSIONS: {
    WIDTH: 200,
    HEIGHT: 100
  },
  MAX_DIMENSIONS: {
    WIDTH: 2000,
    HEIGHT: 1000
  },
  MIN_DIMENSIONS: {
    WIDTH: 50,
    HEIGHT: 20
  },
  DEFAULT_TYPE: 'code128',
  DEFAULT_FORMAT: 'png',
  MAX_DATA_LENGTH: 500,
  EXPIRY_DAYS: 7
};

// ==============================================
// HTTP STATUS CODES
// ==============================================

const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  ACCEPTED: 202,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  METHOD_NOT_ALLOWED: 405,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500,
  BAD_GATEWAY: 502,
  SERVICE_UNAVAILABLE: 503,
  GATEWAY_TIMEOUT: 504
};

// ==============================================
// ERROR CODES
// ==============================================

const ERROR_CODES = {
  // General errors
  INTERNAL_SERVER_ERROR: 'INTERNAL_SERVER_ERROR',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  NOT_FOUND: 'NOT_FOUND',
  BAD_REQUEST: 'BAD_REQUEST',
  UNAUTHORIZED: 'UNAUTHORIZED',
  FORBIDDEN: 'FORBIDDEN',
  
  // Authentication errors
  AUTH_HEADER_MISSING: 'AUTH_HEADER_MISSING',
  JWT_TOKEN_MISSING: 'JWT_TOKEN_MISSING',
  JWT_TOKEN_EXPIRED: 'JWT_TOKEN_EXPIRED',
  INVALID_JWT_TOKEN: 'INVALID_JWT_TOKEN',
  REFRESH_TOKEN_REQUIRED: 'REFRESH_TOKEN_REQUIRED',
  
  // Monday.com errors
  MONDAY_AUTH_FAILED: 'MONDAY_AUTH_FAILED',
  MONDAY_TOKEN_MISSING: 'MONDAY_TOKEN_MISSING',
  MONDAY_TOKEN_INVALID: 'MONDAY_TOKEN_INVALID',
  MONDAY_API_ERROR: 'MONDAY_API_ERROR',
  BOARD_NOT_FOUND: 'BOARD_NOT_FOUND',
  ITEM_NOT_FOUND: 'ITEM_NOT_FOUND',
  
  // Barcode errors
  BARCODE_GENERATION_FAILED: 'BARCODE_GENERATION_FAILED',
  BARCODE_NOT_FOUND: 'BARCODE_NOT_FOUND',
  BARCODE_VALIDATION_FAILED: 'BARCODE_VALIDATION_FAILED',
  UNSUPPORTED_BARCODE_TYPE: 'UNSUPPORTED_BARCODE_TYPE',
  UNSUPPORTED_FORMAT: 'UNSUPPORTED_FORMAT',
  
  // Rate limiting
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  
  // File upload errors
  FILE_SIZE_EXCEEDED: 'FILE_SIZE_EXCEEDED',
  INVALID_FILE_TYPE: 'INVALID_FILE_TYPE',
  
  // Webhook errors
  WEBHOOK_SIGNATURE_INVALID: 'WEBHOOK_SIGNATURE_INVALID',
  WEBHOOK_PROCESSING_ERROR: 'WEBHOOK_PROCESSING_ERROR'
};

// ==============================================
// LOG LEVELS
// ==============================================

const LOG_LEVELS = {
  ERROR: 'error',
  WARN: 'warn',
  INFO: 'info',
  HTTP: 'http',
  DEBUG: 'debug'
};

// ==============================================
// LOG TYPES
// ==============================================

const LOG_TYPES = {
  USER_ACTIVITY: 'USER_ACTIVITY',
  API_REQUEST: 'API_REQUEST',
  MONDAY_API: 'MONDAY_API',
  BARCODE_OPERATION: 'BARCODE_OPERATION',
  SECURITY_EVENT: 'SECURITY_EVENT',
  PERFORMANCE: 'PERFORMANCE',
  APPLICATION_ERROR: 'APPLICATION_ERROR',
  WEBHOOK_EVENT: 'WEBHOOK_EVENT',
  RATE_LIMIT: 'RATE_LIMIT',
  APP_STARTUP: 'APP_STARTUP',
  APP_SHUTDOWN: 'APP_SHUTDOWN',
  DATABASE_OPERATION: 'DATABASE_OPERATION'
};

// ==============================================
// USER ROLES AND PERMISSIONS
// ==============================================

const USER_ROLES = {
  ADMIN: 'admin',
  USER: 'user',
  GUEST: 'guest'
};

const PERMISSIONS = {
  READ_BOARDS: 'boards:read',
  WRITE_BOARDS: 'boards:write',
  READ_ITEMS: 'items:read',
  WRITE_ITEMS: 'items:write',
  READ_COLUMNS: 'columns:read',
  WRITE_COLUMNS: 'columns:write',
  GENERATE_BARCODES: 'barcodes:generate',
  MANAGE_BARCODES: 'barcodes:manage',
  EXPORT_DATA: 'data:export',
  ADMIN_ACCESS: 'admin:access'
};

// ==============================================
// FILE CONFIGURATION
// ==============================================

const FILE_CONFIG = {
  MAX_SIZE: 10 * 1024 * 1024, // 10MB
  ALLOWED_IMAGE_TYPES: [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml'
  ],
  ALLOWED_DOCUMENT_TYPES: [
    'application/pdf',
    'text/csv',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-excel'
  ],
  UPLOAD_PATH: 'uploads/',
  TEMP_PATH: 'temp/'
};

// ==============================================
// CACHE CONFIGURATION
// ==============================================

const CACHE_CONFIG = {
  DEFAULT_TTL: 3600, // 1 hour
  LONG_TTL: 24 * 3600, // 24 hours
  SHORT_TTL: 300, // 5 minutes
  KEYS: {
    USER_BOARDS: 'user_boards:',
    BOARD_COLUMNS: 'board_columns:',
    USER_PROFILE: 'user_profile:',
    BARCODE_STATS: 'barcode_stats:'
  }
};

// ==============================================
// PAGINATION DEFAULTS
// ==============================================

const PAGINATION = {
  DEFAULT_LIMIT: 50,
  MAX_LIMIT: 1000,
  DEFAULT_OFFSET: 0
};

// ==============================================
// SECURITY CONFIGURATION
// ==============================================

const SECURITY_CONFIG = {
  JWT_EXPIRES_IN: '24h',
  JWT_REFRESH_EXPIRES_IN: '7d',
  BCRYPT_ROUNDS: 12,
  SESSION_TIMEOUT: 24 * 60 * 60 * 1000, // 24 hours
  MAX_LOGIN_ATTEMPTS: 5,
  LOCKOUT_TIME: 15 * 60 * 1000, // 15 minutes
  PASSWORD_MIN_LENGTH: 8,
  PASSWORD_REQUIREMENTS: {
    LOWERCASE: true,
    UPPERCASE: true,
    NUMBERS: true,
    SPECIAL_CHARS: true
  }
};

// ==============================================
// EMAIL CONFIGURATION
// ==============================================

const EMAIL_CONFIG = {
  FROM_ADDRESS: 'noreply@monday-barcode-generator.com',
  FROM_NAME: 'Monday.com Barcode Generator',
  TEMPLATES: {
    WELCOME: 'welcome',
    PASSWORD_RESET: 'password_reset',
    ACCOUNT_VERIFICATION: 'account_verification',
    NOTIFICATION: 'notification'
  }
};

// ==============================================
// WEBHOOK CONFIGURATION
// ==============================================

const WEBHOOK_CONFIG = {
  TIMEOUT: 5000, // 5 seconds
  MAX_RETRIES: 3,
  RETRY_DELAY: 1000, // 1 second
  SIGNATURE_HEADER: 'authorization',
  SUPPORTED_EVENTS: [
    'barcode.generated',
    'barcode.deleted',
    'board.connected',
    'item.updated'
  ]
};

// ==============================================
// REGEX PATTERNS
// ==============================================

const REGEX_PATTERNS = {
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  UUID: /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
  MONDAY_ID: /^\d+$/,
  BARCODE_DATA: {
    CODE128: /^[\x00-\x7F]*$/,
    CODE39: /^[A-Z0-9\-\.\$\/\+%\s]*$/,
    EAN13: /^\d{12,13}$/,
    EAN8: /^\d{7,8}$/,
    UPC: /^\d{11,12}$/
  },
  PASSWORD: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,
  PHONE: /^\+?[\d\s\-\(\)]+$/,
  URL: /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/
};

// ==============================================
// DATE FORMATS
// ==============================================

const DATE_FORMATS = {
  ISO: 'YYYY-MM-DDTHH:mm:ss.sssZ',
  DISPLAY: 'MMM DD, YYYY',
  DISPLAY_WITH_TIME: 'MMM DD, YYYY HH:mm',
  API: 'YYYY-MM-DD',
  FILE_NAME: 'YYYYMMDD_HHmmss',
  LOG: 'YYYY-MM-DD HH:mm:ss'
};

// ==============================================
// ENVIRONMENT CONSTANTS
// ==============================================

const ENVIRONMENTS = {
  DEVELOPMENT: 'development',
  STAGING: 'staging',
  PRODUCTION: 'production',
  TEST: 'test'
};

// ==============================================
// FEATURE FLAGS
// ==============================================

const FEATURE_FLAGS = {
  ENABLE_BARCODE_GENERATION: 'ENABLE_BARCODE_GENERATION',
  ENABLE_BATCH_PROCESSING: 'ENABLE_BATCH_PROCESSING',
  ENABLE_EXPORT_FEATURES: 'ENABLE_EXPORT_FEATURES',
  ENABLE_WEBHOOK_SUBSCRIPTIONS: 'ENABLE_WEBHOOK_SUBSCRIPTIONS',
  ENABLE_RATE_LIMITING: 'ENABLE_RATE_LIMITING',
  ENABLE_CACHING: 'ENABLE_CACHING',
  ENABLE_EMAIL_NOTIFICATIONS: 'ENABLE_EMAIL_NOTIFICATIONS'
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  APP_CONFIG,
  API_CONFIG,
  MONDAY_CONFIG,
  BARCODE_CONFIG,
  HTTP_STATUS,
  ERROR_CODES,
  LOG_LEVELS,
  LOG_TYPES,
  USER_ROLES,
  PERMISSIONS,
  FILE_CONFIG,
  CACHE_CONFIG,
  PAGINATION,
  SECURITY_CONFIG,
  EMAIL_CONFIG,
  WEBHOOK_CONFIG,
  REGEX_PATTERNS,
  DATE_FORMATS,
  ENVIRONMENTS,
  FEATURE_FLAGS
}; 