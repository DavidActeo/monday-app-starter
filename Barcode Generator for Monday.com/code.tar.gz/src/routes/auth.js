/**
 * Authentication Routes
 * Handles OAuth flow with Monday.com
 */

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const axios = require('axios');
const { body, query } = require('express-validator');
const validationMiddleware = require('../middleware/validation');
const logger = require('../utils/logger');

/**
 * @route   GET /auth/login
 * @desc    Initiate OAuth flow with Monday.com
 * @access  Public
 */
router.get('/login', (req, res) => {
  const clientId = process.env.MONDAY_CLIENT_ID || 'b9c06a0772299592886578fb1c529588';
  const redirectUri = `${req.protocol}://${req.get('host')}/auth/callback`;
  const state = jwt.sign({ timestamp: Date.now() }, process.env.JWT_SECRET || 'fallback-secret', { expiresIn: '10m' });
  
  const mondayAuthUrl = `https://auth.monday.com/oauth2/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&state=${state}`;
  
  logger.info('OAuth login initiated', { clientId, redirectUri, state });
  res.redirect(mondayAuthUrl);
});

/**
 * @route   GET /auth/callback
 * @desc    Handle OAuth callback from Monday.com
 * @access  Public
 */
router.get('/callback', [
  query('code').notEmpty().withMessage('Authorization code is required'),
  query('state').notEmpty().withMessage('State parameter is required')
], validationMiddleware.handleValidationErrors, async (req, res) => {
  try {
    const { code, state } = req.query;
    
    // Verify state parameter
    try {
      jwt.verify(state, process.env.JWT_SECRET || 'fallback-secret');
    } catch (error) {
      logger.error('Invalid state parameter in OAuth callback', { state });
      return res.status(400).json({ error: 'Invalid state parameter' });
    }
    
    // Exchange code for access token
    const clientId = process.env.MONDAY_CLIENT_ID || 'b9c06a0772299592886578fb1c529588';
    const clientSecret = process.env.MONDAY_CLIENT_SECRET;
    const redirectUri = `${req.protocol}://${req.get('host')}/auth/callback`;
    
    if (!clientSecret) {
      logger.error('Monday client secret not configured');
      return res.status(500).json({ error: 'OAuth configuration incomplete' });
    }
    
    const tokenResponse = await axios.post('https://auth.monday.com/oauth2/token', {
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
      code: code
    });
    
    const { access_token, scope, account_id } = tokenResponse.data;
    
    logger.info('OAuth token exchange successful', { account_id, scope });
    
    // In a real app, you'd save this token to a database
    // For now, we'll just return success
    res.json({
      success: true,
      message: 'Authentication successful',
      data: {
        account_id,
        scope,
        // Don't return the actual token in production
        token_received: !!access_token
      }
    });
    
  } catch (error) {
    logger.error('OAuth callback failed', { error: error.message });
    res.status(500).json({
      error: 'Authentication failed',
      details: error.message
    });
  }
});

/**
 * @route   POST /auth/verify
 * @desc    Verify Monday.com JWT token
 * @access  Public
 */
router.post('/verify', [
  body('token').notEmpty().withMessage('Token is required')
], validationMiddleware.handleValidationErrors, async (req, res) => {
  try {
    const { token } = req.body;
    
    // Verify the JWT token from Monday.com
    // In production, you'd verify this against Monday.com's public key
    const decoded = jwt.decode(token);
    
    if (!decoded) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    
    logger.info('Token verification successful', { userId: decoded.userId, accountId: decoded.accountId });
    
    res.json({
      success: true,
      data: {
        userId: decoded.userId,
        accountId: decoded.accountId,
        aud: decoded.aud
      }
    });
    
  } catch (error) {
    logger.error('Token verification failed', { error: error.message });
    res.status(401).json({
      error: 'Token verification failed',
      details: error.message
    });
  }
});

module.exports = router; 