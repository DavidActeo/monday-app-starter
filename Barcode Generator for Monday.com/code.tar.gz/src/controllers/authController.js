/**
 * Authentication Controller
 * 
 * This file contains controller functions for Monday.com OAuth authentication,
 * token management, and user session handling.
 */

const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const logger = require('../utils/logger');
const mondayService = require('../services/mondayService');
const { createError } = require('../middleware/errorHandler');

// ==============================================
// OAUTH FLOW ENDPOINTS
// ==============================================

/**
 * Initiate Monday.com OAuth flow
 * GET /auth/monday
 */
const initiateOAuth = async (req, res, next) => {
  try {
    const state = crypto.randomBytes(32).toString('hex');
    
    // Store state in session for validation (in production, use Redis or database)
    req.session.oauthState = state;

    const authUrl = `https://auth.monday.com/oauth2/authorize` +
      `?client_id=${process.env.MONDAY_CLIENT_ID}` +
      `&response_type=code` +
      `&scope=boards:read boards:write columns:read columns:write items:read items:write` +
      `&redirect_uri=${encodeURIComponent(process.env.MONDAY_REDIRECT_URI || 'http://localhost:3000/auth/monday/callback')}` +
      `&state=${state}`;

    logger.info('OAuth flow initiated', {
      state: state,
      redirectUri: process.env.MONDAY_REDIRECT_URI
    });

    res.status(200).json({
      status: 'success',
      data: {
        authUrl: authUrl,
        state: state
      }
    });

  } catch (error) {
    logger.error('Error initiating OAuth flow:', error);
    next(createError(500, 'Failed to initiate OAuth flow', 'OAUTH_INIT_FAILED'));
  }
};

/**
 * Handle Monday.com OAuth callback
 * GET /auth/monday/callback
 */
const handleOAuthCallback = async (req, res, next) => {
  try {
    const { code, state, error } = req.query;

    // Handle OAuth errors
    if (error) {
      logger.error('OAuth callback error:', error);
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=${error}`);
    }

    // Validate state parameter
    if (!state || state !== req.session.oauthState) {
      logger.error('Invalid OAuth state parameter');
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=invalid_state`);
    }

    if (!code) {
      logger.error('Authorization code missing from callback');
      return res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=code_missing`);
    }

    // Exchange code for tokens
    const tokenData = await exchangeCodeForTokens(code);
    
    // Get user information from Monday.com
    const userInfo = await mondayService.getCurrentUser(tokenData.access_token);

    // Create JWT token for our application
    const jwtToken = jwt.sign(
      {
        id: userInfo.id,
        name: userInfo.name,
        email: userInfo.email,
        accountId: userInfo.account?.id,
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token,
        scopes: tokenData.scope?.split(' ') || [],
        tokenType: tokenData.token_type || 'Bearer'
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    logger.info('OAuth callback successful', {
      userId: userInfo.id,
      accountId: userInfo.account?.id
    });

    // Clear OAuth state from session
    delete req.session.oauthState;

    // Redirect to frontend with token
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?token=${jwtToken}`);

  } catch (error) {
    logger.error('Error handling OAuth callback:', error);
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}?error=callback_failed`);
  }
};

/**
 * Exchange authorization code for access token
 * POST /auth/monday/token
 */
const exchangeToken = async (req, res, next) => {
  try {
    const { code, state } = req.body;

    // Validate state if provided
    if (state && req.session.oauthState && state !== req.session.oauthState) {
      return next(createError(400, 'Invalid state parameter', 'INVALID_STATE'));
    }

    if (!code) {
      return next(createError(400, 'Authorization code is required', 'CODE_REQUIRED'));
    }

    // Exchange code for tokens
    const tokenData = await exchangeCodeForTokens(code);
    
    // Get user information
    const userInfo = await mondayService.getCurrentUser(tokenData.access_token);

    // Create JWT token
    const jwtToken = jwt.sign(
      {
        id: userInfo.id,
        name: userInfo.name,
        email: userInfo.email,
        accountId: userInfo.account?.id,
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token,
        scopes: tokenData.scope?.split(' ') || [],
        tokenType: tokenData.token_type || 'Bearer'
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    logger.info('Token exchange successful', {
      userId: userInfo.id,
      accountId: userInfo.account?.id
    });

    res.status(200).json({
      status: 'success',
      data: {
        token: jwtToken,
        tokenType: 'Bearer',
        expiresIn: process.env.JWT_EXPIRES_IN || '24h',
        user: {
          id: userInfo.id,
          name: userInfo.name,
          email: userInfo.email,
          accountId: userInfo.account?.id
        }
      }
    });

  } catch (error) {
    logger.error('Error exchanging token:', error);
    next(createError(500, 'Failed to exchange authorization code', 'TOKEN_EXCHANGE_FAILED'));
  }
};

// ==============================================
// TOKEN MANAGEMENT
// ==============================================

/**
 * Refresh access token using refresh token
 * POST /auth/refresh
 */
const refreshToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return next(createError(400, 'Refresh token is required', 'REFRESH_TOKEN_REQUIRED'));
    }

    // Refresh the Monday.com token
    const newTokenData = await refreshMondayToken(refreshToken);
    
    // Get updated user information
    const userInfo = await mondayService.getCurrentUser(newTokenData.access_token);

    // Create new JWT token
    const jwtToken = jwt.sign(
      {
        id: userInfo.id,
        name: userInfo.name,
        email: userInfo.email,
        accountId: userInfo.account?.id,
        accessToken: newTokenData.access_token,
        refreshToken: newTokenData.refresh_token || refreshToken,
        scopes: newTokenData.scope?.split(' ') || [],
        tokenType: newTokenData.token_type || 'Bearer'
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    logger.info('Token refresh successful', {
      userId: userInfo.id
    });

    res.status(200).json({
      status: 'success',
      data: {
        token: jwtToken,
        tokenType: 'Bearer',
        expiresIn: process.env.JWT_EXPIRES_IN || '24h'
      }
    });

  } catch (error) {
    logger.error('Error refreshing token:', error);
    next(createError(401, 'Failed to refresh token', 'TOKEN_REFRESH_FAILED'));
  }
};

/**
 * Validate current access token
 * POST /auth/validate
 */
const validateToken = async (req, res, next) => {
  try {
    const user = req.user;

    // Test Monday.com token validity
    const userInfo = await mondayService.getCurrentUser(user.accessToken);

    res.status(200).json({
      status: 'success',
      data: {
        valid: true,
        user: {
          id: userInfo.id,
          name: userInfo.name,
          email: userInfo.email,
          accountId: userInfo.account?.id
        },
        tokenInfo: {
          scopes: user.scopes || [],
          tokenType: user.tokenType || 'Bearer',
          expiresAt: user.exp ? new Date(user.exp * 1000).toISOString() : null
        }
      }
    });

  } catch (error) {
    logger.error('Error validating token:', error);
    
    if (error.response && error.response.status === 401) {
      return next(createError(401, 'Token is invalid or expired', 'TOKEN_INVALID'));
    }
    
    next(createError(500, 'Failed to validate token', 'TOKEN_VALIDATION_FAILED'));
  }
};

/**
 * Logout user and invalidate tokens
 * POST /auth/logout
 */
const logout = async (req, res, next) => {
  try {
    const user = req.user;

    logger.info('User logout requested', {
      userId: user.id
    });

    // In a production app, you might want to:
    // 1. Add JWT to a blacklist
    // 2. Revoke Monday.com tokens
    // 3. Clear any stored session data

    // For now, we'll just log the logout
    // TODO: Implement token blacklisting or revocation

    res.status(200).json({
      status: 'success',
      message: 'Logged out successfully'
    });

  } catch (error) {
    logger.error('Error during logout:', error);
    next(createError(500, 'Failed to logout', 'LOGOUT_FAILED'));
  }
};

// ==============================================
// USER INFORMATION
// ==============================================

/**
 * Get current user information from Monday.com
 * GET /auth/me
 */
const getCurrentUser = async (req, res, next) => {
  try {
    const user = req.user;
    const userInfo = await mondayService.getCurrentUser(user.accessToken);

    res.status(200).json({
      status: 'success',
      data: {
        id: userInfo.id,
        name: userInfo.name,
        email: userInfo.email,
        photo_original: userInfo.photo_original,
        photo_small: userInfo.photo_small,
        account: userInfo.account ? {
          id: userInfo.account.id,
          name: userInfo.account.name,
          slug: userInfo.account.slug
        } : null,
        permissions: user.scopes || []
      }
    });

  } catch (error) {
    logger.error('Error fetching current user:', error);
    next(createError(500, 'Failed to fetch user information', 'USER_FETCH_FAILED'));
  }
};

/**
 * Get user's app permissions and scopes
 * GET /auth/permissions
 */
const getUserPermissions = async (req, res, next) => {
  try {
    const user = req.user;

    res.status(200).json({
      status: 'success',
      data: {
        scopes: user.scopes || [],
        permissions: {
          canReadBoards: user.scopes?.includes('boards:read') || false,
          canWriteBoards: user.scopes?.includes('boards:write') || false,
          canReadItems: user.scopes?.includes('items:read') || false,
          canWriteItems: user.scopes?.includes('items:write') || false,
          canReadColumns: user.scopes?.includes('columns:read') || false,
          canWriteColumns: user.scopes?.includes('columns:write') || false
        }
      }
    });

  } catch (error) {
    logger.error('Error fetching user permissions:', error);
    next(createError(500, 'Failed to fetch user permissions', 'PERMISSIONS_FETCH_FAILED'));
  }
};

// ==============================================
// WEBHOOK VERIFICATION
// ==============================================

/**
 * Verify webhook signature from Monday.com
 * POST /auth/verify-webhook
 */
const verifyWebhookSignature = async (req, res, next) => {
  try {
    const { payload, signature } = req.body;

    const expectedSignature = crypto
      .createHmac('sha256', process.env.MONDAY_SIGNING_SECRET || 'default-secret')
      .update(JSON.stringify(payload))
      .digest('hex');

    const isValid = crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );

    res.status(200).json({
      status: 'success',
      data: {
        valid: isValid
      }
    });

  } catch (error) {
    logger.error('Error verifying webhook signature:', error);
    next(createError(500, 'Failed to verify webhook signature', 'WEBHOOK_VERIFICATION_FAILED'));
  }
};

// ==============================================
// DEVELOPMENT ENDPOINTS
// ==============================================

/**
 * Test Monday.com API connection (development only)
 * GET /auth/debug/monday-api
 */
const testMondayApiConnection = async (req, res, next) => {
  try {
    const user = req.user;
    
    const testResult = await mondayService.testApiConnection(user.accessToken);

    res.status(200).json({
      status: 'success',
      data: {
        connected: testResult.connected,
        user: testResult.user,
        responseTime: testResult.responseTime,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    logger.error('Error testing Monday.com API connection:', error);
    next(createError(500, 'Failed to test API connection', 'API_CONNECTION_TEST_FAILED'));
  }
};

// ==============================================
// HELPER FUNCTIONS
// ==============================================

/**
 * Exchange authorization code for access tokens
 */
const exchangeCodeForTokens = async (code) => {
  const tokenResponse = await mondayService.exchangeCodeForTokens(code);
  return tokenResponse;
};

/**
 * Refresh Monday.com access token
 */
const refreshMondayToken = async (refreshToken) => {
  const tokenResponse = await mondayService.refreshAccessToken(refreshToken);
  return tokenResponse;
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  initiateOAuth,
  handleOAuthCallback,
  exchangeToken,
  refreshToken,
  validateToken,
  logout,
  getCurrentUser,
  getUserPermissions,
  verifyWebhookSignature,
  testMondayApiConnection
}; 