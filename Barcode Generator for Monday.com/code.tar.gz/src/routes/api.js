/**
 * API Routes - Main API endpoints for the Monday.com Barcode Generator
 * 
 * This file contains all the main API routes for barcode generation,
 * Monday.com interactions, and general app functionality.
 */

const express = require('express');
const router = express.Router();
const { body, param, query } = require('express-validator');

// Controllers
const barcodeController = require('../controllers/barcodeController');
const mondayController = require('../controllers/mondayController');

// Services
const pricingService = require('../services/pricingService');

// Middleware
const authMiddleware = require('../middleware/auth');
const validationMiddleware = require('../middleware/validation');

// ==============================================
// HEALTH & STATUS ENDPOINTS
// ==============================================

/**
 * @route   GET /api/health
 * @desc    API health check endpoint
 * @access  Public
 */
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'API is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

/**
 * @route   GET /api/status
 * @desc    Get application status and configuration
 * @access  Private
 */
router.get('/status', authMiddleware.authenticate, (req, res) => {
  res.status(200).json({
    status: 'success',
    data: {
      appId: process.env.MONDAY_APP_ID,
      environment: process.env.NODE_ENV,
      features: {
        barcodeGeneration: process.env.ENABLE_BARCODE_GENERATION === 'true',
        batchProcessing: process.env.ENABLE_BATCH_PROCESSING === 'true',
        exportFeatures: process.env.ENABLE_EXPORT_FEATURES === 'true'
      }
    }
  });
});

// ==============================================
// BARCODE ENDPOINTS (Placeholder for future implementation)
// ==============================================

/**
 * @route   POST /api/barcode/generate
 * @desc    Generate a barcode and upload to Monday.com File column
 * @access  Private
 */
router.post('/barcode/generate',
  authMiddleware.authenticate,
  [
    body('value').notEmpty().withMessage('Barcode value is required'),
    body('type').isIn(['CODE128', 'QR']).withMessage('Invalid barcode type - must be CODE128 or QR'),
    body('boardId').notEmpty().withMessage('Board ID is required'),
    body('itemId').notEmpty().withMessage('Item ID is required'),
    body('columnId').notEmpty().withMessage('File column ID is required'),
    body('width').optional().isInt({ min: 50, max: 1000 }).withMessage('Width must be between 50 and 1000'),
    body('height').optional().isInt({ min: 20, max: 500 }).withMessage('Height must be between 20 and 500')
  ],
  validationMiddleware.handleValidationErrors,
  barcodeController.generateBarcodeAndUpload
);

/**
 * @route   GET /api/barcode/history
 * @desc    Get barcode generation history for user
 * @access  Private
 */
router.get('/barcode/history',
  authMiddleware.authenticate,
  [
    query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
    query('offset').optional().isInt({ min: 0 }).withMessage('Offset must be a positive integer')
  ],
  validationMiddleware.handleValidationErrors,
  barcodeController.getBarcodeHistory
);

/**
 * @route   GET /api/barcode/:id
 * @desc    Get barcode details by ID
 * @access  Private
 */
router.get('/barcode/:id',
  authMiddleware.authenticate,
  [
    param('id').isUUID().withMessage('Invalid barcode ID')
  ],
  validationMiddleware.handleValidationErrors,
  barcodeController.getBarcodeById
);

/**
 * @route   DELETE /api/barcode/:id
 * @desc    Delete a generated barcode
 * @access  Private
 */
router.delete('/barcode/:id',
  authMiddleware.authenticate,
  [
    param('id').isUUID().withMessage('Invalid barcode ID')
  ],
  validationMiddleware.handleValidationErrors,
  barcodeController.deleteBarcode
);

// ==============================================
// ACTION BLOCK ENDPOINTS
// ==============================================

/**
 * @route   POST /api/actions/create-qr-code
 * @desc    Monday.com Action Block - Generate QR code from column value and save to file column
 * @access  Public (Monday.com webhook)
 */
router.post('/actions/create-qr-code', async (req, res) => {
  await handleBarcodeAction(req, res, 'QR');
});

/**
 * @route   OPTIONS /api/actions/create-qr-code
 * @desc    Handle CORS preflight for QR code Action Block endpoint
 * @access  Public
 */
router.options('/actions/create-qr-code', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(200).end();
});

/**
 * @route   POST /api/actions/create-code128
 * @desc    Monday.com Action Block - Generate Code 128 barcode from column value and save to file column
 * @access  Public (Monday.com webhook)
 */
router.post('/actions/create-code128', async (req, res) => {
  await handleBarcodeAction(req, res, 'CODE128');
});

/**
 * @route   OPTIONS /api/actions/create-code128
 * @desc    Handle CORS preflight for Code 128 Action Block endpoint
 * @access  Public
 */
router.options('/actions/create-code128', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(200).end();
});

/**
 * @route   POST /api/actions/create-ean13
 * @desc    Monday.com Action Block - Generate EAN-13 barcode from column value and save to file column
 * @access  Public (Monday.com webhook)
 */
router.post('/actions/create-ean13', async (req, res) => {
  await handleBarcodeAction(req, res, 'EAN13');
});

/**
 * @route   OPTIONS /api/actions/create-ean13
 * @desc    Handle CORS preflight for EAN-13 Action Block endpoint
 * @access  Public
 */
router.options('/actions/create-ean13', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(200).end();
});

/**
 * @route   POST /api/actions/create-ean8
 * @desc    Monday.com Action Block - Generate EAN-8 barcode from column value and save to file column
 * @access  Public (Monday.com webhook)
 */
router.post('/actions/create-ean8', async (req, res) => {
  await handleBarcodeAction(req, res, 'EAN8');
});

/**
 * @route   OPTIONS /api/actions/create-ean8
 * @desc    Handle CORS preflight for EAN-8 Action Block endpoint
 * @access  Public
 */
router.options('/actions/create-ean8', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(200).end();
});

/**
 * @route   POST /api/actions/create-upc-a
 * @desc    Monday.com Action Block - Generate UPC-A barcode from column value and save to file column
 * @access  Public (Monday.com webhook)
 */
router.post('/actions/create-upc-a', async (req, res) => {
  await handleBarcodeAction(req, res, 'UPC_A');
});

/**
 * @route   OPTIONS /api/actions/create-upc-a
 * @desc    Handle CORS preflight for UPC-A Action Block endpoint
 * @access  Public
 */
router.options('/actions/create-upc-a', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(200).end();
});

/**
 * @route   POST /api/actions/create-code39
 * @desc    Monday.com Action Block - Generate Code 39 barcode from column value and save to file column
 * @access  Public (Monday.com webhook)
 */
router.post('/actions/create-code39', async (req, res) => {
  await handleBarcodeAction(req, res, 'CODE39');
});

/**
 * @route   OPTIONS /api/actions/create-code39
 * @desc    Handle CORS preflight for Code 39 Action Block endpoint
 * @access  Public
 */
router.options('/actions/create-code39', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(200).end();
});

/**
 * @route   POST /api/actions/create-datamatrix
 * @desc    Monday.com Action Block - Generate DataMatrix barcode from column value and save to file column
 * @access  Public (Monday.com webhook)
 */
router.post('/actions/create-datamatrix', async (req, res) => {
  await handleBarcodeAction(req, res, 'DATAMATRIX');
});

/**
 * @route   OPTIONS /api/actions/create-datamatrix
 * @desc    Handle CORS preflight for DataMatrix Action Block endpoint
 * @access  Public
 */
router.options('/actions/create-datamatrix', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(200).end();
});

/**
 * Shared handler function for all barcode action endpoints
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {string} barcodeType - The barcode type to generate
 */
async function handleBarcodeAction(req, res, barcodeType) {
  const logger = require('../utils/logger');
  
  try {
    // Set CORS headers
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    // Log the action request
    logger.info(`${barcodeType} Action Block request received`, { 
      method: req.method,
      url: req.url,
      hasBody: !!req.body,
      hasAuth: !!req.headers.authorization
    });
    
    // CRITICAL: Log the EXACT payload Monday.com sends us
    console.log('🔍 MONDAY.COM PAYLOAD DEBUG:');
    console.log('Headers:', JSON.stringify(req.headers, null, 2));
    console.log('Body:', JSON.stringify(req.body, null, 2));
    console.log('Body Type:', typeof req.body);
    console.log('Body Keys:', req.body ? Object.keys(req.body) : 'No body');
    
    // If body is empty, it might be a parsing issue
    if (!req.body || Object.keys(req.body).length === 0) {
      console.log('⚠️ EMPTY BODY DETECTED - Checking raw body');
      console.log('Content-Type:', req.headers['content-type']);
      console.log('Content-Length:', req.headers['content-length']);
    }
    
    // Validate request structure
    if (!req.body) {
      logger.error('Missing request body');
      return res.status(400).json({ 
        error: 'Missing request body',
        message: 'Request body is required for Monday.com action blocks' 
      });
    }
    
    // Monday.com sends different payload structures based on the integration type
    let payload = req.body;
    
    // Check if payload is wrapped
    if (req.body.payload) {
      // If payload is a string, parse it
      if (typeof req.body.payload === 'string') {
        try {
          payload = JSON.parse(req.body.payload);
          console.log('📦 Parsed string payload:', JSON.stringify(payload, null, 2));
        } catch (e) {
          logger.error('Failed to parse payload string', { error: e.message });
      return res.status(400).json({ 
            error: 'Invalid payload format',
            message: 'Could not parse payload JSON string' 
          });
        }
      } else {
        payload = req.body.payload;
      }
    }
    
    // CRITICAL FIX: Monday.com action blocks use different field names!
    // Based on the Monday.com quickstart integration examples:
    // - They use 'inputFields' for the configured column mappings
    // - They use 'subscriptionId' not 'integrationId'
    // - The actual column values come from trigger output
    
    // Try multiple payload structures to handle different Monday.com versions
    const inputFields = payload.inputFields || payload.input_fields || {};
    const subscriptionId = payload.subscriptionId || payload.subscription_id;
    const userId = payload.userId || payload.user_id;
    const accountId = payload.accountId || payload.account_id;
    
    // For action blocks, Monday.com passes trigger output data
    const triggerOutput = payload.trigger_output || payload.triggerOutput || {};
    
    // Extract board and item info from various possible locations
    const boardId = triggerOutput.boardId || payload.boardId || payload.board_id;
    const itemId = triggerOutput.itemId || payload.itemId || payload.item_id;
    
    console.log('📊 Extracted IDs:', { boardId, itemId, subscriptionId, userId });
    
    // Get auth token from headers
    const authToken = req.headers.authorization;
    
    // Validate we have the essential data
    if (!boardId || !itemId) {
      logger.error('Missing board or item ID in Monday.com payload', { 
        boardId, 
        itemId,
        payload: JSON.stringify(payload, null, 2)
      });
      return res.status(400).json({ 
        error: 'Missing required IDs',
        message: 'Monday.com did not send boardId or itemId in the payload'
      });
    }
    
    if (!authToken) {
      logger.error('Missing authorization token', { headers: req.headers });
      return res.status(401).json({ 
        error: 'Missing authorization',
        message: 'No authorization token provided in headers'
      });
    }
    
    // Extract column IDs from Monday.com's inputFields
    // Monday.com uses specific field names in the recipe configuration
    const sourceColumnId = inputFields.sourceColumnId || inputFields.source_column_id || inputFields.columnId || inputFields.column_id;
    const targetFileColumnId = inputFields.targetColumnId || inputFields.target_column_id || inputFields.fileColumnId || inputFields.file_column_id;
    
    // SECURE VALUE EXTRACTION with input validation and sanitization
    let barcodeValue = null;
    
    // For action blocks, we need to get the column value from the item
    // Monday.com doesn't send the actual values in the payload for actions
    // We need to query the item to get the column values
    
    console.log('🔍 Source column ID:', sourceColumnId);
    console.log('🔍 Target column ID:', targetFileColumnId);
    
    // If we don't have column IDs, we can't proceed
    if (!sourceColumnId || !targetFileColumnId) {
      logger.error('Missing column IDs', { sourceColumnId, targetFileColumnId });
      return res.status(400).json({ 
        error: 'Missing column configuration',
        message: 'Source or target column not configured in the recipe'
      });
    }
    
    // Import Monday service
    const mondayService = require('../services/mondayService');
    
    // Query the item to get the column value
    try {
      console.log('📊 Querying item from Monday.com:', { boardId, itemId });
      
    const query = `
        query GetItemColumnValue($itemId: [ID!]) {
        items(ids: $itemId) {
            id
            name
          column_values {
            id
            text
            value
          }
        }
      }
    `;
    
      const variables = {
        itemId: [itemId]
      };
      
      const itemData = await mondayService.executeGraphQLQuery(actualToken, query, variables);
      
      if (!itemData || !itemData.items || itemData.items.length === 0) {
        logger.error('Item not found', { itemId });
        return res.status(404).json({ 
          error: 'Item not found',
          message: 'The specified item could not be found'
        });
      }
      
      // Find the source column value
      const item = itemData.items[0];
      const sourceColumn = item.column_values.find(col => col.id === sourceColumnId);
      
      if (!sourceColumn) {
        logger.error('Source column not found on item', { sourceColumnId, itemId });
        return res.status(400).json({ 
          error: 'Source column not found',
          message: `Column ${sourceColumnId} not found on item`
        });
      }
      
      // Extract the value - Monday.com provides it in the 'text' field
      barcodeValue = sourceColumn.text || '';
      
      console.log('✅ Got column value:', { sourceColumnId, value: barcodeValue });
      
    } catch (error) {
      logger.error('Failed to query item from Monday.com', { error: error.message });
      return res.status(500).json({ 
        error: 'Failed to get item data',
        message: 'Could not retrieve item data from Monday.com'
      });
    }
    
    // COMPREHENSIVE INPUT SANITIZATION (Monday.com marketplace requirement)
    if (barcodeValue) {
      // 1. Convert to string and trim whitespace
      barcodeValue = String(barcodeValue).trim();
      
      // 2. HTML encode to prevent XSS
      barcodeValue = barcodeValue
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;');
        
      // 3. Remove potential SQL injection patterns
      barcodeValue = barcodeValue
        .replace(/['";]/g, '')
        .replace(/--/g, '')
        .replace(/\/\*/g, '')
        .replace(/\*\//g, '');
        
      // 4. Limit length to prevent buffer overflow attacks
      if (barcodeValue.length > 1000) {
        barcodeValue = barcodeValue.substring(0, 1000);
      }
      
      // 5. Decode HTML entities back for barcode generation (but keep logged version safe)
      const originalValue = barcodeValue;
      barcodeValue = barcodeValue
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#x27;/g, "'")
        .replace(/&amp;/g, '&');
        
      logger.info('Input sanitized', { 
        originalLength: originalValue.length,
        sanitizedLength: barcodeValue.length 
      });
    }
    
    // Extract actual token (remove 'Bearer ' prefix if present)
    let actualToken = authToken;
    if (authToken && authToken.startsWith('Bearer ')) {
      actualToken = authToken.substring(7);
    }
    
    // SECURE ID VALIDATION (Monday.com marketplace requirement)
    // Validate and sanitize all IDs to prevent injection attacks
    const validateId = (id, fieldName) => {
      if (!id) return null;
      
      // Convert to string and validate format
      const sanitizedId = String(id).trim();
      
      // Monday.com IDs should be numeric or specific format
      if (fieldName.includes('Id') && !/^[0-9]+$/.test(sanitizedId)) {
        logger.warn(`Invalid ${fieldName} format`, { id: sanitizedId });
        return null;
      }
      
      // Column IDs should be alphanumeric with underscores
      if (fieldName.includes('ColumnId') && !/^[a-zA-Z0-9_]+$/.test(sanitizedId)) {
        logger.warn(`Invalid ${fieldName} format`, { id: sanitizedId });
        return null;
      }
      
      return sanitizedId;
    };
    
    // Validate all required fields with security checks
    const validatedSourceColumnId = validateId(sourceColumnId, 'sourceColumnId');
    const validatedTargetFileColumnId = validateId(targetFileColumnId, 'targetFileColumnId');
    const validatedBoardId = validateId(boardId, 'boardId');
    const validatedItemId = validateId(itemId, 'itemId');
    
    const missingFields = [];
    if (!validatedSourceColumnId) missingFields.push('sourceColumnId');
    if (!validatedTargetFileColumnId) missingFields.push('targetFileColumnId');
    if (!validatedBoardId) missingFields.push('boardId');
    if (!validatedItemId) missingFields.push('itemId');
    
    if (missingFields.length > 0) {
      logger.error('Missing required fields from Monday.com payload', { 
        missingFields,
        sourceColumnId, 
        targetFileColumnId, 
        boardId, 
        itemId,
        inboundFieldValues,
        inputFields
      });
      return res.status(400).json({ 
        error: 'Missing required fields',
        message: `Missing: ${missingFields.join(', ')}`,
        receivedData: {
          inputFields,
          inboundFieldValues,
          hasRequiredFields: missingFields.length === 0
        }
      });
    }
    
    // Import services
    const mondayService = require('../services/mondayService');
    const barcodeService = require('../services/barcodeService');
    
        logger.info(`${barcodeType} Action Block processing`, { 
      sourceColumnId: validatedSourceColumnId, 
      targetFileColumnId: validatedTargetFileColumnId, 
      boardId: validatedBoardId, 
      itemId: validatedItemId, 
      hasValue: !!barcodeValue 
    });
    
    // Check if we have the barcode value from Monday.com
    if (!barcodeValue || barcodeValue.trim() === '') {
      logger.warn('Source column is empty or missing', { 
        sourceColumnId: validatedSourceColumnId, 
        barcodeValue,
        inboundFieldValues 
      });
      
      // Post update to Monday.com about empty source column
      await postValidationErrorUpdate(
        validatedItemId, 
        actualToken, 
        barcodeType,
        'Empty Source Column',
        `The selected source column is empty. Please add data to the column before generating a ${barcodeType} barcode.`
      );
      
      return res.status(400).json({ 
        error: 'Source column is empty',
        message: 'The selected source column contains no data to encode' 
      });
    }
    
    // VALIDATE INPUT FOR SPECIFIC BARCODE TYPES
    const validationResult = validateBarcodeInput(barcodeValue.trim(), barcodeType);
    if (!validationResult.isValid) {
      logger.warn(`${barcodeType} validation failed`, { 
      value: barcodeValue, 
        error: validationResult.error 
      });
      
      // Post update to Monday.com about validation error
      await postValidationErrorUpdate(
        itemId, 
        actualToken, 
        barcodeType,
        'Invalid Input Format',
        validationResult.error
      );
      
      return res.status(400).json({ 
        error: 'Invalid input format',
        message: validationResult.error
      });
    }
    
    logger.info(`Generating ${barcodeType} barcode`, { 
      valueLength: barcodeValue.length
    });
    
    // Generate barcode using existing service
    const barcodeResult = await barcodeService.generateBarcode({
      value: barcodeValue,
      type: barcodeType,
      userId: 'monday-action-block',
      boardId: validatedBoardId,
      itemId: validatedItemId,
      columnId: validatedTargetFileColumnId
    });
    
    logger.info(`${barcodeType} barcode generated, uploading to Monday.com`, { 
      barcodeId: barcodeResult.data.id,
      filename: barcodeResult.data.filename 
    });
    
    // Upload to Monday.com file column using existing service
    const uploadResult = await mondayService.uploadFileToColumn(
      validatedItemId,
      validatedTargetFileColumnId,
      barcodeResult.data.imageBuffer,
      barcodeResult.data.filename,
      barcodeResult.data.mimeType,
      actualToken
    );
    
    // Post success update to Monday.com
    await postSuccessUpdate(
      validatedItemId,
      actualToken, 
      barcodeType,
      barcodeValue
    );
    
    logger.info(`${barcodeType} Action Block - Barcode generated and uploaded successfully`, {
      barcodeId: barcodeResult.data.id,
      itemId: validatedItemId,
      barcodeType,
      mondayFileId: uploadResult?.id
    });
    
    res.status(200).json({
      success: true,
      message: `${barcodeType} barcode generated and uploaded successfully`,
      data: {
        barcodeId: barcodeResult.data.id,
        mondayFileId: uploadResult?.id,
        barcodeType: barcodeType
      }
    });
    
  } catch (error) {
    const logger = require('../utils/logger');
    logger.error(`${barcodeType} Action Block failed`, { 
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
    
    // Post error update to Monday.com if we have the required info
    try {
      // Try to extract context from the request for error reporting
      let errorItemId, errorAuthToken;
      
      if (req.body.inputFields) {
        // Monday.com direct structure
        errorItemId = req.body.itemId || req.body.inboundFieldValues?.itemId;
        errorAuthToken = req.headers.authorization || 
                        req.body.credentialsValues?.shortLivedToken ||
                        req.body.shortLivedToken;
      } else if (req.body.payload) {
        // Legacy structure
        const { payload } = req.body;
        const { context } = payload || {};
        errorItemId = context?.itemId;
        errorAuthToken = payload?.shortLivedToken || req.headers?.authorization;
      }
      
      if (errorItemId && errorAuthToken) {
        let actualToken = errorAuthToken;
        if (errorAuthToken.startsWith('Bearer ')) {
          actualToken = errorAuthToken.substring(7);
        }
        
        await postValidationErrorUpdate(
          errorItemId, 
          actualToken, 
          barcodeType,
          'Generation Failed',
          `An unexpected error occurred while generating the ${barcodeType} barcode: ${error.message}. Please try again or contact support if the issue persists.`
        );
      }
    } catch (updateError) {
      logger.error('Failed to post error update', { error: updateError.message });
    }
    
    res.status(500).json({
      error: `Failed to generate ${barcodeType} barcode`,
      details: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
}

/**
 * Validate barcode input based on barcode type requirements
 * @param {string} value - The input value to validate
 * @param {string} barcodeType - The barcode type
 * @returns {Object} - Validation result with isValid and error message
 */
function validateBarcodeInput(value, barcodeType) {
  switch (barcodeType) {
    case 'EAN13':
      // EAN-13 requires exactly 12 or 13 digits
      if (!/^\d{12,13}$/.test(value)) {
        return {
          isValid: false,
          error: `EAN-13 requires exactly 12 or 13 digits. You provided "${value}" which has ${value.length} characters. Please use only numbers (e.g., "123456789012").`
        };
      }
      break;
      
    case 'EAN8':
      // EAN-8 requires exactly 7 or 8 digits
      if (!/^\d{7,8}$/.test(value)) {
        return {
          isValid: false,
          error: `EAN-8 requires exactly 7 or 8 digits. You provided "${value}" which has ${value.length} characters. Please use only numbers (e.g., "1234567").`
        };
      }
      break;
      
    case 'UPC_A':
      // UPC-A requires exactly 11 or 12 digits
      if (!/^\d{11,12}$/.test(value)) {
        return {
          isValid: false,
          error: `UPC-A requires exactly 11 or 12 digits. You provided "${value}" which has ${value.length} characters. Please use only numbers (e.g., "12345678901").`
        };
      }
      break;
      
    case 'CODE39':
      // Code 39 allows A-Z, 0-9, and specific special characters
      if (!/^[A-Z0-9\-\.\$\/\+\%\*\s]+$/.test(value.toUpperCase())) {
        return {
          isValid: false,
          error: `Code 39 only accepts uppercase letters (A-Z), numbers (0-9), and these special characters: - . $ / + % * and spaces. You provided "${value}". Please remove any invalid characters.`
        };
      }
      break;
      
    case 'CODE128':
      // Code 128 is very flexible, just check for reasonable length
      if (value.length > 80) {
        return {
          isValid: false,
          error: `Code 128 input is too long (${value.length} characters). Please use 80 characters or less for better barcode readability.`
        };
      }
      break;
      
    case 'QR':
    case 'DATAMATRIX':
      // QR and DataMatrix are very flexible, just check for reasonable length
      if (value.length > 4000) {
        return {
          isValid: false,
          error: `Input is too long (${value.length} characters). Please use 4000 characters or less for optimal ${barcodeType} generation.`
        };
      }
      break;
      
    default:
      // Unknown barcode type
      return {
        isValid: false,
        error: `Unknown barcode type: ${barcodeType}. Please contact support.`
      };
  }
  
  return { isValid: true };
}

/**
 * Post a validation error update to Monday.com item
 * @param {string} itemId - The Monday.com item ID
 * @param {string} authToken - The authentication token
 * @param {string} barcodeType - The barcode type that failed
 * @param {string} errorTitle - Short error title
 * @param {string} errorMessage - Detailed error message with instructions
 */
async function postValidationErrorUpdate(itemId, authToken, barcodeType, errorTitle, errorMessage) {
  try {
    const mondayService = require('../services/mondayService');
    const logger = require('../utils/logger');
    
    const updateText = `🚫 **${barcodeType} Generation Failed - ${errorTitle}**\n\n${errorMessage}\n\n*Please correct the input and try again.*`;
    
    const mutation = `
      mutation ($itemId: Int!, $body: String!) {
        create_update(item_id: $itemId, body: $body) {
          id
        }
      }
    `;
    
    const variables = {
      itemId: parseInt(itemId),
      body: updateText
    };
    
    await mondayService.executeGraphQLQuery(mutation, variables, authToken);
    logger.info(`Posted validation error update for ${barcodeType}`, { itemId, errorTitle });
    
  } catch (error) {
    const logger = require('../utils/logger');
    logger.error('Failed to post validation error update', { 
      error: error.message, 
      itemId, 
      barcodeType 
    });
  }
}

/**
 * Post a success update to Monday.com item
 * @param {string} itemId - The Monday.com item ID
 * @param {string} authToken - The authentication token
 * @param {string} barcodeType - The barcode type that was generated
 * @param {string} inputValue - The value that was encoded
 */
async function postSuccessUpdate(itemId, authToken, barcodeType, inputValue) {
  try {
    const mondayService = require('../services/mondayService');
    const logger = require('../utils/logger');
    
    const updateText = `✅ **${barcodeType} Barcode Generated Successfully**\n\nEncoded value: "${inputValue}"\n\n*The barcode has been saved to your file column.*`;
    
    const mutation = `
      mutation ($itemId: Int!, $body: String!) {
        create_update(item_id: $itemId, body: $body) {
          id
        }
      }
    `;
    
    const variables = {
      itemId: parseInt(itemId),
      body: updateText
    };
    
    await mondayService.executeGraphQLQuery(mutation, variables, authToken);
    logger.info(`Posted success update for ${barcodeType}`, { itemId, inputValue });
    
  } catch (error) {
    const logger = require('../utils/logger');
    logger.error('Failed to post success update', { 
      error: error.message, 
      itemId, 
      barcodeType 
    });
  }
}

// ==============================================
// PRICING ENDPOINTS
// ==============================================

/**
 * @route   GET /api/pricing/plans
 * @desc    Get available pricing plans
 * @access  Public
 */
router.get('/pricing/plans', async (req, res) => {
  try {
    const plans = await pricingService.getPricingPlans();
    res.status(200).json({
      success: true,
      data: plans
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch pricing plans',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/pricing/features/:plan
 * @desc    Get feature access for a specific plan
 * @access  Public
 */
router.get('/pricing/features/:plan', async (req, res) => {
  try {
    const { plan } = req.params;
    const features = await pricingService.getFeatureAccess(plan);
    
    if (!features) {
      return res.status(404).json({
        success: false,
        message: 'Plan not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: features
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch plan features',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/pricing/calculate
 * @desc    Calculate pricing for a specific plan and seat count
 * @access  Public
 */
router.post('/pricing/calculate',
  [
    body('planId').notEmpty().withMessage('Plan ID is required'),
    body('seats').isInt({ min: 1 }).withMessage('Seats must be a positive integer'),
    body('billingPeriod').optional().isIn(['monthly', 'yearly']).withMessage('Billing period must be monthly or yearly')
  ],
  validationMiddleware.handleValidationErrors,
  async (req, res) => {
    try {
      const { planId, seats, billingPeriod = 'monthly' } = req.body;
      const pricing = await pricingService.calculatePricing(planId, seats, billingPeriod);
      
      res.status(200).json({
        success: true,
        data: pricing
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: 'Failed to calculate pricing',
        error: error.message
      });
    }
  }
);

/**
 * @route   GET /api/pricing/trial
 * @desc    Get free trial information
 * @access  Public
 */
router.get('/pricing/trial', async (req, res) => {
  try {
    const trial = await pricingService.getFreeTrial();
    res.status(200).json({
      success: true,
      data: trial
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch trial information',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/pricing/seat-count
 * @desc    Get Monday.com account seat count
 * @access  Private (requires auth token)
 */
router.get('/pricing/seat-count', async (req, res) => {
  try {
    const authToken = req.headers.authorization;
    if (!authToken) {
      return res.status(401).json({
        success: false,
        message: 'Authorization token required'
      });
    }
    
    const seatCount = await pricingService.getAccountSeatCount(authToken);
    res.status(200).json({
      success: true,
      data: {
        seats: seatCount
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch seat count',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/pricing/recommend
 * @desc    Get recommended plan based on seat count
 * @access  Private (requires auth token)
 */
router.get('/pricing/recommend', async (req, res) => {
  try {
    const authToken = req.headers.authorization;
    if (!authToken) {
      return res.status(401).json({
        success: false,
        message: 'Authorization token required'
      });
    }
    
    const seatCount = await pricingService.getAccountSeatCount(authToken);
    const recommendedPlan = await pricingService.recommendPlan(seatCount);
    
    res.status(200).json({
      success: true,
      data: {
        seatCount,
        recommendedPlan,
        pricingOptions: {
          monthly: {
            pricePerSeat: recommendedPlan.monthly_price / 100,
            totalPrice: (recommendedPlan.monthly_price * seatCount) / 100,
            currency: recommendedPlan.currency
          },
          yearly: {
            pricePerSeat: recommendedPlan.yearly_price / 100,
            totalPrice: (recommendedPlan.yearly_price * seatCount) / 100,
            currency: recommendedPlan.currency,
            savings: ((recommendedPlan.monthly_price * 12 - recommendedPlan.yearly_price * 12) * seatCount) / 100
          }
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to generate plan recommendation',
      error: error.message
    });
  }
});

// ==============================================
// MONDAY.COM INTEGRATION ENDPOINTS  
// ==============================================

/**
 * @route   GET /api/monday/fetchFieldDefs
 * @desc    Dynamic field definitions for Action Block column selectors
 * @access  Public (Monday.com webhook)
 */
router.get('/monday/fetchFieldDefs', async (req, res) => {
  try {
    const { field, boardId } = req.query;
    const authToken = req.headers.authorization;
    
    if (!boardId) {
      return res.status(400).json({ error: 'boardId is required' });
    }
    
    // Extract actual token (remove 'Bearer ' prefix if present)
    let actualToken = authToken;
    if (authToken && authToken.startsWith('Bearer ')) {
      actualToken = authToken.substring(7);
    }
    
    // Import services
    const mondayService = require('../services/mondayService');
    const logger = require('../utils/logger');
    
    logger.info('fetchFieldDefs request', { 
      field, 
      boardId,
      hasAuth: !!actualToken 
    });
    
    // Get board columns
    const query = `
      query ($boardId: [Int!]) {
        boards(ids: $boardId) {
          columns {
            id
            title
            type
          }
        }
      }
    `;
    
    const response = await mondayService.executeGraphQLQuery(query, {
      boardId: [parseInt(boardId)]
    }, actualToken);
    
    const columns = response.data.boards[0]?.columns || [];
    
    // Return all columns - column type restrictions are handled in Monday.com Developer Center UI
    const fieldDefinitions = columns.map(col => ({
      id: col.id,
      title: col.title,
      type: col.type
    }));
    
    res.status(200).json({
      data: fieldDefinitions
    });
    
  } catch (error) {
    const logger = require('../utils/logger');
    logger.error('Field definitions fetch failed', { error: error.message });
    
    res.status(500).json({
      error: 'Failed to fetch field definitions',
      details: error.message
    });
  }
});

// ==============================================
// MONDAY.COM INTEGRATION ENDPOINTS
// ==============================================

/**
 * @route   GET /api/monday/boards
 * @desc    Get user's Monday.com boards
 * @access  Private
 */
router.get('/monday/boards',
  authMiddleware.authenticate,
  mondayController.getBoards
);

/**
 * @route   GET /api/monday/boards/:boardId/items
 * @desc    Get items from a specific Monday.com board
 * @access  Private
 */
router.get('/monday/boards/:boardId/items',
  authMiddleware.authenticate,
  [
    param('boardId').isInt().withMessage('Board ID must be a number'),
    query('limit').optional().isInt({ min: 1, max: 500 }).withMessage('Limit must be between 1 and 500'),
    query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer')
  ],
  validationMiddleware.handleValidationErrors,
  mondayController.getBoardItems
);

/**
 * @route   POST /api/monday/boards/:boardId/items
 * @desc    Create a new item in a Monday.com board
 * @access  Private
 */
router.post('/monday/boards/:boardId/items',
  authMiddleware.authenticate,
  [
    param('boardId').isInt().withMessage('Board ID must be a number'),
    body('name').notEmpty().withMessage('Item name is required'),
    body('columnValues').optional().isObject().withMessage('Column values must be an object')
  ],
  validationMiddleware.handleValidationErrors,
  mondayController.createBoardItem
);

/**
 * @route   PUT /api/monday/items/:itemId
 * @desc    Update a Monday.com item with barcode information
 * @access  Private
 */
router.put('/monday/items/:itemId',
  authMiddleware.authenticate,
  [
    param('itemId').isInt().withMessage('Item ID must be a number'),
    body('columnValues').isObject().withMessage('Column values are required')
  ],
  validationMiddleware.handleValidationErrors,
  mondayController.updateItem
);

/**
 * @route   GET /api/monday/columns/:boardId
 * @desc    Get columns for a specific Monday.com board
 * @access  Private
 */
router.get('/monday/columns/:boardId',
  authMiddleware.authenticate,
  [
    param('boardId').isInt().withMessage('Board ID must be a number')
  ],
  validationMiddleware.handleValidationErrors,
  mondayController.getBoardColumns
);

// ==============================================
// BATCH OPERATIONS (Future feature)
// ==============================================

/**
 * @route   POST /api/batch/generate
 * @desc    Generate multiple barcodes in batch (placeholder)
 * @access  Private
 */
router.post('/batch/generate',
  authMiddleware.authenticate,
  [
    body('items').isArray({ min: 1, max: 100 }).withMessage('Items must be an array with 1-100 elements'),
    body('items.*.data').notEmpty().withMessage('Each item must have data'),
    body('items.*.type').optional().isIn(['code128', 'code39', 'ean13', 'qr']).withMessage('Invalid barcode type')
  ],
  validationMiddleware.handleValidationErrors,
  barcodeController.generateBatchBarcodes
);

// ==============================================
// EXPORT ENDPOINTS (Future feature)
// ==============================================

/**
 * @route   GET /api/export/barcodes
 * @desc    Export barcodes in various formats (placeholder)
 * @access  Private
 */
router.get('/export/barcodes',
  authMiddleware.authenticate,
  [
    query('format').isIn(['csv', 'xlsx', 'pdf']).withMessage('Format must be csv, xlsx, or pdf'),
    query('boardId').optional().isInt().withMessage('Board ID must be a number'),
    query('dateFrom').optional().isISO8601().withMessage('Invalid date format'),
    query('dateTo').optional().isISO8601().withMessage('Invalid date format')
  ],
  validationMiddleware.handleValidationErrors,
  barcodeController.exportBarcodes
);

// ==============================================
// ERROR HANDLING
// ==============================================

// Handle 404 for API routes
router.use('*', (req, res) => {
  res.status(404).json({
    status: 'error',
    message: `API endpoint ${req.originalUrl} not found`,
    code: 'ENDPOINT_NOT_FOUND'
  });
});

module.exports = router; 