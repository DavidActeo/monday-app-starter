/**
 * Validation Service
 * 
 * This file contains service functions for data validation, sanitization,
 * and business rule enforcement across the application.
 */

const validator = require('validator');
const logger = require('../utils/logger');

// ==============================================
// GENERAL VALIDATION SERVICES
// ==============================================

/**
 * Validate and sanitize user input data
 */
const validateAndSanitizeInput = (input, rules = {}) => {
  const result = {
    isValid: true,
    errors: [],
    warnings: [],
    sanitizedData: {}
  };

  try {
    for (const [field, fieldRules] of Object.entries(rules)) {
      const value = input[field];
      const fieldResult = validateField(value, fieldRules, field);
      
      if (!fieldResult.isValid) {
        result.isValid = false;
        result.errors.push(...fieldResult.errors);
      }
      
      result.warnings.push(...fieldResult.warnings);
      result.sanitizedData[field] = fieldResult.sanitizedValue;
    }

    return result;

  } catch (error) {
    logger.error('Error in input validation:', error);
    return {
      isValid: false,
      errors: ['Validation error occurred'],
      warnings: [],
      sanitizedData: {}
    };
  }
};

/**
 * Validate individual field against rules
 */
const validateField = (value, rules, fieldName) => {
  const result = {
    isValid: true,
    errors: [],
    warnings: [],
    sanitizedValue: value
  };

  // Handle null/undefined values
  if (value === null || value === undefined) {
    if (rules.required) {
      result.isValid = false;
      result.errors.push(`${fieldName} is required`);
    }
    return result;
  }

  // Convert to string for most validations
  const stringValue = String(value);

  // Required validation
  if (rules.required && (!stringValue || stringValue.trim().length === 0)) {
    result.isValid = false;
    result.errors.push(`${fieldName} is required`);
    return result;
  }

  // Type validation
  if (rules.type) {
    const typeResult = validateType(value, rules.type, fieldName);
    if (!typeResult.isValid) {
      result.isValid = false;
      result.errors.push(...typeResult.errors);
    }
    result.sanitizedValue = typeResult.sanitizedValue;
  }

  // Length validation
  if (rules.minLength && stringValue.length < rules.minLength) {
    result.isValid = false;
    result.errors.push(`${fieldName} must be at least ${rules.minLength} characters long`);
  }

  if (rules.maxLength && stringValue.length > rules.maxLength) {
    result.isValid = false;
    result.errors.push(`${fieldName} must not exceed ${rules.maxLength} characters`);
  }

  // Pattern validation
  if (rules.pattern && !rules.pattern.test(stringValue)) {
    result.isValid = false;
    result.errors.push(`${fieldName} format is invalid`);
  }

  // Enum validation
  if (rules.enum && !rules.enum.includes(value)) {
    result.isValid = false;
    result.errors.push(`${fieldName} must be one of: ${rules.enum.join(', ')}`);
  }

  // Custom validation
  if (rules.custom && typeof rules.custom === 'function') {
    const customResult = rules.custom(value, fieldName);
    if (!customResult.isValid) {
      result.isValid = false;
      result.errors.push(...customResult.errors);
    }
    result.warnings.push(...customResult.warnings || []);
  }

  // Sanitization
  if (rules.sanitize) {
    result.sanitizedValue = sanitizeValue(result.sanitizedValue, rules.sanitize);
  }

  return result;
};

/**
 * Validate data types
 */
const validateType = (value, type, fieldName) => {
  const result = {
    isValid: true,
    errors: [],
    sanitizedValue: value
  };

  switch (type) {
    case 'string':
      result.sanitizedValue = String(value);
      break;

    case 'number':
      const numValue = Number(value);
      if (isNaN(numValue)) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be a valid number`);
      } else {
        result.sanitizedValue = numValue;
      }
      break;

    case 'integer':
      const intValue = parseInt(value, 10);
      if (isNaN(intValue) || intValue !== Number(value)) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be a valid integer`);
      } else {
        result.sanitizedValue = intValue;
      }
      break;

    case 'boolean':
      if (typeof value === 'boolean') {
        result.sanitizedValue = value;
      } else if (typeof value === 'string') {
        const lowerValue = value.toLowerCase();
        if (lowerValue === 'true' || lowerValue === '1') {
          result.sanitizedValue = true;
        } else if (lowerValue === 'false' || lowerValue === '0') {
          result.sanitizedValue = false;
        } else {
          result.isValid = false;
          result.errors.push(`${fieldName} must be a valid boolean`);
        }
      } else {
        result.isValid = false;
        result.errors.push(`${fieldName} must be a valid boolean`);
      }
      break;

    case 'email':
      if (!validator.isEmail(String(value))) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be a valid email address`);
      } else {
        result.sanitizedValue = validator.normalizeEmail(String(value));
      }
      break;

    case 'url':
      if (!validator.isURL(String(value))) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be a valid URL`);
      }
      break;

    case 'date':
      const dateValue = new Date(value);
      if (isNaN(dateValue.getTime())) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be a valid date`);
      } else {
        result.sanitizedValue = dateValue.toISOString();
      }
      break;

    case 'uuid':
      if (!validator.isUUID(String(value))) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be a valid UUID`);
      }
      break;

    case 'array':
      if (!Array.isArray(value)) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be an array`);
      }
      break;

    case 'object':
      if (typeof value !== 'object' || Array.isArray(value) || value === null) {
        result.isValid = false;
        result.errors.push(`${fieldName} must be an object`);
      }
      break;

    default:
      logger.warn(`Unknown validation type: ${type}`);
  }

  return result;
};

/**
 * Sanitize values based on sanitization rules
 */
const sanitizeValue = (value, sanitizeRules) => {
  let sanitized = value;

  if (typeof sanitized === 'string') {
    if (sanitizeRules.includes('trim')) {
      sanitized = sanitized.trim();
    }

    if (sanitizeRules.includes('lowercase')) {
      sanitized = sanitized.toLowerCase();
    }

    if (sanitizeRules.includes('uppercase')) {
      sanitized = sanitized.toUpperCase();
    }

    if (sanitizeRules.includes('escape')) {
      sanitized = validator.escape(sanitized);
    }

    if (sanitizeRules.includes('stripTags')) {
      sanitized = sanitized.replace(/<[^>]*>/g, '');
    }

    if (sanitizeRules.includes('removeSpecialChars')) {
      sanitized = sanitized.replace(/[^\w\s-_]/g, '');
    }
  }

  return sanitized;
};

// ==============================================
// MONDAY.COM SPECIFIC VALIDATION
// ==============================================

/**
 * Validate Monday.com board ID
 */
const validateMondayBoardId = (boardId) => {
  const result = {
    isValid: true,
    errors: [],
    sanitizedValue: boardId
  };

  if (!boardId) {
    result.isValid = false;
    result.errors.push('Board ID is required');
    return result;
  }

  // Monday.com board IDs are typically numeric strings
  if (!/^\d+$/.test(String(boardId))) {
    result.isValid = false;
    result.errors.push('Board ID must be a numeric value');
  } else {
    result.sanitizedValue = String(boardId);
  }

  return result;
};

/**
 * Validate Monday.com item ID
 */
const validateMondayItemId = (itemId) => {
  const result = {
    isValid: true,
    errors: [],
    sanitizedValue: itemId
  };

  if (!itemId) {
    result.isValid = false;
    result.errors.push('Item ID is required');
    return result;
  }

  // Monday.com item IDs are typically numeric strings
  if (!/^\d+$/.test(String(itemId))) {
    result.isValid = false;
    result.errors.push('Item ID must be a numeric value');
  } else {
    result.sanitizedValue = String(itemId);
  }

  return result;
};

/**
 * Validate Monday.com column values
 */
const validateMondayColumnValues = (columnValues) => {
  const result = {
    isValid: true,
    errors: [],
    warnings: [],
    sanitizedValue: {}
  };

  if (!columnValues || typeof columnValues !== 'object') {
    result.isValid = false;
    result.errors.push('Column values must be an object');
    return result;
  }

  for (const [columnId, value] of Object.entries(columnValues)) {
    // Validate column ID
    if (!columnId || typeof columnId !== 'string') {
      result.isValid = false;
      result.errors.push('Column ID must be a non-empty string');
      continue;
    }

    // Basic value validation
    if (value !== null && typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean' && typeof value !== 'object') {
      result.warnings.push(`Column ${columnId} has an unusual value type`);
    }

    result.sanitizedValue[columnId] = value;
  }

  return result;
};

// ==============================================
// BARCODE SPECIFIC VALIDATION
// ==============================================

/**
 * Validate barcode data for different barcode types
 */
const validateBarcodeData = (data, type = 'code128') => {
  const result = {
    isValid: true,
    errors: [],
    warnings: [],
    suggestions: []
  };

  if (!data || typeof data !== 'string' || data.trim().length === 0) {
    result.isValid = false;
    result.errors.push('Barcode data is required and must be a non-empty string');
    return result;
  }

  const trimmedData = data.trim();

  switch (type.toLowerCase()) {
    case 'code128':
      result.suggestions.push(...validateCode128(trimmedData));
      break;

    case 'code39':
      const code39Result = validateCode39(trimmedData);
      if (!code39Result.isValid) {
        result.isValid = false;
        result.errors.push(...code39Result.errors);
      }
      result.warnings.push(...code39Result.warnings);
      break;

    case 'ean13':
      const ean13Result = validateEAN13(trimmedData);
      if (!ean13Result.isValid) {
        result.isValid = false;
        result.errors.push(...ean13Result.errors);
      }
      break;

    case 'ean8':
      const ean8Result = validateEAN8(trimmedData);
      if (!ean8Result.isValid) {
        result.isValid = false;
        result.errors.push(...ean8Result.errors);
      }
      break;

    case 'qr':
      result.suggestions.push(...validateQRCode(trimmedData));
      break;

    case 'upc_a':
    case 'upca':
      const upcaResult = validateUPCA(trimmedData);
      if (!upcaResult.isValid) {
        result.isValid = false;
        result.errors.push(...upcaResult.errors);
      }
      break;

    case 'datamatrix':
      result.suggestions.push(...validateDataMatrix(trimmedData));
      break;

    default:
      result.warnings.push(`Unknown barcode type: ${type}. Using default validation.`);
  }

  // General length checks
  if (trimmedData.length > 2000) {
    result.warnings.push('Very long data may cause scanning issues');
  }

  return result;
};

/**
 * Validate Code128 specific rules
 */
const validateCode128 = (data) => {
  const suggestions = [];

  if (data.length > 100) {
    suggestions.push('Code128 works best with data under 100 characters');
  }

  // Check for problematic characters
  if (/[\x00-\x1F\x7F]/.test(data)) {
    suggestions.push('Control characters may cause issues in Code128');
  }

  return suggestions;
};

/**
 * Validate Code39 specific rules
 */
const validateCode39 = (data) => {
  const result = {
    isValid: true,
    errors: [],
    warnings: []
  };

  // Code39 character set validation
  if (!/^[A-Z0-9\-\.\$\/\+%\s]*$/.test(data)) {
    result.isValid = false;
    result.errors.push('Code39 only supports uppercase letters, numbers, and symbols: - . $ / + % space');
  }

  if (data.length > 50) {
    result.warnings.push('Code39 becomes harder to scan with more than 50 characters');
  }

  return result;
};

/**
 * Validate EAN13 specific rules
 */
const validateEAN13 = (data) => {
  const result = {
    isValid: true,
    errors: []
  };

  // EAN13 must be exactly 12 or 13 digits
  if (!/^\d{12,13}$/.test(data)) {
    result.isValid = false;
    result.errors.push('EAN13 requires exactly 12 or 13 digits');
    return result;
  }

  // Validate check digit if 13 digits provided
  if (data.length === 13) {
    const checkDigit = calculateEAN13CheckDigit(data.substring(0, 12));
    if (parseInt(data.charAt(12)) !== checkDigit) {
      result.isValid = false;
      result.errors.push('EAN13 check digit is invalid');
    }
  }

  return result;
};

/**
 * Validate EAN8 specific rules
 */
const validateEAN8 = (data) => {
  const result = {
    isValid: true,
    errors: []
  };

  // EAN8 must be exactly 7 or 8 digits
  if (!/^\d{7,8}$/.test(data)) {
    result.isValid = false;
    result.errors.push('EAN8 requires exactly 7 or 8 digits');
    return result;
  }

  // Validate check digit if 8 digits provided
  if (data.length === 8) {
    const checkDigit = calculateEAN8CheckDigit(data.substring(0, 7));
    if (parseInt(data.charAt(7)) !== checkDigit) {
      result.isValid = false;
      result.errors.push('EAN8 check digit is invalid');
    }
  }

  return result;
};

/**
 * Validate QR Code specific rules
 */
const validateQRCode = (data) => {
  const suggestions = [];

  if (data.length > 1000) {
    suggestions.push('QR codes with over 1000 characters may be difficult to scan');
  }

  if (data.length > 2000) {
    suggestions.push('Consider reducing data size for better QR code readability');
  }

  // Check for special characters that might need encoding
  if (/[^\x00-\xFF]/.test(data)) {
    suggestions.push('Non-ASCII characters will increase QR code size');
  }

  return suggestions;
};

/**
 * Validate UPC-A specific rules
 */
const validateUPCA = (data) => {
  const result = {
    isValid: true,
    errors: [],
    warnings: []
  };

  // UPC-A must be exactly 12 digits
  if (!/^\d{12}$/.test(data)) {
    result.isValid = false;
    result.errors.push('UPC-A must be exactly 12 digits');
    return result;
  }

  // Validate check digit
  const digits = data.substring(0, 11);
  const checkDigit = parseInt(data.charAt(11));
  const calculatedCheckDigit = calculateUPCACheckDigit(digits);

  if (checkDigit !== calculatedCheckDigit) {
    result.warnings.push(`Check digit may be incorrect. Expected: ${calculatedCheckDigit}, Got: ${checkDigit}`);
  }

  return result;
};

/**
 * Validate DataMatrix specific rules
 */
const validateDataMatrix = (data) => {
  const suggestions = [];

  if (data.length > 500) {
    suggestions.push('DataMatrix codes work best with data under 500 characters');
  }

  if (data.length > 1000) {
    suggestions.push('Very large data may make DataMatrix codes difficult to scan');
  }

  // Check for special characters
  if (/[^\x20-\x7E]/.test(data)) {
    suggestions.push('Non-printable characters may require special encoding');
  }

  return suggestions;
};

// ==============================================
// HELPER FUNCTIONS
// ==============================================

/**
 * Calculate EAN13 check digit
 */
const calculateEAN13CheckDigit = (digits) => {
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const digit = parseInt(digits.charAt(i));
    sum += i % 2 === 0 ? digit : digit * 3;
  }
  return (10 - (sum % 10)) % 10;
};

/**
 * Calculate EAN8 check digit
 */
const calculateEAN8CheckDigit = (digits) => {
  let sum = 0;
  for (let i = 0; i < 7; i++) {
    const digit = parseInt(digits.charAt(i));
    sum += i % 2 === 0 ? digit * 3 : digit;
  }
  return (10 - (sum % 10)) % 10;
};

/**
 * Calculate UPC-A check digit
 */
const calculateUPCACheckDigit = (digits) => {
  let sum = 0;
  for (let i = 0; i < 11; i++) {
    const digit = parseInt(digits.charAt(i));
    sum += i % 2 === 0 ? digit : digit * 3;
  }
  return (10 - (sum % 10)) % 10;
};

/**
 * Validate file upload data
 */
const validateFileUpload = (file, allowedTypes = [], maxSizeMB = 10) => {
  const result = {
    isValid: true,
    errors: [],
    warnings: []
  };

  if (!file) {
    result.isValid = false;
    result.errors.push('File is required');
    return result;
  }

  // Check file size
  const maxSizeBytes = maxSizeMB * 1024 * 1024;
  if (file.size > maxSizeBytes) {
    result.isValid = false;
    result.errors.push(`File size exceeds ${maxSizeMB}MB limit`);
  }

  // Check file type
  if (allowedTypes.length > 0 && !allowedTypes.includes(file.mimetype)) {
    result.isValid = false;
    result.errors.push(`File type ${file.mimetype} is not allowed`);
  }

  // Check for suspicious file names
  if (file.originalname && /[<>:"/\\|?*]/.test(file.originalname)) {
    result.warnings.push('File name contains potentially problematic characters');
  }

  return result;
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  // General validation
  validateAndSanitizeInput,
  validateField,
  validateType,
  sanitizeValue,

  // Monday.com specific validation
  validateMondayBoardId,
  validateMondayItemId,
  validateMondayColumnValues,

  // Barcode specific validation
  validateBarcodeData,
  validateCode128,
  validateCode39,
  validateEAN13,
  validateEAN8,
  validateQRCode,
  validateUPCA,
  validateDataMatrix,

  // File validation
  validateFileUpload,

  // Helper functions
  calculateEAN13CheckDigit,
  calculateEAN8CheckDigit,
  calculateUPCACheckDigit
}; 