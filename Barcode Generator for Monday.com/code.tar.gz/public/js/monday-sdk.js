/**
 * Monday.com SDK Integration
 * Wrapper functions for Monday.com SDK operations
 */

class MondaySDK {
  constructor() {
    this.sdk = null;
    this.context = null;
    this.user = null;
    this.initialized = false;
  }

  // Initialize the Monday.com SDK
  async init() {
    try {
      if (typeof monday === 'undefined') {
        throw new Error('Monday.com SDK not loaded');
      }

      this.sdk = monday();
      
      // Set API version
      this.sdk.setApiVersion('2023-10');
      
      // Get context information
      this.context = await this.sdk.get('context');
      console.log('Monday.com context:', this.context);
      
      // Get current user
      this.user = await this.getCurrentUser();
      
      this.initialized = true;
      return true;
    } catch (error) {
      console.error('Failed to initialize Monday.com SDK:', error);
      throw error;
    }
  }

  // Check if SDK is initialized
  ensureInitialized() {
    if (!this.initialized) {
      throw new Error('Monday.com SDK not initialized. Call init() first.');
    }
  }

  // Get current user information
  async getCurrentUser() {
    try {
      const query = `
        query {
          me {
            id
            name
            email
            photo_original
            is_admin
            is_guest
          }
        }
      `;
      
      const response = await this.executeQuery(query);
      return response.data.me;
    } catch (error) {
      console.error('Failed to get current user:', error);
      return null;
    }
  }

  // Get user's boards
  async getBoards(limit = 50) {
    try {
      this.ensureInitialized();
      
      const query = `
        query GetBoards($limit: Int) {
          boards(limit: $limit) {
            id
            name
            description
            state
            board_folder_id
            board_kind
            columns {
              id
              title
              type
            }
          }
        }
      `;
      
      const response = await this.executeQuery(query, { limit });
      return response.data.boards;
    } catch (error) {
      console.error('Failed to get boards:', error);
      throw error;
    }
  }

  // Get board items
  async getBoardItems(boardId, limit = 50) {
    try {
      this.ensureInitialized();
      
      const query = `
        query GetBoardItems($boardId: [Int!], $limit: Int) {
          boards(ids: $boardId) {
            items(limit: $limit) {
              id
              name
              state
              column_values {
                id
                text
                type
              }
            }
          }
        }
      `;
      
      const response = await this.executeQuery(query, { 
        boardId: [parseInt(boardId)], 
        limit 
      });
      
      return response.data.boards[0]?.items || [];
    } catch (error) {
      console.error('Failed to get board items:', error);
      throw error;
    }
  }

  // Get board columns
  async getBoardColumns(boardId) {
    try {
      this.ensureInitialized();
      
      const query = `
        query GetBoardColumns($boardId: [Int!]) {
          boards(ids: $boardId) {
            columns {
              id
              title
              type
              settings_str
            }
          }
        }
      `;
      
      const response = await this.executeQuery(query, { 
        boardId: [parseInt(boardId)] 
      });
      
      return response.data.boards[0]?.columns || [];
    } catch (error) {
      console.error('Failed to get board columns:', error);
      throw error;
    }
  }

  // Upload file to Monday.com
  async uploadFile(file) {
    try {
      this.ensureInitialized();
      
      const mutation = `
        mutation UploadFile($file: File!) {
          add_file_to_update(file: $file) {
            id
            url
          }
        }
      `;
      
      const response = await this.executeMutation(mutation, { file });
      return response.data.add_file_to_update;
    } catch (error) {
      console.error('Failed to upload file:', error);
      throw error;
    }
  }

  // Update item column value (for file columns)
  async updateItemColumnValue(itemId, columnId, value) {
    try {
      this.ensureInitialized();
      
      const mutation = `
        mutation UpdateItemColumnValue($itemId: Int!, $columnId: String!, $value: JSON!) {
          change_column_value(item_id: $itemId, column_id: $columnId, value: $value) {
            id
          }
        }
      `;
      
      const response = await this.executeMutation(mutation, {
        itemId: parseInt(itemId),
        columnId,
        value: JSON.stringify(value)
      });
      
      return response.data.change_column_value;
    } catch (error) {
      console.error('Failed to update item column value:', error);
      throw error;
    }
  }

  // Execute GraphQL query
  async executeQuery(query, variables = {}) {
    try {
      this.ensureInitialized();
      
      const response = await this.sdk.api(query, { variables });
      
      if (response.errors) {
        throw new Error(`GraphQL errors: ${JSON.stringify(response.errors)}`);
      }
      
      return response;
    } catch (error) {
      console.error('GraphQL query failed:', error);
      throw error;
    }
  }

  // Execute GraphQL mutation
  async executeMutation(mutation, variables = {}) {
    try {
      this.ensureInitialized();
      
      const response = await this.sdk.api(mutation, { variables });
      
      if (response.errors) {
        throw new Error(`GraphQL errors: ${JSON.stringify(response.errors)}`);
      }
      
      return response;
    } catch (error) {
      console.error('GraphQL mutation failed:', error);
      throw error;
    }
  }

  // Listen to context changes
  onContextChange(callback) {
    if (this.sdk) {
      this.sdk.listen('context', callback);
    }
  }

  // Show confirmation dialog
  async showConfirm(message, confirmText = 'Confirm', cancelText = 'Cancel') {
    try {
      this.ensureInitialized();
      
      const result = await this.sdk.execute('confirm', {
        message,
        confirmButton: confirmText,
        cancelButton: cancelText
      });
      
      return result;
    } catch (error) {
      console.error('Failed to show confirmation:', error);
      return false;
    }
  }

  // Show notice
  showNotice(message, type = 'info') {
    try {
      this.ensureInitialized();
      
      this.sdk.execute('notice', {
        message,
        type // 'info', 'success', 'error'
      });
    } catch (error) {
      console.error('Failed to show notice:', error);
    }
  }

  // Get context information
  getContext() {
    return this.context;
  }

  // Get current user
  getUser() {
    return this.user;
  }

  // Check if user is admin
  isAdmin() {
    return this.user?.is_admin || false;
  }

  // Get board ID from context
  getBoardId() {
    return this.context?.boardId || this.context?.boardIds?.[0];
  }

  // Get item ID from context
  getItemId() {
    return this.context?.itemId || this.context?.itemIds?.[0];
  }
}

// Create global instance
const mondaySDK = new MondaySDK();

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', async () => {
  try {
    await mondaySDK.init();
    console.log('Monday.com SDK initialized successfully');
    
    // Trigger custom event
    document.dispatchEvent(new CustomEvent('mondaySDKReady', {
      detail: { sdk: mondaySDK }
    }));
  } catch (error) {
    console.error('Failed to initialize Monday.com SDK:', error);
    Utils.showError('Failed to initialize Monday.com integration');
  }
});

// Export for global use
window.MondaySDK = mondaySDK; 