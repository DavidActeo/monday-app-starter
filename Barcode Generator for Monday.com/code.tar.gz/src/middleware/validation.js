/**
 * Validation Middleware
 * 
 * This file contains middleware functions for request validation,
 * input sanitization, and error handling using express-validator.
 */

const { validationResult, body, param, query } = require('express-validator');
const logger = require('../utils/logger');

// ==============================================
// VALIDATION ERROR HANDLER
// ==============================================

/**
 * Middleware to handle validation errors from express-validator
 */
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map(error => ({
      field: error.param,
      message: error.msg,
      value: error.value,
      location: error.location
    }));
    
    logger.warn('Validation errors:', {
      url: req.originalUrl,
      method: req.method,
      errors: errorMessages,
      userId: req.user ? req.user.id : 'anonymous'
    });
    
    return res.status(400).json({
      status: 'error',
      message: 'Validation failed',
      code: 'VALIDATION_ERROR',
      errors: errorMessages
    });
  }
  
  next();
};

// ==============================================
// COMMON VALIDATION RULES
// ==============================================

/**
 * Validation rules for barcode generation
 */
const validateBarcodeGeneration = [
  body('data')
    .notEmpty()
    .withMessage('Barcode data is required')
    .isLength({ min: 1, max: 500 })
    .withMessage('Barcode data must be between 1 and 500 characters')
    .trim()
    .escape(),
    
  body('type')
    .optional()
    .isIn(['code128', 'code39', 'ean13', 'ean8', 'upc', 'qr', 'datamatrix'])
    .withMessage('Invalid barcode type'),
    
  body('format')
    .optional()
    .isIn(['png', 'svg', 'jpeg', 'pdf'])
    .withMessage('Invalid output format'),
    
  body('width')
    .optional()
    .isInt({ min: 50, max: 2000 })
    .withMessage('Width must be between 50 and 2000 pixels'),
    
  body('height')
    .optional()
    .isInt({ min: 20, max: 1000 })
    .withMessage('Height must be between 20 and 1000 pixels'),
    
  body('includeText')
    .optional()
    .isBoolean()
    .withMessage('includeText must be a boolean'),
    
  body('textPosition')
    .optional()
    .isIn(['top', 'bottom', 'none'])
    .withMessage('Invalid text position')
];

/**
 * Validation rules for Monday.com board operations
 */
const validateBoardOperations = [
  param('boardId')
    .isInt({ min: 1 })
    .withMessage('Board ID must be a positive integer'),
    
  body('name')
    .optional()
    .isLength({ min: 1, max: 255 })
    .withMessage('Board name must be between 1 and 255 characters')
    .trim()
    .escape(),
    
  body('description')
    .optional()
    .isLength({ max: 1000 })
    .withMessage('Description must not exceed 1000 characters')
    .trim()
    .escape()
];

/**
 * Validation rules for Monday.com item operations
 */
const validateItemOperations = [
  param('itemId')
    .isInt({ min: 1 })
    .withMessage('Item ID must be a positive integer'),
    
  body('name')
    .optional()
    .isLength({ min: 1, max: 255 })
    .withMessage('Item name must be between 1 and 255 characters')
    .trim()
    .escape(),
    
  body('columnValues')
    .optional()
    .isObject()
    .withMessage('Column values must be an object'),
    
  body('groupId')
    .optional()
    .isString()
    .withMessage('Group ID must be a string')
];

/**
 * Validation rules for pagination
 */
const validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
    
  query('limit')
    .optional()
    .isInt({ min: 1, max: 1000 })
    .withMessage('Limit must be between 1 and 1000'),
    
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('Offset must be a non-negative integer')
];

/**
 * Validation rules for date ranges
 */
const validateDateRange = [
  query('startDate')
    .optional()
    .isISO8601()
    .withMessage('Start date must be a valid ISO 8601 date'),
    
  query('endDate')
    .optional()
    .isISO8601()
    .withMessage('End date must be a valid ISO 8601 date'),
    
  query('timezone')
    .optional()
    .isString()
    .withMessage('Timezone must be a string')
];

// ==============================================
// CUSTOM VALIDATORS
// ==============================================

/**
 * Custom validator to check if end date is after start date
 */
const validateDateRangeLogic = (req, res, next) => {
  const { startDate, endDate } = req.query;
  
  if (startDate && endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (start >= end) {
      return res.status(400).json({
        status: 'error',
        message: 'End date must be after start date',
        code: 'INVALID_DATE_RANGE'
      });
    }
  }
  
  next();
};

/**
 * Custom validator for Monday.com column values
 */
const validateColumnValues = (req, res, next) => {
  const { columnValues } = req.body;
  
  if (columnValues) {
    // Check if columnValues is a valid object
    if (typeof columnValues !== 'object' || Array.isArray(columnValues)) {
      return res.status(400).json({
        status: 'error',
        message: 'Column values must be an object',
        code: 'INVALID_COLUMN_VALUES'
      });
    }
    
    // Validate each column value
    for (const [columnId, value] of Object.entries(columnValues)) {
      if (!columnId || typeof columnId !== 'string') {
        return res.status(400).json({
          status: 'error',
          message: 'Column ID must be a non-empty string',
          code: 'INVALID_COLUMN_ID'
        });
      }
      
      // Basic validation for column values (can be extended based on column types)
      if (value !== null && typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean' && typeof value !== 'object') {
        return res.status(400).json({
          status: 'error',
          message: `Invalid value type for column ${columnId}`,
          code: 'INVALID_COLUMN_VALUE_TYPE'
        });
      }
    }
  }
  
  next();
};

/**
 * Validator for batch operations
 */
const validateBatchSize = (maxItems = 100) => {
  return (req, res, next) => {
    const { items } = req.body;
    
    if (items && Array.isArray(items)) {
      if (items.length > maxItems) {
        return res.status(400).json({
          status: 'error',
          message: `Batch size cannot exceed ${maxItems} items`,
          code: 'BATCH_SIZE_EXCEEDED',
          limit: maxItems,
          provided: items.length
        });
      }
      
      if (items.length === 0) {
        return res.status(400).json({
          status: 'error',
          message: 'Batch cannot be empty',
          code: 'EMPTY_BATCH'
        });
      }
    }
    
    next();
  };
};

// ==============================================
// FILE UPLOAD VALIDATION
// ==============================================

/**
 * Validator for file uploads
 */
const validateFileUpload = (allowedTypes = [], maxSizeMB = 10) => {
  return (req, res, next) => {
    if (!req.file) {
      return next(); // No file uploaded, skip validation
    }
    
    const file = req.file;
    const maxSizeBytes = maxSizeMB * 1024 * 1024;
    
    // Check file size
    if (file.size > maxSizeBytes) {
      return res.status(400).json({
        status: 'error',
        message: `File size exceeds ${maxSizeMB}MB limit`,
        code: 'FILE_SIZE_EXCEEDED',
        limit: maxSizeMB,
        size: Math.round(file.size / 1024 / 1024 * 100) / 100
      });
    }
    
    // Check file type
    if (allowedTypes.length > 0 && !allowedTypes.includes(file.mimetype)) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid file type',
        code: 'INVALID_FILE_TYPE',
        allowed: allowedTypes,
        provided: file.mimetype
      });
    }
    
    next();
  };
};

// ==============================================
// SANITIZATION MIDDLEWARE
// ==============================================

/**
 * Middleware to sanitize request data
 */
const sanitizeInput = (req, res, next) => {
  try {
    // Sanitize common XSS patterns
    const sanitizeValue = (value) => {
      if (typeof value === 'string') {
        return value
          .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
          .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
          .replace(/javascript:/gi, '')
          .replace(/on\w+=/gi, '');
      }
      return value;
    };
    
    // Recursively sanitize object
    const sanitizeObject = (obj) => {
      if (obj && typeof obj === 'object') {
        for (const key in obj) {
          if (obj.hasOwnProperty(key)) {
            if (typeof obj[key] === 'object') {
              sanitizeObject(obj[key]);
            } else {
              obj[key] = sanitizeValue(obj[key]);
            }
          }
        }
      }
    };
    
    // Sanitize request body, query, and params
    sanitizeObject(req.body);
    sanitizeObject(req.query);
    sanitizeObject(req.params);
    
    next();
  } catch (error) {
    logger.error('Input sanitization error:', error);
    next(); // Continue on error to avoid blocking requests
  }
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  handleValidationErrors,
  validateBarcodeGeneration,
  validateBoardOperations,
  validateItemOperations,
  validatePagination,
  validateDateRange,
  validateDateRangeLogic,
  validateColumnValues,
  validateBatchSize,
  validateFileUpload,
  sanitizeInput
}; 