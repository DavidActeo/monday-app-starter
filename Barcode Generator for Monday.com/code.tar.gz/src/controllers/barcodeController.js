/**
 * Barcode Controller
 * Handles barcode generation, management, and Monday.com integration
 */

const logger = require('../utils/logger');
const barcodeService = require('../services/barcodeService');
const mondayService = require('../services/mondayService');
const pricingService = require('../services/pricingService');
const { createError } = require('../middleware/errorHandler');

/**
 * Generate a barcode and upload to Monday.com
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const generateBarcodeAndUpload = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { value, type, boardId, itemId, columnId, width, height } = req.body;

    logger.info('Barcode generation and upload request', { 
      userId, 
      type, 
      boardId, 
      itemId, 
      columnId 
    });

    // Check pricing and plan access
    const userPlan = req.user.plan || 'freemium'; // Default to freemium if no plan
    
    // Validate barcode type access based on user plan
    const typeAccess = await pricingService.validateBarcodeTypeAccess(userPlan, type);
    if (!typeAccess.allowed) {
      return res.status(403).json({
        success: false,
        message: typeAccess.reason,
        error: 'PLAN_UPGRADE_REQUIRED',
        upgradeUrl: '/pricing'
      });
    }

    // No usage limits - all plans have unlimited barcode generation
    logger.info('No usage limits enforced - unlimited generation for all plans');

    // Get item details for metadata
    const itemData = await mondayService.getItemById(itemId, req.user.mondayToken);
    const boardData = await mondayService.getUserBoards(req.user.mondayToken);
    const board = boardData.find(b => b.id.toString() === boardId.toString());
    
    const barcodeParams = {
      value,
      type,
      userId,
      boardId,
      itemId,
      columnId,
      width,
      height,
      boardName: board?.name || 'Unknown Board',
      itemName: itemData?.name || 'Unknown Item'
    };

    // Generate the barcode
    const barcodeResult = await barcodeService.generateBarcode(barcodeParams);

    // Upload to Monday.com file column
    const uploadResult = await mondayService.uploadFileToColumn(
      itemId,
      columnId,
      barcodeResult.data.imageBuffer,
      barcodeResult.data.filename,
      barcodeResult.data.mimeType,
      req.user.mondayToken
    );

    logger.barcodeOperation('generate_and_upload_success', { 
      userId, 
      barcodeId: barcodeResult.data.id,
      mondayFileId: uploadResult?.id
    });

    res.status(201).json({
      success: true,
      message: 'Barcode generated and uploaded successfully',
      data: {
        ...barcodeResult.data,
        mondayFileId: uploadResult?.id,
        mondayFileUrl: uploadResult?.url
      }
    });
  } catch (error) {
    logger.error('Barcode generation and upload failed', { 
      error: error.message, 
      userId: req.user?.id,
      params: req.body 
    });

    next(createError(500, 'Failed to generate and upload barcode', 'BARCODE_UPLOAD_FAILED'));
  }
};

/**
 * Generate a barcode (legacy function for compatibility)
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const generateBarcode = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const barcodeParams = { ...req.body, userId };

    logger.barcodeOperation('generate_request', { userId, params: barcodeParams });

    const result = await barcodeService.generateBarcode(barcodeParams);

    logger.barcodeOperation('generate_success', { 
      userId, 
      barcodeId: result.data.id 
    });

    res.status(201).json({
      success: true,
      message: 'Barcode generated successfully',
      data: result.data
    });
  } catch (error) {
    logger.error('Barcode generation failed', { 
      error: error.message, 
      userId: req.user?.id,
      params: req.body 
    });

    next(createError(500, 'Failed to generate barcode', 'BARCODE_GENERATION_FAILED'));
  }
};

/**
 * Get barcode generation history for user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const getBarcodeHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { limit, offset } = req.query;

    logger.barcodeOperation('history_request', { userId, limit, offset });

    const result = await barcodeService.getBarcodeHistory(userId, { limit, offset });

    logger.barcodeOperation('history_success', { 
      userId, 
      count: result.data.length 
    });

    res.status(200).json({
      success: true,
      data: result.data,
      pagination: result.pagination
    });
  } catch (error) {
    logger.error('Failed to get barcode history', { 
      error: error.message, 
      userId: req.user?.id 
    });

    next(createError(500, 'Failed to get barcode history', 'HISTORY_FETCH_FAILED'));
  }
};

/**
 * Get barcode by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const getBarcodeById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    logger.barcodeOperation('get_by_id_request', { userId, barcodeId: id });

    const result = await barcodeService.getBarcodeById(id);

    if (!result.success) {
      return res.status(404).json({
        success: false,
        message: 'Barcode not found'
      });
    }

    // Check if user has access to this barcode
    if (result.data.metadata.userId !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    logger.barcodeOperation('get_by_id_success', { userId, barcodeId: id });

    res.status(200).json({
      success: true,
      data: result.data
    });
  } catch (error) {
    logger.error('Failed to get barcode by ID', { 
      error: error.message, 
      userId: req.user?.id,
      barcodeId: req.params.id 
    });

    next(createError(500, 'Failed to retrieve barcode', 'BARCODE_FETCH_FAILED'));
  }
};

/**
 * Delete a barcode
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const deleteBarcode = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    logger.barcodeOperation('delete_request', { userId, barcodeId: id });

    const result = await barcodeService.deleteBarcode(id, userId);

    logger.barcodeOperation('delete_success', { userId, barcodeId: id });

    res.status(200).json({
      success: true,
      message: 'Barcode deleted successfully',
      data: result.data
    });
  } catch (error) {
    logger.error('Failed to delete barcode', { 
      error: error.message, 
      userId: req.user?.id,
      barcodeId: req.params.id 
    });

    next(createError(500, 'Failed to delete barcode', 'BARCODE_DELETE_FAILED'));
  }
};

/**
 * Generate multiple barcodes in batch
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const generateBatchBarcodes = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { items } = req.body;

    logger.barcodeOperation('batch_generate_request', { userId, itemCount: items.length });

    const result = await barcodeService.generateBatchBarcodes(items, userId);

    logger.barcodeOperation('batch_generate_success', { 
      userId, 
      successful: result.data.successful,
      failed: result.data.failed
    });

    res.status(201).json({
      success: true,
      message: 'Batch barcode generation completed',
      data: result.data
    });
  } catch (error) {
    logger.error('Batch barcode generation failed', { 
      error: error.message, 
      userId: req.user?.id,
      params: req.body 
    });

    next(createError(500, 'Failed to generate batch barcodes', 'BATCH_GENERATION_FAILED'));
  }
};

/**
 * Export barcodes
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const exportBarcodes = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { format = 'csv', filters = {} } = req.body;

    logger.barcodeOperation('export_request', { userId, format });

    const result = await barcodeService.exportBarcodes({ userId, format, filters });

    logger.barcodeOperation('export_success', { 
      userId, 
      format,
      recordCount: result.data.recordCount
    });

    // Set appropriate headers for download
    res.setHeader('Content-Type', result.data.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${result.data.filename}"`);
    
    res.status(200).send(result.data.content);
  } catch (error) {
    logger.error('Barcode export failed', { 
      error: error.message, 
      userId: req.user?.id,
      params: req.body 
    });

    next(createError(500, 'Failed to export barcodes', 'EXPORT_FAILED'));
  }
};

/**
 * Validate barcode data
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const validateBarcodeData = async (req, res, next) => {
  try {
    const { value, type } = req.body;

    logger.barcodeOperation('validate_request', { type, valueLength: value?.length });

    const result = await barcodeService.validateBarcodeData({ value, type });

    res.status(200).json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('Barcode validation failed', { 
      error: error.message,
      params: req.body 
    });

    next(createError(500, 'Failed to validate barcode data', 'VALIDATION_FAILED'));
  }
};

/**
 * Get barcode statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const getBarcodeStats = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { period = '30d' } = req.query;

    logger.barcodeOperation('stats_request', { userId, period });

    const result = await barcodeService.getBarcodeStats(userId, period);

    logger.barcodeOperation('stats_success', { userId, period });

    res.status(200).json({
      success: true,
      data: result.data
    });
  } catch (error) {
    logger.error('Failed to get barcode stats', { 
      error: error.message, 
      userId: req.user?.id 
    });

    next(createError(500, 'Failed to get barcode statistics', 'STATS_FETCH_FAILED'));
  }
};

/**
 * Update barcode metadata
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
const updateBarcode = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const updateData = req.body;

    logger.barcodeOperation('update_request', { userId, barcodeId: id });

    const result = await barcodeService.updateBarcode(id, updateData, userId);

    logger.barcodeOperation('update_success', { userId, barcodeId: id });

    res.status(200).json({
      success: true,
      message: 'Barcode updated successfully',
      data: result.data
    });
  } catch (error) {
    logger.error('Failed to update barcode', { 
      error: error.message, 
      userId: req.user?.id,
      barcodeId: req.params.id 
    });

    next(createError(500, 'Failed to update barcode', 'BARCODE_UPDATE_FAILED'));
  }
};

module.exports = {
  generateBarcode,
  generateBarcodeAndUpload,
  getBarcodeHistory,
  deleteBarcode,
  generateBatchBarcodes,
  exportBarcodes,
  validateBarcodeData,
  getBarcodeStats,
  getBarcodeById,
  updateBarcode
}; 