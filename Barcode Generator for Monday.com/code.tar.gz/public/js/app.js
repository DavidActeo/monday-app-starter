/**
 * Main Application JavaScript
 * Handles barcode generation UI and interactions
 */

class BarcodeGeneratorApp {
  constructor() {
    this.currentTab = 'generate';
    this.boards = [];
    this.selectedBoard = null;
    this.selectedItem = null;
    this.barcodeHistory = [];
    this.settings = {
      defaultBarcodeType: 'QR',
      autoSave: true,
      showPreview: true
    };
  }

  // Initialize the application
  async init() {
    try {
      Utils.showLoading('Initializing application...');
      
      // Wait for Monday SDK to be ready
      if (!window.MondaySDK.initialized) {
        await new Promise((resolve) => {
          document.addEventListener('mondaySDKReady', resolve, { once: true });
        });
      }

      this.setupEventListeners();
      await this.loadUserBoards();
      await this.loadBarcodeHistory();
      this.restoreSettings();
      
      Utils.hideLoading();
      Utils.showSuccess('Application initialized successfully');
    } catch (error) {
      console.error('Failed to initialize app:', error);
      Utils.hideLoading();
      Utils.showError('Failed to initialize application: ' + error.message);
    }
  }

  // Setup event listeners
  setupEventListeners() {
    // Tab navigation
    document.querySelectorAll('.tab-button').forEach(button => {
      button.addEventListener('click', (e) => {
        const tabId = e.target.dataset.tab;
        this.switchToTab(tabId);
      });
    });

    // Barcode generation form
    const generateForm = Utils.$('#barcode-form');
    if (generateForm) {
      generateForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleBarcodeGeneration();
      });
    }

    // Board selection
    const boardSelect = Utils.$('#board-select');
    if (boardSelect) {
      boardSelect.addEventListener('change', (e) => {
        this.handleBoardSelection(e.target.value);
      });
    }

    // Item selection
    const itemSelect = Utils.$('#item-select');
    if (itemSelect) {
      itemSelect.addEventListener('change', (e) => {
        this.handleItemSelection(e.target.value);
      });
    }

    // Barcode type change
    const barcodeType = Utils.$('#barcode-type');
    if (barcodeType) {
      barcodeType.addEventListener('change', (e) => {
        this.handleBarcodeTypeChange(e.target.value);
      });
    }

    // Settings form
    const settingsForm = Utils.$('#settings-form');
    if (settingsForm) {
      settingsForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleSettingsUpdate();
      });
    }

    // Test action button
    const testActionBtn = Utils.$('#test-action-btn');
    if (testActionBtn) {
      testActionBtn.addEventListener('click', () => {
        this.testBarcodeAction();
      });
    }

    // Refresh buttons
    const refreshBoardsBtn = Utils.$('#refresh-boards-btn');
    if (refreshBoardsBtn) {
      refreshBoardsBtn.addEventListener('click', () => {
        this.loadUserBoards();
      });
    }

    // History refresh
    const refreshHistoryBtn = Utils.$('#refresh-history-btn');
    if (refreshHistoryBtn) {
      refreshHistoryBtn.addEventListener('click', () => {
        this.loadBarcodeHistory();
      });
    }
  }

  // Switch to a specific tab
  switchToTab(tabId) {
    this.currentTab = tabId;
    Utils.switchTab(tabId);
    
    // Load tab-specific data
    switch (tabId) {
      case 'history':
        this.loadBarcodeHistory();
        break;
      case 'settings':
        this.loadSettings();
        break;
    }
  }

  // Load user's boards
  async loadUserBoards() {
    try {
      Utils.showLoading('Loading boards...');
      
      this.boards = await window.MondaySDK.getBoards();
      this.populateBoardSelect();
      
      // Auto-select current board if available
      const currentBoardId = window.MondaySDK.getBoardId();
      if (currentBoardId) {
        this.handleBoardSelection(currentBoardId);
      }
      
      Utils.hideLoading();
    } catch (error) {
      console.error('Failed to load boards:', error);
      Utils.hideLoading();
      Utils.showError('Failed to load boards: ' + error.message);
    }
  }

  // Populate board selection dropdown
  populateBoardSelect() {
    const boardSelect = Utils.$('#board-select');
    if (!boardSelect) return;

    boardSelect.innerHTML = '<option value="">Select a board...</option>';
    
    this.boards.forEach(board => {
      const option = document.createElement('option');
      option.value = board.id;
      option.textContent = board.name;
      boardSelect.appendChild(option);
    });
  }

  // Handle board selection
  async handleBoardSelection(boardId) {
    if (!boardId) return;

    try {
      Utils.showLoading('Loading board items...');
      
      this.selectedBoard = this.boards.find(b => b.id === parseInt(boardId));
      const items = await window.MondaySDK.getBoardItems(boardId);
      
      this.populateItemSelect(items);
      this.populateColumnSelect(this.selectedBoard.columns);
      
      Utils.hideLoading();
    } catch (error) {
      console.error('Failed to load board items:', error);
      Utils.hideLoading();
      Utils.showError('Failed to load board items: ' + error.message);
    }
  }

  // Populate item selection dropdown
  populateItemSelect(items) {
    const itemSelect = Utils.$('#item-select');
    if (!itemSelect) return;

    itemSelect.innerHTML = '<option value="">Select an item...</option>';
    
    items.forEach(item => {
      const option = document.createElement('option');
      option.value = item.id;
      option.textContent = item.name;
      itemSelect.appendChild(option);
    });

    // Auto-select current item if available
    const currentItemId = window.MondaySDK.getItemId();
    if (currentItemId) {
      itemSelect.value = currentItemId;
      this.handleItemSelection(currentItemId);
    }
  }

  // Populate file column selection dropdown
  populateColumnSelect(columns) {
    const columnSelect = Utils.$('#file-column-select');
    if (!columnSelect) return;

    columnSelect.innerHTML = '<option value="">Select a file column...</option>';
    
    // Filter for file columns
    const fileColumns = columns.filter(col => col.type === 'file');
    
    fileColumns.forEach(column => {
      const option = document.createElement('option');
      option.value = column.id;
      option.textContent = column.title;
      columnSelect.appendChild(option);
    });

    if (fileColumns.length === 0) {
      const noColumnsOption = document.createElement('option');
      noColumnsOption.value = '';
      noColumnsOption.textContent = 'No file columns found';
      noColumnsOption.disabled = true;
      columnSelect.appendChild(noColumnsOption);
    }
  }

  // Handle item selection
  handleItemSelection(itemId) {
    this.selectedItem = itemId;
  }

  // Handle barcode type change
  handleBarcodeTypeChange(type) {
    const barcodeValue = Utils.$('#barcode-value');
    const helpText = Utils.$('#barcode-help-text');
    
    if (!barcodeValue || !helpText) return;

    switch (type) {
      case 'QR':
        barcodeValue.placeholder = 'Enter text, URL, or data for QR code';
        helpText.textContent = 'QR codes can contain up to 2,953 characters including text, URLs, phone numbers, etc.';
        break;
      case 'CODE128':
        barcodeValue.placeholder = 'Enter alphanumeric text for Code128';
        helpText.textContent = 'Code128 supports alphanumeric characters and is commonly used for inventory tracking.';
        break;
      default:
        barcodeValue.placeholder = 'Enter barcode value';
        helpText.textContent = 'Select a barcode type for specific format information.';
    }
  }

  // Handle barcode generation
  async handleBarcodeGeneration() {
    try {
      const formData = Utils.getFormData('#barcode-form');
      
      // Validate form data
      const validation = this.validateBarcodeForm(formData);
      if (!validation.valid) {
        Utils.showError(validation.message);
        return;
      }

      Utils.showLoading('Generating barcode...');

      // Call backend API to generate barcode
      const response = await Utils.apiRequest('/api/barcode/generate', {
        method: 'POST',
        body: JSON.stringify({
          value: formData['barcode-value'],
          type: formData['barcode-type'],
          boardId: formData['board-select'],
          itemId: formData['item-select'],
          columnId: formData['file-column-select']
        })
      });

      if (response.success) {
        Utils.hideLoading();
        Utils.showSuccess('Barcode generated and uploaded successfully!');
        
        // Show preview if enabled
        if (this.settings.showPreview && response.data.previewUrl) {
          this.showBarcodePreview(response.data);
        }
        
        // Refresh history
        this.loadBarcodeHistory();
        
        // Clear form if not auto-saving
        if (!this.settings.autoSave) {
          Utils.clearForm('#barcode-form');
        }
      } else {
        throw new Error(response.message || 'Failed to generate barcode');
      }
    } catch (error) {
      console.error('Failed to generate barcode:', error);
      Utils.hideLoading();
      Utils.showError('Failed to generate barcode: ' + error.message);
    }
  }

  // Validate barcode generation form
  validateBarcodeForm(formData) {
    if (!formData['barcode-value'] || !formData['barcode-value'].trim()) {
      return { valid: false, message: 'Barcode value is required' };
    }

    if (!formData['barcode-type']) {
      return { valid: false, message: 'Barcode type is required' };
    }

    if (!formData['board-select']) {
      return { valid: false, message: 'Please select a board' };
    }

    if (!formData['item-select']) {
      return { valid: false, message: 'Please select an item' };
    }

    if (!formData['file-column-select']) {
      return { valid: false, message: 'Please select a file column' };
    }

    // Validate barcode value based on type
    const barcodeValidation = Utils.validateBarcodeInput(
      formData['barcode-value'], 
      formData['barcode-type']
    );
    
    if (!barcodeValidation.valid) {
      return barcodeValidation;
    }

    return { valid: true };
  }

  // Show barcode preview
  showBarcodePreview(barcodeData) {
    const previewContainer = Utils.$('#barcode-preview');
    if (!previewContainer) return;

    previewContainer.innerHTML = `
      <div class="barcode-preview-item">
        <h4>Generated Barcode</h4>
        <img src="${barcodeData.previewUrl}" alt="Generated barcode" class="barcode-image">
        <div class="barcode-details">
          <p><strong>Type:</strong> ${barcodeData.type}</p>
          <p><strong>Value:</strong> ${barcodeData.value}</p>
          <p><strong>Size:</strong> ${Utils.formatFileSize(barcodeData.fileSize)}</p>
        </div>
      </div>
    `;
    
    Utils.show(previewContainer);
  }

  // Load barcode history
  async loadBarcodeHistory() {
    try {
      const response = await Utils.apiRequest('/api/barcode/history');
      
      if (response.success) {
        this.barcodeHistory = response.data;
        this.populateHistoryTable();
      }
    } catch (error) {
      console.error('Failed to load barcode history:', error);
      Utils.showError('Failed to load barcode history');
    }
  }

  // Populate history table
  populateHistoryTable() {
    const historyTable = Utils.$('#history-table tbody');
    if (!historyTable) return;

    historyTable.innerHTML = '';

    if (this.barcodeHistory.length === 0) {
      historyTable.innerHTML = `
        <tr>
          <td colspan="6" class="no-data">No barcode history found</td>
        </tr>
      `;
      return;
    }

    this.barcodeHistory.forEach(barcode => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${Utils.formatDate(barcode.createdAt)}</td>
        <td>${barcode.type}</td>
        <td class="barcode-value" title="${barcode.value}">${this.truncateText(barcode.value, 30)}</td>
        <td>${barcode.boardName || 'N/A'}</td>
        <td>${barcode.itemName || 'N/A'}</td>
        <td>
          <button class="btn btn-sm" onclick="app.viewBarcode('${barcode.id}')">View</button>
          <button class="btn btn-sm btn-danger" onclick="app.deleteBarcode('${barcode.id}')">Delete</button>
        </td>
      `;
      historyTable.appendChild(row);
    });
  }

  // Truncate text helper
  truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  // View barcode details
  async viewBarcode(barcodeId) {
    try {
      const response = await Utils.apiRequest(`/api/barcode/${barcodeId}`);
      
      if (response.success) {
        this.showBarcodeModal(response.data);
      }
    } catch (error) {
      console.error('Failed to load barcode details:', error);
      Utils.showError('Failed to load barcode details');
    }
  }

  // Show barcode modal
  showBarcodeModal(barcodeData) {
    // Create modal if it doesn't exist
    let modal = Utils.$('#barcode-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'barcode-modal';
      modal.className = 'modal';
      document.body.appendChild(modal);
    }

    modal.innerHTML = `
      <div class="modal-content">
        <span class="modal-close" onclick="this.closest('.modal').style.display='none'">&times;</span>
        <h3>Barcode Details</h3>
        <div class="barcode-modal-content">
          <img src="${barcodeData.imageUrl}" alt="Barcode" class="barcode-image-large">
          <div class="barcode-details">
            <p><strong>Type:</strong> ${barcodeData.type}</p>
            <p><strong>Value:</strong> ${barcodeData.value}</p>
            <p><strong>Created:</strong> ${Utils.formatDate(barcodeData.createdAt)}</p>
            <p><strong>Board:</strong> ${barcodeData.boardName}</p>
            <p><strong>Item:</strong> ${barcodeData.itemName}</p>
            <p><strong>File Size:</strong> ${Utils.formatFileSize(barcodeData.fileSize)}</p>
          </div>
        </div>
      </div>
    `;

    modal.style.display = 'block';
  }

  // Delete barcode
  async deleteBarcode(barcodeId) {
    try {
      const confirmed = await window.MondaySDK.showConfirm(
        'Are you sure you want to delete this barcode?',
        'Delete',
        'Cancel'
      );

      if (!confirmed) return;

      const response = await Utils.apiRequest(`/api/barcode/${barcodeId}`, {
        method: 'DELETE'
      });

      if (response.success) {
        Utils.showSuccess('Barcode deleted successfully');
        this.loadBarcodeHistory();
      }
    } catch (error) {
      console.error('Failed to delete barcode:', error);
      Utils.showError('Failed to delete barcode');
    }
  }

  // Load settings
  loadSettings() {
    const settingsForm = Utils.$('#settings-form');
    if (settingsForm) {
      Utils.setFormData(settingsForm, this.settings);
    }
  }

  // Handle settings update
  handleSettingsUpdate() {
    const formData = Utils.getFormData('#settings-form');
    
    this.settings = {
      ...this.settings,
      ...formData
    };

    this.saveSettings();
    Utils.showSuccess('Settings updated successfully');
  }

  // Save settings to localStorage
  saveSettings() {
    try {
      localStorage.setItem('barcodeGeneratorSettings', JSON.stringify(this.settings));
    } catch (error) {
      console.error('Failed to save settings:', error);
    }
  }

  // Restore settings from localStorage
  restoreSettings() {
    try {
      const saved = localStorage.getItem('barcodeGeneratorSettings');
      if (saved) {
        this.settings = { ...this.settings, ...JSON.parse(saved) };
      }
    } catch (error) {
      console.error('Failed to restore settings:', error);
    }
  }

  // Test barcode action
  async testBarcodeAction() {
    try {
      const testData = {
        value: 'TEST-' + Date.now(),
        type: 'QR',
        boardId: this.selectedBoard?.id,
        itemId: this.selectedItem,
        columnId: Utils.$('#file-column-select')?.value
      };

      if (!testData.boardId || !testData.itemId || !testData.columnId) {
        Utils.showError('Please select a board, item, and file column first');
        return;
      }

      Utils.showLoading('Testing barcode action...');

      const response = await Utils.apiRequest('/api/barcode/generate', {
        method: 'POST',
        body: JSON.stringify(testData)
      });

      if (response.success) {
        Utils.hideLoading();
        Utils.showSuccess('Test barcode created successfully!');
        window.MondaySDK.showNotice('Test barcode uploaded to your selected item', 'success');
      } else {
        throw new Error(response.message);
      }
    } catch (error) {
      console.error('Test action failed:', error);
      Utils.hideLoading();
      Utils.showError('Test action failed: ' + error.message);
    }
  }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.app = new BarcodeGeneratorApp();
  window.app.init();
}); 