/**
 * Authentication Middleware
 * 
 * This file contains middleware functions for handling authentication,
 * JWT token validation, and Monday.com API token management.
 */

const jwt = require('jsonwebtoken');
const axios = require('axios');
const logger = require('../utils/logger');

// ==============================================
// JWT AUTHENTICATION MIDDLEWARE
// ==============================================

/**
 * Middleware to authenticate JWT tokens
 */
const authenticate = async (req, res, next) => {
  try {
    // Extract token from Authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return res.status(401).json({
        status: 'error',
        message: 'Authorization header missing',
        code: 'AUTH_HEADER_MISSING'
      });
    }

    // Check if header starts with "Bearer "
    if (!authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        status: 'error',
        message: 'Authorization header must start with "Bearer "',
        code: 'INVALID_AUTH_HEADER_FORMAT'
      });
    }

    // Extract the token
    const token = authHeader.substring(7);
    
    if (!token) {
      return res.status(401).json({
        status: 'error',
        message: 'JWT token missing',
        code: 'JWT_TOKEN_MISSING'
      });
    }

    // Verify the JWT token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Attach user information to request object
    req.user = decoded;
    
    // Log successful authentication
    logger.info('User authenticated successfully', {
      userId: decoded.id,
      accountId: decoded.accountId
    });

    next();
  } catch (error) {
    logger.error('Authentication error:', error);
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid JWT token',
        code: 'INVALID_JWT_TOKEN'
      });
    }
    
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        status: 'error',
        message: 'JWT token has expired',
        code: 'JWT_TOKEN_EXPIRED'
      });
    }
    
    return res.status(500).json({
      status: 'error',
      message: 'Authentication error',
      code: 'AUTHENTICATION_ERROR'
    });
  }
};

// ==============================================
// MONDAY.COM TOKEN VALIDATION
// ==============================================

/**
 * Middleware to validate Monday.com access token
 */
const validateMondayToken = async (req, res, next) => {
  try {
    const user = req.user;
    
    if (!user || !user.accessToken) {
      return res.status(401).json({
        status: 'error',
        message: 'Monday.com access token missing',
        code: 'MONDAY_TOKEN_MISSING'
      });
    }

    // Test the Monday.com token by making a simple API call
    const response = await axios.post('https://api.monday.com/v2', 
      {
        query: 'query { me { id name email } }'
      },
      {
        headers: {
          'Authorization': `Bearer ${user.accessToken}`,
          'Content-Type': 'application/json'
        },
        timeout: 5000
      }
    );

    if (response.data.errors) {
      logger.warn('Monday.com token validation failed:', response.data.errors);
      return res.status(401).json({
        status: 'error',
        message: 'Invalid Monday.com access token',
        code: 'INVALID_MONDAY_TOKEN'
      });
    }

    // Attach Monday.com user data to request
    req.mondayUser = response.data.data.me;
    
    next();
  } catch (error) {
    logger.error('Monday.com token validation error:', error);
    
    if (error.response && error.response.status === 401) {
      return res.status(401).json({
        status: 'error',
        message: 'Monday.com access token expired or invalid',
        code: 'MONDAY_TOKEN_INVALID'
      });
    }
    
    return res.status(500).json({
      status: 'error',
      message: 'Error validating Monday.com token',
      code: 'MONDAY_TOKEN_VALIDATION_ERROR'
    });
  }
};

// ==============================================
// ROLE-BASED ACCESS CONTROL
// ==============================================

/**
 * Middleware to check user roles and permissions
 */
const checkPermissions = (requiredPermissions = []) => {
  return (req, res, next) => {
    try {
      const user = req.user;
      
      if (!user) {
        return res.status(401).json({
          status: 'error',
          message: 'User authentication required',
          code: 'USER_NOT_AUTHENTICATED'
        });
      }

      // Check if user has required permissions
      const userPermissions = user.permissions || [];
      const hasPermission = requiredPermissions.every(permission => 
        userPermissions.includes(permission)
      );

      if (!hasPermission) {
        logger.warn('Permission denied for user', {
          userId: user.id,
          requiredPermissions,
          userPermissions
        });
        
        return res.status(403).json({
          status: 'error',
          message: 'Insufficient permissions',
          code: 'INSUFFICIENT_PERMISSIONS',
          required: requiredPermissions,
          current: userPermissions
        });
      }

      next();
    } catch (error) {
      logger.error('Permission check error:', error);
      return res.status(500).json({
        status: 'error',
        message: 'Error checking permissions',
        code: 'PERMISSION_CHECK_ERROR'
      });
    }
  };
};

// ==============================================
// RATE LIMITING MIDDLEWARE
// ==============================================

/**
 * Middleware for user-specific rate limiting
 */
const userRateLimit = (maxRequests = 100, windowMs = 900000) => {
  const requests = new Map();
  
  return (req, res, next) => {
    try {
      const user = req.user;
      const userId = user ? user.id : req.ip;
      const now = Date.now();
      const windowStart = now - windowMs;
      
      // Get or create user request log
      if (!requests.has(userId)) {
        requests.set(userId, []);
      }
      
      const userRequests = requests.get(userId);
      
      // Remove old requests outside the time window
      const recentRequests = userRequests.filter(timestamp => timestamp > windowStart);
      requests.set(userId, recentRequests);
      
      // Check if user has exceeded rate limit
      if (recentRequests.length >= maxRequests) {
        return res.status(429).json({
          status: 'error',
          message: 'Rate limit exceeded',
          code: 'RATE_LIMIT_EXCEEDED',
          limit: maxRequests,
          windowMs: windowMs,
          retryAfter: Math.ceil((recentRequests[0] + windowMs - now) / 1000)
        });
      }
      
      // Add current request timestamp
      recentRequests.push(now);
      
      next();
    } catch (error) {
      logger.error('Rate limiting error:', error);
      next(); // Continue on error to avoid blocking all requests
    }
  };
};

// ==============================================
// OPTIONAL AUTHENTICATION
// ==============================================

/**
 * Middleware for optional authentication (doesn't fail if no token provided)
 */
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      // No token provided, continue without authentication
      req.user = null;
      return next();
    }

    const token = authHeader.substring(7);
    
    if (!token) {
      req.user = null;
      return next();
    }

    // Try to verify the JWT token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    
    next();
  } catch (error) {
    // If token verification fails, continue without authentication
    logger.warn('Optional authentication failed:', error.message);
    req.user = null;
    next();
  }
};

// ==============================================
// DEVELOPMENT MIDDLEWARE
// ==============================================

/**
 * Middleware to bypass authentication in development mode (use with caution)
 */
const devBypassAuth = (req, res, next) => {
  if (process.env.NODE_ENV === 'development' && process.env.BYPASS_AUTH === 'true') {
    logger.warn('Authentication bypassed in development mode');
    
    // Create a mock user for development
    req.user = {
      id: 'dev-user-123',
      name: 'Development User',
      email: 'dev@example.com',
      accountId: 'dev-account-123',
      accessToken: 'dev-token',
      permissions: ['read', 'write', 'admin']
    };
    
    return next();
  }
  
  // In production or when bypass is disabled, use normal authentication
  return authenticate(req, res, next);
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  authenticate,
  validateMondayToken,
  checkPermissions,
  userRateLimit,
  optionalAuth,
  devBypassAuth
}; 