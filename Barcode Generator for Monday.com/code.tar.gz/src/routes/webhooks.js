/**
 * Webhook Routes - Monday.com webhook handlers
 * 
 * This file handles incoming webhooks from Monday.com including
 * board updates, item changes, and other Monday.com events.
 */

const express = require('express');
const router = express.Router();
const crypto = require('crypto');

// Controllers
const authController = require('../controllers/authController');

// Utils
const logger = require('../utils/logger');

// ==============================================
// WEBHOOK VERIFICATION MIDDLEWARE
// ==============================================

/**
 * Middleware to verify Monday.com webhook signatures
 */
const verifyWebhookSignature = (req, res, next) => {
  try {
    const signature = req.headers['authorization'];
    const body = JSON.stringify(req.body);
    
    if (!signature) {
      return res.status(401).json({
        status: 'error',
        message: 'Missing webhook signature',
        code: 'SIGNATURE_MISSING'
      });
    }

    // Extract the signature from the Authorization header
    const receivedSignature = signature.replace('Bearer ', '');
    
    // Calculate expected signature
    const expectedSignature = crypto
      .createHmac('sha256', process.env.MONDAY_SIGNING_SECRET || 'default-secret')
      .update(body)
      .digest('hex');

    // Compare signatures
    if (!crypto.timingSafeEqual(Buffer.from(receivedSignature), Buffer.from(expectedSignature))) {
      logger.warn('Webhook signature verification failed', {
        received: receivedSignature,
        expected: expectedSignature
      });
      
      return res.status(401).json({
        status: 'error',
        message: 'Invalid webhook signature',
        code: 'SIGNATURE_INVALID'
      });
    }

    logger.info('Webhook signature verified successfully');
    next();
  } catch (error) {
    logger.error('Error verifying webhook signature:', error);
    return res.status(500).json({
      status: 'error',
      message: 'Error verifying webhook signature',
      code: 'SIGNATURE_VERIFICATION_ERROR'
    });
  }
};

// ==============================================
// MAIN WEBHOOK ENDPOINTS
// ==============================================

/**
 * @route   POST /webhooks/monday
 * @desc    Main Monday.com webhook handler
 * @access  Public (but signature verified)
 */
router.post('/monday', verifyWebhookSignature, (req, res) => {
  try {
    const { event, data } = req.body;
    
    logger.info('Received Monday.com webhook:', {
      event: event,
      dataKeys: Object.keys(data || {}),
      timestamp: new Date().toISOString()
    });

    // Handle different webhook events
    switch (event) {
      case 'create_item':
        handleItemCreated(data, req, res);
        break;
        
      case 'change_column_value':
        handleColumnValueChanged(data, req, res);
        break;
        
      case 'create_subitem':
        handleSubitemCreated(data, req, res);
        break;
        
      case 'move_item':
        handleItemMoved(data, req, res);
        break;
        
      case 'archive_item':
        handleItemArchived(data, req, res);
        break;
        
      case 'delete_item':
        handleItemDeleted(data, req, res);
        break;
        
      case 'create_board':
        handleBoardCreated(data, req, res);
        break;
        
      case 'create_column':
        handleColumnCreated(data, req, res);
        break;
        
      default:
        logger.warn('Unhandled webhook event:', event);
        res.status(200).json({
          status: 'success',
          message: `Webhook event '${event}' received but not handled`,
          code: 'EVENT_NOT_HANDLED'
        });
    }
  } catch (error) {
    logger.error('Error processing Monday.com webhook:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error processing webhook',
      code: 'WEBHOOK_PROCESSING_ERROR'
    });
  }
});

/**
 * @route   GET /webhooks/monday/health
 * @desc    Webhook health check endpoint
 * @access  Public
 */
router.get('/monday/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'Monday.com webhook endpoint is healthy',
    timestamp: new Date().toISOString()
  });
});

// ==============================================
// WEBHOOK EVENT HANDLERS
// ==============================================

/**
 * Handle item creation webhook
 */
function handleItemCreated(data, req, res) {
  logger.info('Processing item creation webhook:', data);
  
  // TODO: Implement barcode generation logic when item is created
  // This could trigger automatic barcode generation based on item properties
  
  res.status(200).json({
    status: 'success',
    message: 'Item creation webhook processed',
    code: 'ITEM_CREATED_PROCESSED'
  });
}

/**
 * Handle column value change webhook
 */
function handleColumnValueChanged(data, req, res) {
  logger.info('Processing column value change webhook:', data);
  
  // TODO: Check if the changed column is related to barcode data
  // Regenerate barcode if necessary
  
  res.status(200).json({
    status: 'success',
    message: 'Column value change webhook processed',
    code: 'COLUMN_VALUE_CHANGE_PROCESSED'
  });
}

/**
 * Handle subitem creation webhook
 */
function handleSubitemCreated(data, req, res) {
  logger.info('Processing subitem creation webhook:', data);
  
  // TODO: Handle barcode generation for subitems if needed
  
  res.status(200).json({
    status: 'success',
    message: 'Subitem creation webhook processed',
    code: 'SUBITEM_CREATED_PROCESSED'
  });
}

/**
 * Handle item move webhook
 */
function handleItemMoved(data, req, res) {
  logger.info('Processing item move webhook:', data);
  
  // TODO: Update barcode references when items are moved between groups/boards
  
  res.status(200).json({
    status: 'success',
    message: 'Item move webhook processed',
    code: 'ITEM_MOVED_PROCESSED'
  });
}

/**
 * Handle item archival webhook
 */
function handleItemArchived(data, req, res) {
  logger.info('Processing item archive webhook:', data);
  
  // TODO: Handle barcode cleanup when items are archived
  
  res.status(200).json({
    status: 'success',
    message: 'Item archive webhook processed',
    code: 'ITEM_ARCHIVED_PROCESSED'
  });
}

/**
 * Handle item deletion webhook
 */
function handleItemDeleted(data, req, res) {
  logger.info('Processing item deletion webhook:', data);
  
  // TODO: Clean up associated barcode data when items are deleted
  
  res.status(200).json({
    status: 'success',
    message: 'Item deletion webhook processed',
    code: 'ITEM_DELETED_PROCESSED'
  });
}

/**
 * Handle board creation webhook
 */
function handleBoardCreated(data, req, res) {
  logger.info('Processing board creation webhook:', data);
  
  // TODO: Set up barcode columns or templates for new boards
  
  res.status(200).json({
    status: 'success',
    message: 'Board creation webhook processed',
    code: 'BOARD_CREATED_PROCESSED'
  });
}

/**
 * Handle column creation webhook
 */
function handleColumnCreated(data, req, res) {
  logger.info('Processing column creation webhook:', data);
  
  // TODO: Detect if new column is for barcode data and configure accordingly
  
  res.status(200).json({
    status: 'success',
    message: 'Column creation webhook processed',
    code: 'COLUMN_CREATED_PROCESSED'
  });
}

// ==============================================
// TESTING & DEBUGGING ENDPOINTS
// ==============================================

if (process.env.NODE_ENV === 'development') {
  /**
   * @route   POST /webhooks/test
   * @desc    Test webhook endpoint for development
   * @access  Public
   */
  router.post('/test', (req, res) => {
    logger.info('Test webhook received:', req.body);
    
    res.status(200).json({
      status: 'success',
      message: 'Test webhook received successfully',
      data: req.body,
      timestamp: new Date().toISOString()
    });
  });

  /**
   * @route   GET /webhooks/debug/signature
   * @desc    Debug signature generation for testing
   * @access  Public
   */
  router.get('/debug/signature', (req, res) => {
    const testPayload = { event: 'test', data: { message: 'test webhook' } };
    const signature = crypto
      .createHmac('sha256', process.env.MONDAY_SIGNING_SECRET || 'default-secret')
      .update(JSON.stringify(testPayload))
      .digest('hex');

    res.status(200).json({
      status: 'success',
      data: {
        payload: testPayload,
        signature: signature,
        secret: process.env.MONDAY_SIGNING_SECRET ? 'configured' : 'using default'
      }
    });
  });
}

// ==============================================
// ERROR HANDLING
// ==============================================

// Handle 404 for webhook routes
router.use('*', (req, res) => {
  res.status(404).json({
    status: 'error',
    message: `Webhook endpoint ${req.originalUrl} not found`,
    code: 'WEBHOOK_ENDPOINT_NOT_FOUND'
  });
});

module.exports = router; 