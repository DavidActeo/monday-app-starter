/**
 * Utility functions for the Monday.com Barcode Generator
 * Common helper functions used across the frontend
 */

// DOM utilities
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

// Show/hide elements
const show = (element) => {
  if (typeof element === 'string') element = $(element);
  if (element) element.style.display = 'block';
};

const hide = (element) => {
  if (typeof element === 'string') element = $(element);
  if (element) element.style.display = 'none';
};

const toggle = (element) => {
  if (typeof element === 'string') element = $(element);
  if (element) {
    element.style.display = element.style.display === 'none' ? 'block' : 'none';
  }
};

// Loading states
const showLoading = (message = 'Loading...') => {
  const loading = $('#loading-screen');
  const loadingText = $('#loading-text');
  if (loadingText) loadingText.textContent = message;
  show(loading);
};

const hideLoading = () => {
  hide('#loading-screen');
};

// Tab management
const switchTab = (tabId) => {
  // Hide all tab contents
  $$('.tab-content').forEach(content => {
    content.classList.remove('active');
  });
  
  // Remove active from all tab buttons
  $$('.tab-button').forEach(button => {
    button.classList.remove('active');
  });
  
  // Show selected tab content
  const targetContent = $(`#${tabId}-content`);
  const targetButton = $(`[data-tab="${tabId}"]`);
  
  if (targetContent) targetContent.classList.add('active');
  if (targetButton) targetButton.classList.add('active');
};

// Form utilities
const getFormData = (formElement) => {
  if (typeof formElement === 'string') formElement = $(formElement);
  if (!formElement) return {};
  
  const formData = new FormData(formElement);
  const data = {};
  
  for (let [key, value] of formData.entries()) {
    data[key] = value;
  }
  
  return data;
};

const setFormData = (formElement, data) => {
  if (typeof formElement === 'string') formElement = $(formElement);
  if (!formElement || !data) return;
  
  Object.keys(data).forEach(key => {
    const field = formElement.querySelector(`[name="${key}"]`);
    if (field) {
      if (field.type === 'checkbox') {
        field.checked = Boolean(data[key]);
      } else {
        field.value = data[key] || '';
      }
    }
  });
};

const clearForm = (formElement) => {
  if (typeof formElement === 'string') formElement = $(formElement);
  if (formElement) formElement.reset();
};

// Validation utilities
const validateBarcodeInput = (value, type) => {
  if (!value || !value.trim()) {
    return { valid: false, message: 'Value is required' };
  }
  
  const trimmedValue = value.trim();
  
  switch (type) {
    case 'CODE128':
      if (trimmedValue.length > 80) {
        return { valid: false, message: 'CODE128 value must be 80 characters or less' };
      }
      break;
    case 'QR':
      if (trimmedValue.length > 2953) {
        return { valid: false, message: 'QR code value is too long (max 2953 characters)' };
      }
      break;
    default:
      return { valid: false, message: 'Invalid barcode type' };
  }
  
  return { valid: true };
};

// Message utilities
const showMessage = (message, type = 'info', duration = 5000) => {
  const messageContainer = $('#message-container') || createMessageContainer();
  
  const messageElement = document.createElement('div');
  messageElement.className = `message message-${type}`;
  messageElement.innerHTML = `
    <span class="message-text">${message}</span>
    <button class="message-close" onclick="this.parentElement.remove()">×</button>
  `;
  
  messageContainer.appendChild(messageElement);
  
  // Auto remove after duration
  if (duration > 0) {
    setTimeout(() => {
      if (messageElement.parentElement) {
        messageElement.remove();
      }
    }, duration);
  }
  
  return messageElement;
};

const createMessageContainer = () => {
  const container = document.createElement('div');
  container.id = 'message-container';
  container.className = 'message-container';
  document.body.appendChild(container);
  return container;
};

const showError = (message, duration = 5000) => {
  return showMessage(message, 'error', duration);
};

const showSuccess = (message, duration = 5000) => {
  return showMessage(message, 'success', duration);
};

const showWarning = (message, duration = 5000) => {
  return showMessage(message, 'warning', duration);
};

// API utilities
const apiRequest = async (endpoint, options = {}) => {
  try {
    const defaultOptions = {
      headers: {
        'Content-Type': 'application/json',
      },
    };
    
    const response = await fetch(endpoint, {
      ...defaultOptions,
      ...options,
      headers: {
        ...defaultOptions.headers,
        ...options.headers,
      },
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
};

// Format utilities
const formatDate = (date) => {
  if (!date) return '';
  const d = new Date(date);
  return d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
};

const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// Debounce utility
const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

// Export utilities for use in other scripts
window.Utils = {
  $, $$, show, hide, toggle,
  showLoading, hideLoading,
  switchTab,
  getFormData, setFormData, clearForm,
  validateBarcodeInput,
  showMessage, showError, showSuccess, showWarning,
  apiRequest,
  formatDate, formatFileSize,
  debounce
}; 