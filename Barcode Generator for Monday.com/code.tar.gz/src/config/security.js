/**
 * Security Configuration
 * 
 * This file contains all security-related configuration including
 * JWT settings, encryption parameters, and security policies.
 */

const { SECURITY_CONFIG } = require('../utils/constants');

// ==============================================
// JWT CONFIGURATION
// ==============================================

const jwt = {
  secret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
  algorithm: 'HS256',
  expiresIn: process.env.JWT_EXPIRES_IN || SECURITY_CONFIG.JWT_EXPIRES_IN,
  issuer: process.env.JWT_ISSUER || 'monday-barcode-generator',
  audience: process.env.JWT_AUDIENCE || 'monday-barcode-users',
  
  refresh: {
    secret: process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET || 'your-refresh-secret',
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || SECURITY_CONFIG.JWT_REFRESH_EXPIRES_IN,
    algorithm: 'HS256'
  },
  
  options: {
    clockTolerance: 60, // 60 seconds
    ignoreExpiration: false,
    ignoreNotBefore: false
  }
};

// ==============================================
// SESSION CONFIGURATION
// ==============================================

const session = {
  secret: process.env.SESSION_SECRET || 'your-session-secret-change-in-production',
  name: 'monday.barcode.sid',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: parseInt(process.env.SESSION_TIMEOUT) || SECURITY_CONFIG.SESSION_TIMEOUT,
    sameSite: 'strict'
  },
  
  store: {
    type: process.env.SESSION_STORE_TYPE || 'memory', // memory, redis, mongodb
    url: process.env.SESSION_STORE_URL,
    options: {
      ttl: parseInt(process.env.SESSION_TTL) || 86400 // 24 hours
    }
  }
};

// ==============================================
// ENCRYPTION CONFIGURATION
// ==============================================

const encryption = {
  algorithm: 'aes-256-gcm',
  keyLength: 32,
  ivLength: 16,
  tagLength: 16,
  
  // Key derivation
  pbkdf2: {
    iterations: 100000,
    keyLength: 32,
    digest: 'sha256'
  },
  
  // Password hashing
  bcrypt: {
    rounds: parseInt(process.env.BCRYPT_ROUNDS) || SECURITY_CONFIG.BCRYPT_ROUNDS
  }
};

// ==============================================
// CORS CONFIGURATION
// ==============================================

const cors = {
  origin: function (origin, callback) {
    // Allow development origins
    const allowedOrigins = [
      'http://localhost:3000',
      'http://127.0.0.1:3000',
      'https://monday.com',
      'https://auth.monday.com',
      'https://api.monday.com'
    ];
    
    // Add production origins from environment
    if (process.env.ALLOWED_ORIGINS) {
      allowedOrigins.push(...process.env.ALLOWED_ORIGINS.split(','));
    }
    
    // Allow requests with no origin (mobile apps, etc.)
    if (!origin) return callback(null, true);
    
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  
  allowedHeaders: [
    'Origin',
    'X-Requested-With',
    'Content-Type',
    'Accept',
    'Authorization',
    'Cache-Control',
    'X-API-Key'
  ],
  
  credentials: true,
  maxAge: 86400 // 24 hours
};

// ==============================================
// HELMET SECURITY HEADERS
// ==============================================

const helmet = {
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'", "https://cdn.monday.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      connectSrc: ["'self'", "https://api.monday.com", "https://auth.monday.com"],
      mediaSrc: ["'self'"],
      objectSrc: ["'none'"],
      childSrc: ["'self'"],
      workerSrc: ["'self'"],
      frameSrc: ["'self'", "https://monday.com"],
      formAction: ["'self'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null
    }
  },
  
  hsts: {
    maxAge: 31536000, // 1 year
    includeSubDomains: true,
    preload: true
  },
  
  noSniff: true,
  frameguard: { action: 'deny' },
  xssFilter: true,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
};

// ==============================================
// API SECURITY
// ==============================================

const api = {
  rateLimiting: {
    enabled: process.env.ENABLE_RATE_LIMITING !== 'false',
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
    
    // Skip successful requests
    skipSuccessfulRequests: false,
    skipFailedRequests: false,
    
    // Custom key generator
    keyGenerator: (req) => req.ip,
    
    // Handler for when limit is reached
    handler: (req, res) => {
      res.status(429).json({
        error: 'Rate limit exceeded',
        message: 'Too many requests from this IP, please try again later.',
        retryAfter: Math.round(15 * 60 * 1000 / 1000) // seconds
      });
    }
  },
  
  validation: {
    // Maximum request size
    maxRequestSize: process.env.MAX_REQUEST_SIZE || '10mb',
    
    // Parameter pollution protection
    parameterLimit: 100,
    
    // JSON parsing limits
    jsonLimit: '10mb',
    
    // URL encoded limits
    urlencodedLimit: '10mb'
  }
};

// ==============================================
// WEBHOOK SECURITY
// ==============================================

const webhook = {
  signature: {
    algorithm: 'sha256',
    header: 'authorization',
    secret: process.env.MONDAY_SIGNING_SECRET
  },
  
  timeout: parseInt(process.env.WEBHOOK_TIMEOUT) || 5000,
  
  validation: {
    requireSignature: true,
    maxAge: 300, // 5 minutes
    allowedIPs: process.env.WEBHOOK_ALLOWED_IPS ? 
      process.env.WEBHOOK_ALLOWED_IPS.split(',') : []
  }
};

// ==============================================
// SECURITY POLICIES
// ==============================================

const policies = {
  // Password requirements
  password: {
    minLength: SECURITY_CONFIG.PASSWORD_MIN_LENGTH,
    requireLowercase: SECURITY_CONFIG.PASSWORD_REQUIREMENTS.LOWERCASE,
    requireUppercase: SECURITY_CONFIG.PASSWORD_REQUIREMENTS.UPPERCASE,
    requireNumbers: SECURITY_CONFIG.PASSWORD_REQUIREMENTS.NUMBERS,
    requireSpecialChars: SECURITY_CONFIG.PASSWORD_REQUIREMENTS.SPECIAL_CHARS,
    maxAge: 90 * 24 * 60 * 60 * 1000, // 90 days
    historySize: 5 // Remember last 5 passwords
  },
  
  // Account lockout
  lockout: {
    enabled: true,
    maxAttempts: SECURITY_CONFIG.MAX_LOGIN_ATTEMPTS,
    lockoutTime: SECURITY_CONFIG.LOCKOUT_TIME,
    resetTime: 24 * 60 * 60 * 1000 // 24 hours
  },
  
  // Data retention
  dataRetention: {
    logs: 30 * 24 * 60 * 60 * 1000, // 30 days
    sessions: 7 * 24 * 60 * 60 * 1000, // 7 days
    barcodes: 30 * 24 * 60 * 60 * 1000, // 30 days
    auditTrail: 365 * 24 * 60 * 60 * 1000 // 1 year
  },
  
  // Privacy settings
  privacy: {
    anonymizeIPs: process.env.NODE_ENV === 'production',
    logRetention: 30, // days
    dataProcessingConsent: true,
    cookieConsent: true
  }
};

// ==============================================
// VALIDATION FUNCTIONS
// ==============================================

/**
 * Validate security configuration
 */
const validateSecurityConfig = () => {
  const errors = [];
  
  if (!jwt.secret || jwt.secret === 'your-super-secret-jwt-key-change-in-production') {
    errors.push('JWT_SECRET must be set to a secure value in production');
  }
  
  if (!session.secret || session.secret === 'your-session-secret-change-in-production') {
    errors.push('SESSION_SECRET must be set to a secure value in production');
  }
  
  if (process.env.NODE_ENV === 'production') {
    if (!session.cookie.secure) {
      errors.push('Session cookies must be secure in production');
    }
    
    if (cors.origin === '*') {
      errors.push('CORS origin should not be wildcard in production');
    }
  }
  
  if (webhook.validation.requireSignature && !webhook.signature.secret) {
    errors.push('Webhook signing secret is required when signature validation is enabled');
  }
  
  if (errors.length > 0) {
    throw new Error(`Security configuration errors: ${errors.join(', ')}`);
  }
};

/**
 * Get environment-specific security settings
 */
const getEnvironmentSecurity = () => {
  const env = process.env.NODE_ENV || 'development';
  
  const envSecurity = {
    development: {
      strictSSL: false,
      allowInsecureRequests: true,
      debugMode: true,
      verboseLogs: true
    },
    staging: {
      strictSSL: true,
      allowInsecureRequests: false,
      debugMode: false,
      verboseLogs: true
    },
    production: {
      strictSSL: true,
      allowInsecureRequests: false,
      debugMode: false,
      verboseLogs: false
    }
  };
  
  return envSecurity[env] || envSecurity.development;
};

// ==============================================
// EXPORTS
// ==============================================

module.exports = {
  jwt,
  session,
  encryption,
  cors,
  helmet,
  api,
  webhook,
  policies,
  validateSecurityConfig,
  getEnvironmentSecurity
}; 